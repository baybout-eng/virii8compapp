# Virii8 Companion Android

Version: 1.0.0 production release candidate

Virii8 Companion is the Android-side bridge for the Virii8 Ecosystem. The first active production-candidate module is Health Bridge for Samsung Health Data SDK 1.1.0.

The app pairs with Virii8 Core using a tokenized bridge, requests Samsung Health permissions on-device, reads approved health categories, queues failed sync payloads locally, and syncs normalized records to Virii8 Core.

## Current status

This package is a v1.0.0 production release candidate aligned to Virii8 Ecosystem Core 1.6.1266. It preserves release signing support, Samsung approval prep, privacy/support/store metadata, all Samsung read paths, offline queue/retry, background sync controls, privacy dashboard, bottom navigation, and accessibility polish.

It is not a broad public release until Samsung approval, release SHA-256 registration, signed artifact verification, public privacy/support URLs, and real-device Core smoke testing are complete.

## App identity

```text
App label: Virii8 Companion
Production package: com.miltonmarketing.virii8.health
Debug package: com.miltonmarketing.virii8.health.debug
versionName: 1.0.0
versionCode: 19
Core reconciliation baseline: Virii8 Core 1.6.1266
Samsung SDK: 1.1.0
```

## Build types

Debug/private testing APK:

```bash
./gradlew --no-daemon clean assembleDebug
```

Release APK/AAB after keystore configuration:

```bash
cp keystore.properties.example keystore.properties
# edit keystore.properties privately
./gradlew --no-daemon clean printSigningStatus assembleRelease bundleRelease
```

## Required runtime gates before external production distribution

```text
1. Install v1.0.0 on a Samsung device with Samsung Health installed.
2. Confirm header shows v1.0.0 production RC.
3. Pair against Virii8 Core 1.6.1266.
4. Test bridge status endpoint.
5. Grant Samsung permissions for selected categories.
6. Run Sync Today with real Samsung Health data.
7. Verify Core Companion devices panel shows the device.
8. Verify Core Imported data map shows inserted rows.
9. Test offline queue/retry.
10. Confirm diagnostics exclude bridge token.
11. Build signed release APK/AAB.
12. Register release SHA-256 with Samsung/approval flow.
```

## GitHub Actions ZIP workflow

For Bernard's current ZIP-based repository, copy the workflow from:

```text
docs/GITHUB-ACTIONS-ZIP-RELEASE-v1.0.0.yml
```

That ZIP-based workflow expects this exact ZIP filename in the repo root:

```text
virii8-companion-android-v1.0.0-production-release-candidate-source.zip
```

## Production/support docs

```text
docs/FINAL-RELEASE-CANDIDATE-v1.0.0.md
docs/GITHUB-ACTIONS-ZIP-RELEASE-v1.0.0.yml
docs/PATCH-REPORT-v1.0.0.txt
docs/FILE-MANIFEST-v1.0.0.txt
docs/SAMSUNG-APP-REGISTRATION-v0.9.6.md
docs/SAMSUNG-APPROVAL-CHECKLIST-v0.9.6.md
docs/PRIVACY-POLICY-DRAFT-v0.9.7.md
docs/SUPPORT-CONTACTS-v0.9.7.md
docs/STORE-LISTING-METADATA-v0.9.7.md
docs/DATA-SAFETY-FORM-v0.9.7.md
docs/DISTRIBUTION-CHECKLIST-v0.9.7.md
```
