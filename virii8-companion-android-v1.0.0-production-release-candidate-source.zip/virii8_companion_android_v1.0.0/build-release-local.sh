#!/usr/bin/env bash
set -euo pipefail

chmod +x ./gradlew
./gradlew --no-daemon clean printSigningStatus assembleRelease bundleRelease

printf '\nRelease APK output:\n'
find app/build/outputs/apk/release -type f -maxdepth 2 2>/dev/null || true
printf '\nRelease AAB output:\n'
find app/build/outputs/bundle/release -type f -maxdepth 2 2>/dev/null || true
