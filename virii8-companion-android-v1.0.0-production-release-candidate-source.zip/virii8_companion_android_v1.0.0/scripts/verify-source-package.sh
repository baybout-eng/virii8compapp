#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
grep -n "versionCode 19" app/build.gradle
grep -n "versionName '1.0.0'" app/build.gradle
grep -n 'APP_VERSION = "1.0.0"' app/src/main/java/com/miltonmarketing/virii8/health/MainActivity.java
test -f app/libs/samsung-health-data-api-1.1.0.aar
test -f docs/GITHUB-ACTIONS-ZIP-RELEASE-v1.0.0.yml
test -f docs/FINAL-RELEASE-CANDIDATE-v1.0.0.md
test -f docs/PATCH-REPORT-v1.0.0.txt
test -f docs/FILE-MANIFEST-v1.0.0.txt
test -f scripts/print-signing-fingerprints.sh
test -f keystore.properties.example
printf 'Virii8 Companion Android v1.0.0 source package markers verified.
'
