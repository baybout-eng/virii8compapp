#!/usr/bin/env bash
set -euo pipefail

DEBUG_KEYSTORE="${HOME}/.android/debug.keystore"
DEBUG_ALIAS="androiddebugkey"
DEBUG_PASS="android"

printf '\nVirii8 Companion package name:\ncom.miltonmarketing.virii8.health\n'
printf '\nDebug SHA fingerprints, if debug keystore exists:\n'
if [ -f "$DEBUG_KEYSTORE" ]; then
  keytool -list -v -keystore "$DEBUG_KEYSTORE" -alias "$DEBUG_ALIAS" -storepass "$DEBUG_PASS" -keypass "$DEBUG_PASS" | grep -E 'SHA1:|SHA256:' || true
else
  echo "Debug keystore not found at $DEBUG_KEYSTORE. Build once or run an Android Gradle task to generate it."
fi

printf '\nRelease SHA fingerprints from keystore.properties, if configured:\n'
if [ -f "keystore.properties" ]; then
  STORE_FILE="$(grep -E '^storeFile=' keystore.properties | cut -d= -f2-)"
  STORE_PASSWORD="$(grep -E '^storePassword=' keystore.properties | cut -d= -f2-)"
  KEY_ALIAS="$(grep -E '^keyAlias=' keystore.properties | cut -d= -f2-)"
  KEY_PASSWORD="$(grep -E '^keyPassword=' keystore.properties | cut -d= -f2-)"
  if [ -n "$STORE_FILE" ] && [ -f "$STORE_FILE" ]; then
    keytool -list -v -keystore "$STORE_FILE" -alias "$KEY_ALIAS" -storepass "$STORE_PASSWORD" -keypass "$KEY_PASSWORD" | grep -E 'SHA1:|SHA256:' || true
  else
    echo "Configured storeFile does not exist: $STORE_FILE"
  fi
else
  echo "keystore.properties not found. Copy keystore.properties.example to keystore.properties after creating a private release keystore."
fi
