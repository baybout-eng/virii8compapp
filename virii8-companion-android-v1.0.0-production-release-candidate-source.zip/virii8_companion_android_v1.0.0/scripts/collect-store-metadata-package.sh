#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="$ROOT_DIR/release/store-metadata-v1.0.0"
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"
cp "$ROOT_DIR/docs/PRIVACY-POLICY-DRAFT-v1.0.0.md" "$OUT_DIR/"
cp "$ROOT_DIR/docs/SUPPORT-CONTACTS-v1.0.0.md" "$OUT_DIR/"
cp "$ROOT_DIR/docs/STORE-LISTING-METADATA-v1.0.0.md" "$OUT_DIR/"
cp "$ROOT_DIR/docs/DATA-SAFETY-FORM-v1.0.0.md" "$OUT_DIR/"
cp "$ROOT_DIR/docs/DISTRIBUTION-CHECKLIST-v1.0.0.md" "$OUT_DIR/"
cp "$ROOT_DIR/docs/SAMSUNG-APP-REGISTRATION-v0.9.6.md" "$OUT_DIR/"
cp "$ROOT_DIR/docs/SAMSUNG-APPROVAL-CHECKLIST-v0.9.6.md" "$OUT_DIR/"
cat > "$OUT_DIR/README.txt" <<'README_EOF'
Virii8 Companion v1.0.0 store/distribution metadata package.
This package is a prep bundle, not final legal/store approval.
Verify public privacy/support URLs, Samsung approval, release signing, and real-device smoke tests before distribution.
README_EOF
find "$OUT_DIR" -maxdepth 1 -type f -printf '%f\n' | sort
