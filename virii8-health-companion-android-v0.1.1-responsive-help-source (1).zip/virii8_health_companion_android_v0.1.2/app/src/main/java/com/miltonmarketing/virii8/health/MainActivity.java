package com.miltonmarketing.virii8.health;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String APP_VERSION = "0.1.2";
    private static final int BG = Color.rgb(7, 19, 31);
    private static final int PANEL = Color.rgb(14, 34, 53);
    private static final int PANEL_ALT = Color.rgb(19, 43, 66);
    private static final int PANEL_SOFT = Color.rgb(11, 28, 45);
    private static final int TEXT = Color.rgb(243, 250, 255);
    private static final int MUTED = Color.rgb(159, 183, 200);
    private static final int ACCENT = Color.rgb(34, 211, 238);
    private static final int ACCENT_2 = Color.rgb(94, 234, 212);
    private static final int WARNING = Color.rgb(251, 191, 36);

    private static final String STATE_SITE = "state_site";
    private static final String STATE_TOKEN = "state_token";
    private static final String STATE_DEVICE = "state_device";
    private static final String STATE_STATUS = "state_status";

    private SecureTokenStore tokenStore;
    private SamsungHealthBridge samsungBridge;
    private EditText siteUrl;
    private EditText pairingToken;
    private EditText deviceLabel;
    private TextView status;
    private TextView bridgeSummary;
    private String lastStatus = "Ready. Pair this phone with Virii8, grant Samsung Health permissions, then run Sync Today.";
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tokenStore = new SecureTokenStore(this);
        samsungBridge = new SamsungHealthBridge(this);

        String initialSite = savedInstanceState != null ? savedInstanceState.getString(STATE_SITE, tokenStore.getSiteUrl()) : tokenStore.getSiteUrl();
        String initialToken = savedInstanceState != null ? savedInstanceState.getString(STATE_TOKEN, "") : "";
        String initialDevice = savedInstanceState != null ? savedInstanceState.getString(STATE_DEVICE, tokenStore.getDeviceLabel()) : tokenStore.getDeviceLabel();
        String initialStatus = savedInstanceState != null ? savedInstanceState.getString(STATE_STATUS, lastStatus) : lastStatus;
        buildUi(initialSite, initialToken, initialDevice, initialStatus);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        String currentSite = siteUrl != null ? siteUrl.getText().toString() : tokenStore.getSiteUrl();
        String currentToken = pairingToken != null ? pairingToken.getText().toString() : "";
        String currentDevice = deviceLabel != null ? deviceLabel.getText().toString() : tokenStore.getDeviceLabel();
        String currentStatus = status != null ? status.getText().toString() : lastStatus;
        buildUi(currentSite, currentToken, currentDevice, currentStatus + "\nLayout refreshed for " + layoutModeLabel() + ".");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (siteUrl != null) outState.putString(STATE_SITE, siteUrl.getText().toString());
        if (pairingToken != null) outState.putString(STATE_TOKEN, pairingToken.getText().toString());
        if (deviceLabel != null) outState.putString(STATE_DEVICE, deviceLabel.getText().toString());
        if (status != null) outState.putString(STATE_STATUS, status.getText().toString());
    }

    @Override
    protected void onDestroy() {
        networkExecutor.shutdownNow();
        super.onDestroy();
    }

    private void buildUi(String initialSite, String initialToken, String initialDevice, String initialStatus) {
        Configuration cfg = getResources().getConfiguration();
        int widthDp = Math.max(320, cfg.screenWidthDp);
        int heightDp = Math.max(320, cfg.screenHeightDp);
        int smallestDp = Math.max(0, cfg.smallestScreenWidthDp);
        boolean landscape = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE || widthDp > heightDp;
        boolean twoColumn = widthDp >= 520 || smallestDp >= 600 || (landscape && widthDp >= 430);
        boolean largeCanvas = widthDp >= 720 || smallestDp >= 720;
        boolean compact = widthDp < 380;

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        outer.setPadding(dp(compact ? 12 : 20), dp(landscape ? 12 : 22), dp(compact ? 12 : 20), dp(24));
        scroll.addView(outer, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int maxWidthPx = largeCanvas ? dp(1240) : LinearLayout.LayoutParams.MATCH_PARENT;
        LinearLayout.LayoutParams rootParams = new LinearLayout.LayoutParams(maxWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT);
        rootParams.gravity = Gravity.CENTER_HORIZONTAL;
        outer.addView(root, rootParams);

        root.addView(header(twoColumn, compact, landscape));
        root.addView(adaptiveNoticeCard(widthDp, heightDp, smallestDp, landscape, twoColumn));
        root.addView(bridgeStatusCard());

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(twoColumn ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        body.setGravity(Gravity.TOP);
        body.setLayoutParams(matchWrapBottom(dp(14)));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);

        if (twoColumn) {
            LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.05f);
            leftParams.setMargins(0, 0, dp(8), 0);
            LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.95f);
            rightParams.setMargins(dp(8), 0, 0, 0);
            body.addView(left, leftParams);
            body.addView(right, rightParams);
        } else {
            body.addView(left, matchWrapBottom(0));
            body.addView(right, matchWrapBottom(0));
        }

        left.addView(pairingCard(initialSite, initialToken, initialDevice));
        left.addView(actionsCard());
        left.addView(setupHelpCard());

        right.addView(dataCoverageCard());
        right.addView(linksCard());
        right.addView(privacyCard());

        root.addView(body);

        status = text("", compact ? 13 : 14, TEXT, false);
        status.setBackgroundColor(PANEL);
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        status.setGravity(Gravity.START);
        root.addView(status, matchWrapBottom(0));

        setContentView(scroll);
        updateBridgeSummary();
        refreshStatus(initialStatus == null || initialStatus.trim().isEmpty() ? lastStatus : initialStatus);
    }

    private View header(boolean twoColumn, boolean compact, boolean landscape) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(twoColumn && landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(0, 0, 0, dp(twoColumn ? 12 : 18));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("mm_logo", "drawable", getPackageName()));
        int logoSize = dp(compact ? 64 : (twoColumn ? 76 : 88));
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(logoSize, logoSize);
        logoParams.gravity = Gravity.CENTER;
        if (twoColumn && landscape) logoParams.setMargins(0, 0, dp(16), 0);
        logo.setLayoutParams(logoParams);
        logo.setAdjustViewBounds(true);
        header.addView(logo);

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setGravity(twoColumn && landscape ? Gravity.CENTER_VERTICAL : Gravity.CENTER_HORIZONTAL);

        TextView title = text("Virii8 Health Companion", twoColumn ? 22 : 25, TEXT, true);
        title.setGravity(twoColumn && landscape ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        copy.addView(title);

        TextView subtitle = text("Private Samsung Health sync for MiltonMarketing.com", 14, MUTED, false);
        subtitle.setGravity(twoColumn && landscape ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, dp(5), 0, 0);
        copy.addView(subtitle);

        TextView version = text("v" + APP_VERSION + " adaptive layout • " + layoutModeLabel(), 12, ACCENT_2, true);
        version.setGravity(twoColumn && landscape ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        version.setPadding(0, dp(6), 0, 0);
        copy.addView(version);

        header.addView(copy, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return header;
    }

    private View adaptiveNoticeCard(int widthDp, int heightDp, int smallestDp, boolean landscape, boolean twoColumn) {
        LinearLayout card = card(PANEL_SOFT);
        card.addView(sectionTitle("Adaptive display"));
        card.addView(text("Current mode: " + layoutModeLabel() + ". Cards reflow automatically for portrait, landscape, tablets, foldables, and DeX-style resizable windows.", 13, MUTED, false));
        card.addView(metricRow("Layout", twoColumn ? "Two-column dashboard" : "Single-column phone stack"));
        card.addView(metricRow("Viewport", widthDp + "dp × " + heightDp + "dp" + (smallestDp > 0 ? " • smallest " + smallestDp + "dp" : "")));
        card.addView(metricRow("Rotation", landscape ? "Landscape / wide" : "Portrait / tall"));
        return card;
    }

    private View bridgeStatusCard() {
        LinearLayout card = card(PANEL);
        card.addView(sectionTitle("Bridge status"));
        bridgeSummary = text("", 13, MUTED, false);
        bridgeSummary.setPadding(0, dp(6), 0, 0);
        card.addView(bridgeSummary);
        return card;
    }

    private View pairingCard(String initialSite, String initialToken, String initialDevice) {
        LinearLayout card = card(PANEL);
        card.addView(sectionTitle("1. Pair this phone"));
        card.addView(text("Paste the bridge token generated by Virii8 Health admin. The token is encrypted on this device and used only for private sync.", 13, MUTED, false));

        card.addView(label("Virii8 Site URL"));
        siteUrl = input("https://miltonmarketing.com", false);
        siteUrl.setText(initialSite == null || initialSite.trim().isEmpty() ? "https://miltonmarketing.com" : initialSite);
        card.addView(siteUrl);

        card.addView(label("Pairing Token"));
        pairingToken = input("Paste token generated in Virii8 Health admin", true);
        if (initialToken != null) pairingToken.setText(initialToken);
        card.addView(pairingToken);

        card.addView(label("Device Label"));
        deviceLabel = input("Samsung phone label", false);
        deviceLabel.setText(initialDevice == null || initialDevice.trim().isEmpty() ? android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL : initialDevice);
        card.addView(deviceLabel);

        Button save = button("Save Pairing", ACCENT, Color.rgb(4, 18, 28));
        save.setOnClickListener(v -> savePairing());
        card.addView(save);
        return card;
    }

    private View actionsCard() {
        LinearLayout actions = card(PANEL);
        actions.addView(sectionTitle("2. Permissions and sync"));
        actions.addView(text("Start with Samsung Health permissions, then run a manual test sync. Background smart sync comes after device testing and Samsung approval checks.", 13, MUTED, false));

        Button permissions = button("Grant Samsung Health Permissions", ACCENT_2, Color.rgb(4, 18, 28));
        permissions.setOnClickListener(v -> samsungBridge.requestPermissions(
            this::refreshStatus,
            e -> refreshStatus("Samsung permission error: " + e.getMessage())
        ));
        actions.addView(permissions);

        Button sync = button("Sync Today", ACCENT, Color.rgb(4, 18, 28));
        sync.setOnClickListener(v -> syncToday());
        actions.addView(sync);

        Button disconnect = button("Disconnect This Phone", PANEL_ALT, TEXT);
        disconnect.setOnClickListener(v -> {
            tokenStore.clear();
            pairingToken.setText("");
            updateBridgeSummary();
            refreshStatus("Disconnected locally. Revoke the bridge token in Virii8 as well if this phone is lost or retired.");
        });
        actions.addView(disconnect);
        return actions;
    }

    private View setupHelpCard() {
        LinearLayout card = card(PANEL);
        card.addView(sectionTitle("Setup help"));
        card.addView(helpLine("1", "Open Virii8 Health admin and generate a Samsung bridge pairing token."));
        card.addView(helpLine("2", "Paste the token here, confirm the site URL, and tap Save Pairing."));
        card.addView(helpLine("3", "Grant only the Samsung Health categories you want Virii8 to import."));
        card.addView(helpLine("4", "Tap Sync Today and confirm the data appears in your private Virii8 Health dashboard."));
        return card;
    }

    private View dataCoverageCard() {
        LinearLayout card = card(PANEL);
        card.addView(sectionTitle("What this build can do"));
        card.addView(metricRow("Now", "Manual Samsung step aggregate sync for today."));
        card.addView(metricRow("Prepared", "Sleep, heart, workout, nutrition, hydration, and body metric bridge mapping."));
        card.addView(metricRow("Protected", "Sleep apnea and irregular rhythm signals are sensitive wellness indicators, not diagnoses."));
        card.addView(metricRow("Later", "Background smart sync, Samsung change tracking, and approved writeback policies."));
        return card;
    }

    private View linksCard() {
        LinearLayout card = card(PANEL);
        card.addView(sectionTitle("Helpful links"));
        card.addView(text("Open trusted references while setting up. These links leave the app.", 13, MUTED, false));
        card.addView(linkButton("MiltonMarketing.com", "https://miltonmarketing.com"));
        card.addView(linkButton("Virii8 Health articles", "https://miltonmarketing.com/?s=Virii8+Health"));
        card.addView(linkButton("Samsung Health Data SDK", "https://developer.samsung.com/health/data/guide/introduction.html"));
        card.addView(linkButton("Android Health Connect", "https://developer.android.com/health-and-fitness/health-connect"));
        card.addView(linkButton("Fitbit Web API", "https://developer.fitbit.com/build/reference/web-api/"));
        card.addView(linkButton("Apple HealthKit", "https://developer.apple.com/documentation/healthkit"));
        return card;
    }

    private View privacyCard() {
        LinearLayout privacy = card(PANEL);
        privacy.addView(sectionTitle("Privacy boundary"));
        privacy.addView(text("This app reads only the Samsung Health categories you approve on this phone and sends them to your private Virii8 Health module using a bridge token. It does not replace Samsung Health, Health Connect, Apple Health, Fitbit, or medical care.", 13, MUTED, false));
        return privacy;
    }

    private View helpLine(String number, String copy) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(10), 0, 0);

        TextView badge = text(number, 13, Color.rgb(4, 18, 28), true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackgroundColor(ACCENT_2);
        row.addView(badge, new LinearLayout.LayoutParams(dp(28), dp(28)));

        TextView body = text(copy, 13, MUTED, false);
        LinearLayout.LayoutParams bodyParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        bodyParams.setMargins(dp(10), 0, 0, 0);
        row.addView(body, bodyParams);
        return row;
    }

    private View metricRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(8), 0, 0);
        TextView l = text(label, 12, WARNING, true);
        TextView v = text(value, 13, MUTED, false);
        v.setPadding(0, dp(2), 0, 0);
        row.addView(l);
        row.addView(v);
        return row;
    }

    private Button linkButton(String label, String url) {
        Button b = button(label, PANEL_ALT, TEXT);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(v -> openUrl(url));
        return b;
    }

    private void openUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            refreshStatus("Could not open link: " + e.getMessage());
        }
    }

    private void savePairing() {
        try {
            String url = siteUrl.getText().toString().trim();
            String token = pairingToken.getText().toString().trim();
            String label = deviceLabel.getText().toString().trim();
            if (!url.startsWith("https://")) throw new IllegalArgumentException("Use an HTTPS Virii8 site URL.");
            if (token.length() < 16) throw new IllegalArgumentException("Pairing token looks too short.");
            if (label.isEmpty()) label = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
            tokenStore.savePairing(url, token, label);
            updateBridgeSummary();
            refreshStatus("Pairing saved securely on this device.");
        } catch (Exception e) {
            refreshStatus("Pairing failed: " + e.getMessage());
        }
    }

    private void syncToday() {
        if (!tokenStore.isPaired()) {
            refreshStatus("Not paired yet. Save your Virii8 site URL and pairing token first.");
            return;
        }
        refreshStatus("Reading today's Samsung Health step aggregates…");
        samsungBridge.readTodaySteps(records -> {
            if (records.isEmpty()) {
                refreshStatus("No step records returned for today. Check Samsung Health permissions and data availability.");
                return;
            }
            refreshStatus("Read " + records.size() + " step records. Sending to Virii8…");
            networkExecutor.execute(() -> {
                try {
                    JSONObject payload = samsungBridge.buildSyncPayload(tokenStore.getDeviceLabel(), records);
                    String response = Virii8HealthApi.postSync(tokenStore.getSiteUrl(), tokenStore.getToken(), payload);
                    runOnUiThread(() -> refreshStatus("Sync complete. Virii8 response: " + response));
                } catch (Exception e) {
                    runOnUiThread(() -> refreshStatus("Virii8 sync error: " + e.getMessage()));
                }
            });
        }, e -> refreshStatus("Samsung read error: " + e.getMessage()));
    }

    private void updateBridgeSummary() {
        if (bridgeSummary == null || tokenStore == null) return;
        String paired = tokenStore.isPaired() ? "Paired" : "Not paired";
        String device = tokenStore.getDeviceLabel();
        String site = tokenStore.getSiteUrl();
        bridgeSummary.setText(paired + " • " + device + " • " + site + "\nSamsung SDK bridge: manual sync scaffold v" + APP_VERSION + ". Data stays private to your Virii8 account/tenant boundary.");
    }

    private LinearLayout card(int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundColor(color);
        card.setLayoutParams(matchWrapBottom(dp(14)));
        return card;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 16, TEXT, true);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 12, MUTED, true);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private EditText input(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setBackgroundColor(PANEL_ALT);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setInputType(password ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return e;
    }

    private Button button(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(fg);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackgroundColor(bg);
        b.setMinHeight(dp(48));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(10), 0, 0);
        b.setLayoutParams(p);
        return b;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(dp(1), 1.05f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void refreshStatus(String message) {
        lastStatus = message == null ? "" : message;
        if (status != null) {
            status.setText(lastStatus);
        }
    }

    private String layoutModeLabel() {
        Configuration cfg = getResources().getConfiguration();
        int widthDp = Math.max(320, cfg.screenWidthDp);
        int heightDp = Math.max(320, cfg.screenHeightDp);
        int smallestDp = Math.max(0, cfg.smallestScreenWidthDp);
        boolean landscape = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE || widthDp > heightDp;
        boolean tablet = smallestDp >= 600 || widthDp >= 720;
        boolean foldableWide = widthDp >= 520 && heightDp >= 520;
        if (landscape && tablet) return "landscape tablet";
        if (landscape) return "landscape phone/foldable";
        if (tablet) return "portrait tablet";
        if (foldableWide) return "portrait foldable/wide";
        return "portrait phone";
    }

    private LinearLayout.LayoutParams matchWrapBottom(int bottomMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 0, 0, bottomMargin);
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
