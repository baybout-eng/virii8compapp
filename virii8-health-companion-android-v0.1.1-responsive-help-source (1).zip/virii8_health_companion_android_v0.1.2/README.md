# Virii8 Health Companion Android v0.1.2

Professional Samsung Health companion app scaffold for Virii8 / MiltonMarketing.com.

## v0.1.2 changes

- Makes orientation handling explicit with `fullSensor`.
- Adds `resizeableActivity=true` for tablets, foldables, and Samsung DeX-style windows.
- Handles configuration changes and rebuilds the UI when orientation/screen size changes.
- Adds visible adaptive display diagnostics so it is obvious which APK/build is installed.
- Lowers the two-column threshold for foldables/tablets so portrait tablet layouts do not waste the screen.
- Keeps Samsung Health Data SDK 1.1.0 bridge scaffolding, encrypted pairing storage, and manual Samsung steps sync.

## Build debug APK in GitHub Actions

Keep this ZIP in the repository root and use the root workflow:

`.github/workflows/build-virii8-health-apk-from-zip.yml`

That workflow should locate the latest `virii8-health-companion-android-v*.zip`, unzip it, and run `./gradlew assembleDebug`.

## Local build

```bash
./build-debug-apk.sh
```

Output:

```text
app/build/outputs/apk/debug/app-debug.apk
```
