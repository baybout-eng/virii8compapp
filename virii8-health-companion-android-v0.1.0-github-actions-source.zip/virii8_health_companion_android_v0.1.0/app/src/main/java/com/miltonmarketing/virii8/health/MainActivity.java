package com.miltonmarketing.virii8.health;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(7, 19, 31);
    private static final int PANEL = Color.rgb(14, 34, 53);
    private static final int PANEL_ALT = Color.rgb(19, 43, 66);
    private static final int TEXT = Color.rgb(243, 250, 255);
    private static final int MUTED = Color.rgb(159, 183, 200);
    private static final int ACCENT = Color.rgb(34, 211, 238);

    private SecureTokenStore tokenStore;
    private SamsungHealthBridge samsungBridge;
    private EditText siteUrl;
    private EditText pairingToken;
    private EditText deviceLabel;
    private TextView status;
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tokenStore = new SecureTokenStore(this);
        samsungBridge = new SamsungHealthBridge(this);
        buildUi();
        refreshStatus("Ready. Pair this phone with Virii8, grant Samsung Health permissions, then run Sync Today.");
    }

    @Override
    protected void onDestroy() {
        networkExecutor.shutdownNow();
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(28));
        scroll.addView(root);

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("mm_logo", "drawable", getPackageName()));
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(dp(92), dp(92));
        logoParams.gravity = Gravity.CENTER_HORIZONTAL;
        logo.setLayoutParams(logoParams);
        root.addView(logo);

        TextView title = text("Virii8 Health Companion", 25, TEXT, true);
        title.setGravity(Gravity.CENTER_HORIZONTAL);
        title.setPadding(0, dp(14), 0, 0);
        root.addView(title);

        TextView subtitle = text("Private Samsung Health sync for MiltonMarketing.com", 14, MUTED, false);
        subtitle.setGravity(Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, dp(6), 0, dp(18));
        root.addView(subtitle);

        LinearLayout card = card();
        card.addView(label("Virii8 Site URL"));
        siteUrl = input("https://miltonmarketing.com", false);
        siteUrl.setText(tokenStore.getSiteUrl());
        card.addView(siteUrl);

        card.addView(label("Pairing Token"));
        pairingToken = input("Paste token generated in Virii8 Health admin", true);
        card.addView(pairingToken);

        card.addView(label("Device Label"));
        deviceLabel = input("Samsung phone label", false);
        deviceLabel.setText(tokenStore.getDeviceLabel());
        card.addView(deviceLabel);

        Button save = button("Save Pairing", ACCENT, Color.rgb(4, 18, 28));
        save.setOnClickListener(v -> savePairing());
        card.addView(save);
        root.addView(card);

        LinearLayout actions = card();
        Button permissions = button("Grant Samsung Health Permissions", Color.rgb(94, 234, 212), Color.rgb(4, 18, 28));
        permissions.setOnClickListener(v -> samsungBridge.requestPermissions(
            this::refreshStatus,
            e -> refreshStatus("Samsung permission error: " + e.getMessage())
        ));
        actions.addView(permissions);

        Button sync = button("Sync Today", ACCENT, Color.rgb(4, 18, 28));
        sync.setOnClickListener(v -> syncToday());
        actions.addView(sync);

        Button disconnect = button("Disconnect This Phone", PANEL_ALT, TEXT);
        disconnect.setOnClickListener(v -> {
            tokenStore.clear();
            pairingToken.setText("");
            refreshStatus("Disconnected locally. Revoke the bridge token in Virii8 as well if this phone is lost or retired.");
        });
        actions.addView(disconnect);
        root.addView(actions);

        LinearLayout privacy = card();
        privacy.addView(text("Privacy boundary", 16, TEXT, true));
        privacy.addView(text("This app reads only the Samsung Health categories you approve on this phone and sends them to your private Virii8 Health module using a bridge token. Sleep apnea and irregular-heart-rhythm notification data are treated as sensitive wellness indicators, not diagnoses.", 13, MUTED, false));
        root.addView(privacy);

        status = text("", 14, TEXT, false);
        status.setBackgroundColor(PANEL);
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.addView(status);

        setContentView(scroll);
    }

    private void savePairing() {
        try {
            String url = siteUrl.getText().toString().trim();
            String token = pairingToken.getText().toString().trim();
            String label = deviceLabel.getText().toString().trim();
            if (!url.startsWith("https://")) throw new IllegalArgumentException("Use an HTTPS Virii8 site URL.");
            if (token.length() < 16) throw new IllegalArgumentException("Pairing token looks too short.");
            if (label.isEmpty()) label = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
            tokenStore.savePairing(url, token, label);
            refreshStatus("Pairing saved securely on this device.");
        } catch (Exception e) {
            refreshStatus("Pairing failed: " + e.getMessage());
        }
    }

    private void syncToday() {
        if (!tokenStore.isPaired()) {
            refreshStatus("Not paired yet. Save your Virii8 site URL and pairing token first.");
            return;
        }
        refreshStatus("Reading today's Samsung Health step aggregates…");
        samsungBridge.readTodaySteps(records -> {
            if (records.isEmpty()) {
                refreshStatus("No step records returned for today. Check Samsung Health permissions and data availability.");
                return;
            }
            refreshStatus("Read " + records.size() + " step records. Sending to Virii8…");
            networkExecutor.execute(() -> {
                try {
                    JSONObject payload = samsungBridge.buildSyncPayload(tokenStore.getDeviceLabel(), records);
                    String response = Virii8HealthApi.postSync(tokenStore.getSiteUrl(), tokenStore.getToken(), payload);
                    runOnUiThread(() -> refreshStatus("Sync complete. Virii8 response: " + response));
                } catch (Exception e) {
                    runOnUiThread(() -> refreshStatus("Virii8 sync error: " + e.getMessage()));
                }
            });
        }, e -> refreshStatus("Samsung read error: " + e.getMessage()));
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackgroundColor(PANEL);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 0, 0, dp(16));
        card.setLayoutParams(p);
        return card;
    }

    private TextView label(String s) {
        TextView t = text(s, 12, MUTED, true);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private EditText input(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextColor(TEXT);
        e.setHintTextColor(MUTED);
        e.setBackgroundColor(PANEL_ALT);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setInputType(password ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT);
        return e;
    }

    private Button button(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(fg);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackgroundColor(bg);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(10), 0, 0);
        b.setLayoutParams(p);
        return b;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void refreshStatus(String message) {
        if (status != null) {
            status.setText(message);
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
