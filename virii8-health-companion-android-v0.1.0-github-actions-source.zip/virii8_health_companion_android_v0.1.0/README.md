# Virii8 Health Companion Android v0.1.0

Professional Android test scaffold for syncing Samsung Health data into Virii8 Core.

## Purpose

This is a lean Android bridge app:

Samsung Health on phone -> Samsung Health Data SDK 1.1.0 -> Virii8 Health Companion -> Virii8 Core Health Samsung bridge.

It is not a replacement for the Virii8 web workspace.

## Branding

- App label: Virii8 Health
- Website default: https://miltonmarketing.com
- Package: com.miltonmarketing.virii8.health
- Debug package: com.miltonmarketing.virii8.health.debug
- Logo: MiltonMarketing/Virii8 logo from `mmLOGO.png`

## Current v0.1.0 scope

Implemented:

- Professional single-screen pairing/sync UI
- Virii8 site URL field
- Virii8 pairing-token field
- Device label field
- AndroidKeyStore-backed local token encryption
- Samsung Health Data SDK 1.1.0 AAR dependency
- Samsung Health permission request scaffold
- Samsung steps read for today's hourly aggregate data
- Manual `Sync Today` button
- POST to Core v1.6.1263 Samsung bridge endpoint:
  `/wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/sync`

Declared/readiness permissions:

- Steps
- Sleep
- Blood oxygen
- Skin temperature
- Heart rate
- Nutrition
- Water intake
- Exercise

Writeback is intentionally not enabled.

## Build APK

Open this folder in Android Studio, then run:

```bash
./gradlew assembleDebug
```

Expected APK:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Install with:

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## Samsung requirements

Use a real Samsung device. Samsung Health Data SDK does not support emulator testing. For production, register/approve the app package and release signing SHA-256 with Samsung.

## Virii8 Core requirement

Install Core v1.6.1263 or newer with Samsung Health Data SDK bridge readiness.

Generate a pairing token in Virii8 Health admin, paste it into this app, then save pairing.

## Build APK without Android Studio

This source package includes a GitHub Actions workflow:

```text
.github/workflows/build-debug-apk.yml
```

Upload this project to a GitHub repository, open **Actions**, run **Build Virii8 Health Debug APK**, then download the uploaded artifact named:

```text
virii8-health-companion-v0.1.0-debug-apk
```

The APK produced by the workflow is expected at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Full instructions are in:

```text
docs/GITHUB-ACTIONS-APK-BUILD.txt
```
