# Virii8 Companion v0.9.6 Release Signing Setup

Package:

```text
com.miltonmarketing.virii8.health
```

Version:

```text
versionName 0.9.6
versionCode 17
```

## What changed in v0.9.6

v0.9.6 adds release-signing readiness without committing secrets into source control.

It supports:

- debug APK builds for private testing
- signed release APK builds when signing is configured
- signed release AAB builds when signing is configured
- local `keystore.properties`
- GitHub Actions secrets
- SHA-1/SHA-256 fingerprint helper script
- `.gitignore` protections for keystores and signing property files

## Local signing setup

1. Generate a private release keystore on your own machine:

```bash
./scripts/generate-release-keystore-local.sh
```

2. Copy the example properties file:

```bash
cp keystore.properties.example keystore.properties
```

3. Edit `keystore.properties`:

```properties
storeFile=release/virii8-companion-release.keystore
storePassword=YOUR_PRIVATE_STORE_PASSWORD
keyAlias=virii8-companion
keyPassword=YOUR_PRIVATE_KEY_PASSWORD
```

4. Confirm signing status:

```bash
./gradlew --no-daemon printSigningStatus
```

5. Build release APK and AAB:

```bash
./gradlew --no-daemon clean assembleRelease bundleRelease
```

Expected outputs:

```text
app/build/outputs/apk/release/*.apk
app/build/outputs/bundle/release/*.aab
```

## GitHub Actions signing setup

Add these repository secrets:

```text
V8_RELEASE_KEYSTORE_BASE64
V8_RELEASE_STORE_PASSWORD
V8_RELEASE_KEY_ALIAS
V8_RELEASE_KEY_PASSWORD
```

Create `V8_RELEASE_KEYSTORE_BASE64` from your private keystore:

```bash
base64 -w 0 release/virii8-companion-release.keystore
```

On macOS, use:

```bash
base64 -i release/virii8-companion-release.keystore | tr -d '\n'
```

Then run the release workflow.

## Fingerprints for Samsung approval

Run:

```bash
./scripts/print-signing-fingerprints.sh
```

Samsung registration/approval generally needs the final package name and signing certificate fingerprints. Use the release fingerprint for production identity, not only the debug fingerprint.

## Security rules

Never commit:

```text
keystore.properties
*.keystore
*.jks
*.p12
release/*.keystore
release/*.jks
release/*.p12
```

The source package includes `.gitignore` protections for these files.
