# Virii8 Companion Android v1.0.5 Release Artifact Evidence Workflow

Status: Phase 3 release artifact workflow/evidence candidate, not release-safe.

## Purpose

This pass does not claim a completed APK/AAB build. It hardens the source package so a local or CI release build produces a reviewable evidence bundle alongside the signed APK/AAB.

## Evidence generated after signed release build

When release artifacts exist, run:

```bash
./scripts/verify-release-artifacts.sh
./scripts/collect-release-evidence-package.sh
```

Expected output:

```text
release/verification-v1.0.5/RELEASE-ARTIFACT-VERIFICATION.txt
release/verification-v1.0.5/RELEASE-ARTIFACTS.sha256
release/evidence-v1.0.5/artifacts/*.apk
release/evidence-v1.0.5/artifacts/*.aab
release/evidence-v1.0.5/SIGNING-FINGERPRINTS.txt
release/evidence-v1.0.5/README-RELEASE-EVIDENCE.txt
release/evidence-v1.0.5/EVIDENCE-BUNDLE.sha256
```

## CI behavior

The release workflow builds signed artifacts only when all `V8_RELEASE_*` secrets exist. When artifacts are built, the workflow uploads:

```text
virii8-companion-v1.0.5-release-apk
virii8-companion-v1.0.5-release-aab
virii8-companion-v1.0.5-release-evidence
```

## Release-safe gates still outside this source package

- Android Gradle build and Java compile on a machine with Android SDK access.
- Signed APK/AAB artifact generation.
- Release SHA-256 registration with Samsung approval path.
- Real Samsung-device smoke testing with Samsung Health installed.
- WordPress staging activation and live Health bridge route classification.
- Cache/WAF/PWA Authorization/no-store verification.
- Full Virii8 protected regression matrix.

## Phase 4 assertion

After collecting evidence, run:

```bash
./scripts/assert-release-evidence-complete.sh
```

This is intentionally stricter than collection. Collection creates the evidence directory. Assertion decides whether that evidence is complete enough to preserve as a release candidate artifact.
