# Virii8 Companion Android v1.0.5 Phase 4 Release Execution Gate

Status: `ANDROID_COMPANION_v1.0.5_PHASE4_RELEASE_EXECUTION_GATE_NOT_RELEASE_SAFE`

This pass turns the Phase 3 release evidence workflow into a stricter execution gate. It still does not claim a successful release build in environments that cannot run Android Gradle with a configured SDK and release keystore.

## One-command local gate

After configuring `keystore.properties` privately, run:

```bash
./scripts/phase4-release-execution-gate.sh
```

The gate runs:

```text
1. build environment preflight
2. source marker verification
3. signing fingerprint printout
4. Gradle clean + release signing input verification
5. assembleRelease
6. bundleRelease
7. release artifact verification
8. release evidence package collection
9. release evidence completeness assertion
```

## Evidence assertion

`scripts/assert-release-evidence-complete.sh` fails the release if any of the following are missing or invalid:

```text
- release/verification-v1.0.5/RELEASE-ARTIFACT-VERIFICATION.txt
- release/verification-v1.0.5/RELEASE-ARTIFACTS.sha256
- release/evidence-v1.0.5/artifacts/*.apk
- release/evidence-v1.0.5/artifacts/*.aab
- release/evidence-v1.0.5/SIGNING-FINGERPRINTS.txt
- release/evidence-v1.0.5/README-RELEASE-EVIDENCE.txt
- release/evidence-v1.0.5/EVIDENCE-BUNDLE.sha256
```

It also verifies artifact checksums, evidence-bundle checksums, expected application ID, expected `1.0.5 / versionCode 24`, and scans text evidence for obvious private token/password/raw-payload markers.

## CI behavior

The release GitHub workflow now runs the evidence assertion before uploading release artifacts. This prevents a partial evidence package from being treated as a candidate release bundle.

## Still not release-safe

Release-safe remains blocked until real signed APK/AAB artifacts are built, the evidence package passes, release SHA-256 is registered with Samsung, Samsung approval is confirmed, a real Samsung-device smoke test passes, and Virii8 Core staging/route/cache/WAF checks pass.
