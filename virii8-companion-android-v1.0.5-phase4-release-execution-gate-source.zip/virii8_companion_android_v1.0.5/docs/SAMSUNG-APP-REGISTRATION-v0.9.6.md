# Virii8 Companion v0.9.6 Samsung App Registration / SHA-256 Prep

This pass prepares the Android companion for Samsung Health Data SDK registration and approval. It does not claim Samsung approval has been granted.

## App identity

```text
App label: Virii8 Companion
Production package: com.miltonmarketing.virii8.health
Debug/private-test package: com.miltonmarketing.virii8.health.debug
versionName: 0.9.6
versionCode: 17
minSdk: 29
targetSdk: 34
compileSdk: 34
Samsung SDK: Samsung Health Data SDK 1.1.0
```

Use the **production package** and the **release SHA-256** for production approval. The debug package and debug SHA-256 are private-testing identities only.

## Fingerprints

Generate fingerprints on a build machine after creating/configuring the release keystore:

```bash
./scripts/print-signing-fingerprints.sh
```

Or use Gradle:

```bash
./gradlew --no-daemon signingReport
```

Submit the release certificate SHA-256 when Samsung asks for the production signing certificate. Keep the release keystore private.

## Health data direction

The companion is read-only from Samsung Health to Virii8 Core. It does not write records back into Samsung Health.

## Current Samsung read categories

```text
Steps / activity
Sleep sessions
Sleep stages
Sleep-associated oxygen and temperature where available
Heart-rate records
Workout / exercise summaries
Nutrition
Water intake / hydration
Blood pressure
Blood glucose
Body temperature
Body composition
```

Workout GPS route coordinates are intentionally not synced in this candidate.

## Virii8 bridge endpoints

```text
GET  /wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/status
POST /wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/sync
```

Pairing uses a Virii8-generated token. The Android app stores the token in AndroidKeyStore-backed local encrypted storage and excludes the token from diagnostics and approval summaries.

## Submission notes

Describe the app as a private user-controlled health data bridge for the Virii8 Ecosystem. The app imports user-approved Samsung Health data into the user's Virii8 workspace for private dashboards, trends, and insights. Backend access remains tokenized and tenant-aware inside Virii8 Core.

## Still required before production

- Real Samsung-device APK smoke test.
- Confirm Samsung Health permission prompts for every selected category.
- Confirm Virii8 Core receives normalized records correctly.
- Register final release SHA-256 with Samsung.
- Complete Samsung developer review/approval if required.
- Confirm public privacy policy and support contact.
- Use final signed release APK/AAB only after approval.
