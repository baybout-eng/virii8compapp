# Virii8 Companion Android v1.0.0 Production Release Candidate

## Candidate identity

- App label: Virii8 Companion
- Production package: `com.miltonmarketing.virii8.health`
- Debug package: `com.miltonmarketing.virii8.health.debug`
- versionName: `1.0.0`
- versionCode: `19`
- Core reconciliation baseline: Virii8 Ecosystem Core `1.6.1266`
- Samsung Health Data SDK: `1.1.0`

## Preserved production-candidate surfaces

- Setup wizard
- QR/deep-link pairing
- Manual pairing token entry
- AndroidKeyStore-secured token storage
- Samsung steps, sleep, heart, workout, nutrition/hydration, and body-metric readers
- Offline queue and retry
- Background sync controls
- Privacy dashboard
- Local revoke/clear controls
- Diagnostics export without bridge token
- Bottom navigation and responsive foldable/tablet layout
- Release signing/APK/AAB workflow prep
- Samsung approval/SHA-256 prep
- Privacy/support/store/data-safety metadata prep

## Virii8 Core expectations

The companion expects these Core routes to be available and private/token-governed as classified by Core manifests:

```text
GET  /wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/status
POST /wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/pairing-token
POST /wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/sync
GET  /wp-json/v8e/v1/personal-health/bridge/devices
POST /wp-json/v8e/v1/personal-health/bridge/devices/{id}/revoke
GET  /wp-json/v8e/v1/personal-health/data-visibility
```

## Required gates before external production distribution

1. Build/install the debug APK for private smoke testing.
2. Build signed release APK/AAB using private keystore material.
3. Capture release SHA-256 and register it for Samsung approval.
4. Confirm Samsung approval for the production package, not the debug package.
5. Pair against Core `1.6.1266`.
6. Run status, sync, offline retry, background policy, privacy, diagnostics, and revoke tests.
7. Confirm Core Companion devices and Imported data map panels reflect the test device and inserted rows.
8. Confirm no bridge token appears in diagnostics, screenshots, logs, or public output.
9. Confirm privacy/support URLs are final and accessible.
10. Keep rollback path to previous Core and Android source ZIPs.

## Known limitation

This package is source-only. APK/AAB artifacts must be built in GitHub Actions or a local Android SDK/Gradle environment.
