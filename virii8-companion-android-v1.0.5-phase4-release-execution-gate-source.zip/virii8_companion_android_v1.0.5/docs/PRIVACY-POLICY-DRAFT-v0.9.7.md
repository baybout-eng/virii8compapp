# Virii8 Companion v0.9.7 Privacy Policy Draft Notes

Status: production privacy/support/store metadata prep candidate. This is a drafting aid, not a final legal policy.

## Product identity

- App label: Virii8 Companion
- Production package: `com.miltonmarketing.virii8.health`
- Debug/private-test package: `com.miltonmarketing.virii8.health.debug`
- Owner/site context: MiltonMarketing.com / Virii8 Ecosystem
- Primary purpose: private Samsung Health to Virii8 Core health-data bridge

## What the app does

Virii8 Companion reads Samsung Health data on the Android device only after the user grants Samsung Health permissions. It then sends selected health records to the user’s private Virii8 Core health bridge endpoint using a local bridge token.

Virii8 Companion is a bridge, not a medical device, not emergency monitoring, and not a replacement for professional medical advice, diagnosis, or treatment.

## Data that may be processed

Depending on user-selected categories and Samsung permission approval, the app may process:

- Steps/activity summaries
- Sleep sessions and sleep stages
- Sleep-related oxygen/temperature values where Samsung exposes them
- Heart-rate records
- Workout/exercise summaries
- Nutrition records
- Water/hydration records
- Blood pressure records
- Blood glucose records
- Body temperature records
- Body composition records

Current candidate boundary: workout GPS route coordinates are not synced.

## Local device data

The app may store locally:

- Virii8 site URL
- Device label
- Encrypted bridge token
- Selected sync categories
- Theme/layout preferences
- Background sync preferences
- Sync history/status text
- Offline queued sync payloads when network/Virii8 is unavailable
- Sanitized diagnostics text

Diagnostics and privacy summaries intentionally exclude the bridge token.

## Server-side data

Virii8 Core controls imported health records, server-side bridge tokens, audit logs, tenant/user boundaries, retention policy, dashboards, analytics, and server-side deletion/revocation. Clearing local app data does not delete records already imported into Virii8 Core.

## Sharing and third parties

The app reads from Samsung Health on-device and sends data to the configured Virii8 Core site. It does not write back to Samsung Health in this candidate.

Any public production policy must explicitly document hosting, backups, analytics, provider integrations, legal retention, support access, and any administrator access model used by Virii8 Core.

## User controls

The app provides controls for:

- Selecting health categories
- Opening Samsung Health permission/settings screens
- Running manual sync
- Configuring conservative background sync
- Viewing/clearing local sync history
- Viewing/clearing local offline queue
- Revoking the local bridge token
- Clearing all local companion data
- Exporting diagnostics without the bridge token

Server-side revocation/deletion must be handled in Virii8 Core.

## Production blockers before public distribution

- Publish a final privacy policy at `https://miltonmarketing.com/privacy-policy/` or the configured site equivalent.
- Publish support/contact process at `https://miltonmarketing.com/contact/` or the configured site equivalent.
- Confirm Samsung approval for the final release package and release SHA-256.
- Confirm release signing and artifact provenance.
- Confirm real-device smoke test on Samsung hardware with Samsung Health installed.
- Confirm Virii8 Core retention/deletion/revocation UX is implemented and documented.
