# Virii8 Companion Android v0.9.0 — Private Testing Checklist

Status: private testing candidate, not production/store release.

## Install freshness
- Uninstall any older Virii8 Companion / Virii8 Health debug APK.
- Install the newest GitHub Actions artifact APK.
- Confirm the app header shows `v0.9.0 private testing candidate`.

## Device and display
- Test portrait and landscape.
- Test narrow phone mode and wide/foldable/tablet mode if available.
- Confirm bottom navigation remains reachable and cards do not overflow.

## Pairing
- Test manual Virii8 site/token/device label pairing.
- Test QR/deep-link import if Virii8 Core provides a pairing payload.
- Confirm diagnostics do not include the bridge token.

## Samsung permissions
- Grant one category at a time first.
- Then test all enabled categories together.
- Deny at least one category and confirm the app reports that state cleanly.

## Sync
- Run Sync Today with data available in Samsung Health.
- Confirm Virii8 Core receives records for enabled categories.
- Confirm no private data is visible on public WordPress routes.

## Offline queue
- Disable network.
- Run Sync Today.
- Confirm offline queue count increases.
- Re-enable network.
- Tap Retry Queued Sync and confirm queue decreases after successful send.

## Background sync
- Keep manual-only as the baseline.
- Test daily or six-hour only after manual sync works.
- Test Wi-Fi-only and charging-only constraints.

## Privacy
- Review privacy dashboard.
- Open Samsung Health permissions/settings.
- Revoke local bridge token.
- Clear local companion data.
- Confirm server-side records remain controlled by Virii8 Core.

## Known limitations
- This is a debug/private-testing APK.
- Samsung approval/signature/package registration is still required for production SDK authorization.
- Store signing, privacy policy, release notes, and AAB generation are future production-readiness passes.
