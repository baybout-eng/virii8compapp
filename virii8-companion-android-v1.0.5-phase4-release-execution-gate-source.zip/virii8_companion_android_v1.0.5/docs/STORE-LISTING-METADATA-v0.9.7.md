# Virii8 Companion v0.9.7 Store / Distribution Metadata Draft

Status: production store/distribution metadata prep candidate. Not final public listing copy.

## App name

Virii8 Companion

## Short description

Private Samsung Health bridge for Virii8 Health workspace sync.

## Full description draft

Virii8 Companion connects Samsung Health on your Android device to your private Virii8 Health workspace. After you approve Samsung Health permissions, the companion can securely sync selected wellness and fitness records to Virii8 Core for private dashboards, history, and insights.

Supported candidate categories include steps, sleep, heart rate, workouts, nutrition, hydration, blood pressure, blood glucose, body temperature, and body composition, depending on Samsung Health availability and permissions.

Virii8 Companion is a private data bridge. It is not medical advice, diagnosis, treatment, emergency monitoring, or a replacement for Samsung Health or professional care.

## Keywords / tags

Samsung Health, health data, wellness, private workspace, Virii8, fitness sync, sleep tracking, heart rate, workouts, health dashboard

## Category suggestion

Health & Fitness / Productivity companion, depending on distribution channel.

## Distribution notes

- For private/internal testing: debug APK can be used with test devices only.
- For external distribution: use signed release APK/AAB only.
- Production Samsung approval must use package `com.miltonmarketing.virii8.health` and the release SHA-256 fingerprint.
- Do not distribute builds signed with unknown/debug credentials as production.

## Screenshots to capture later

- Setup wizard
- QR pairing/import screen
- Category selection
- Sync/queue screen
- Privacy dashboard
- Help/diagnostics screen
- Samsung approval/store metadata card
- Tablet/foldable layout
