# Virii8 Companion v0.9.7 Support Metadata

Status: production support metadata prep candidate.

## Recommended public support URL

`https://miltonmarketing.com/contact/`

## Recommended support email / contact handling

Use the site’s existing MiltonMarketing/Virii8 support intake. Do not ask users to send bridge tokens, keystores, passwords, or raw private health exports through normal support channels.

## Support categories

1. Pairing and QR/deep-link problems
2. Samsung Health permission problems
3. No records returned from Samsung Health
4. Virii8 bridge endpoint errors
5. Offline queue/retry problems
6. Background sync not running as expected
7. Privacy/deletion/revocation questions
8. Release build/signing/Samsung approval problems

## Safe diagnostics instructions

Use the in-app Share Diagnostics feature. It excludes the bridge token by design. Review diagnostics for:

- App version
- Package name
- Device model
- Android SDK
- Paired state
- Virii8 site
- Selected categories
- Last sync result
- Offline queue count
- Background sync state
- Samsung approval/store metadata status

## Escalation rules

Escalate to Virii8 Core/admin review when the issue involves:

- Imported server-side health records
- Server-side token revocation
- Retention/legal hold
- Tenant or person boundary
- REST bridge access/audit logs
- Workspace dashboard data mismatch

Escalate to Android app review when the issue involves:

- APK install/update failure
- Samsung Health permission UX
- Android background scheduling
- Offline queue behavior
- Diagnostics export
- Local app settings
