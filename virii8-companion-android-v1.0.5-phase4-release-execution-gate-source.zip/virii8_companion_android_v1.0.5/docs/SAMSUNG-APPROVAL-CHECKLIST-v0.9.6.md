# Virii8 Companion v0.9.6 Samsung Approval Checklist

## Identity

- [ ] Confirm app label is `Virii8 Companion`.
- [ ] Confirm production package is `com.miltonmarketing.virii8.health`.
- [ ] Confirm debug/private-test package is not submitted as production.
- [ ] Confirm versionName `0.9.6` and versionCode `17`.

## Signing

- [ ] Generate private release keystore.
- [ ] Configure `keystore.properties` locally or GitHub release secrets.
- [ ] Build release APK/AAB.
- [ ] Run `./scripts/print-signing-fingerprints.sh`.
- [ ] Record release SHA-256.
- [ ] Register release SHA-256 with Samsung.
- [ ] Keep keystore/passwords out of GitHub.

## Samsung Health permissions

- [ ] Steps/activity permission prompt appears.
- [ ] Sleep permission prompt appears.
- [ ] Heart-rate permission prompt appears.
- [ ] Exercise/workout permission prompt appears.
- [ ] Nutrition and water intake permission prompt appears.
- [ ] Body metrics permission prompts appear where supported.
- [ ] User can revoke permissions in Samsung Health settings.

## Privacy and data boundaries

- [ ] App describes read-only Samsung Health access.
- [ ] Diagnostics exclude bridge token.
- [ ] Approval summary excludes bridge token.
- [ ] Workout GPS route coordinates are not synced.
- [ ] Virii8 Core owns server-side token revocation, retention, tenant boundary, and audit.

## Real-device smoke test

- [ ] Install signed release APK on Samsung device.
- [ ] Pair to Virii8 Core.
- [ ] Request selected Samsung permissions.
- [ ] Run Sync Today.
- [ ] Confirm Virii8 Core status/sync endpoints respond.
- [ ] Confirm records appear in Virii8 Health workspace/admin surfaces.
- [ ] Export diagnostics and confirm no token/secrets.
- [ ] Test offline queue and retry.

## Not complete until

- [ ] Samsung approval is granted.
- [ ] Production privacy policy/support contact are finalized.
- [ ] Final v1.0.0 release package passes real-device testing.
