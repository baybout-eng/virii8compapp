# Virii8 Companion v0.9.7 Distribution Checklist

## Before private test install

- [ ] Build the debug APK from GitHub Actions or Android Studio.
- [ ] Install on Samsung test device.
- [ ] Confirm header shows `v0.9.7 privacy/support prep`.
- [ ] Pair with Virii8 Core bridge token.
- [ ] Request Samsung Health permissions.
- [ ] Run Sync Today.
- [ ] Test offline queue and retry.
- [ ] Export diagnostics and confirm no bridge token appears.

## Before signed release build

- [ ] Generate private release keystore.
- [ ] Store release secrets in GitHub repository secrets or local-only `keystore.properties`.
- [ ] Build release APK/AAB.
- [ ] Print and archive release SHA-256 fingerprint.
- [ ] Confirm production package is `com.miltonmarketing.virii8.health`.

## Before Samsung approval submission

- [ ] Submit production package and release SHA-256.
- [ ] Include Samsung Health Data SDK category explanation.
- [ ] Include privacy policy URL.
- [ ] Include support URL.
- [ ] Include screenshots if required.
- [ ] Keep debug package separate from production approval.

## Before public/client distribution

- [ ] Publish final privacy policy.
- [ ] Publish support/contact flow.
- [ ] Verify Virii8 Core token revocation device dashboard.
- [ ] Verify Virii8 Core imported-record deletion/retention handling.
- [ ] Complete real Samsung device smoke test.
- [ ] Confirm no secrets in repo, APK logs, diagnostics, docs, screenshots, or frontend output.
