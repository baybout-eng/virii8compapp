# Virii8 Companion Android v1.0.4 Release Build / Signing / Evidence Readiness

Status: Phase 3 release artifact evidence candidate, not release-safe.

## What this pass hardens

- Preserves Phase 2 release signing guardrails: release APK/AAB Gradle tasks require signing inputs; debug builds remain allowed.
- Fixes the README ZIP workflow source filename to the current v1.0.4 Phase 3 source package.
- Adds a release evidence collector that packages signed artifacts, SHA-256 checksums, certificate/signing evidence, and a human-readable evidence README.
- Updates repository and ZIP-based GitHub workflows to upload a release evidence artifact when signed APK/AAB files are produced.
- Keeps release-safe blocked until actual build/signing/device/Core runtime gates pass.

## Local build commands

```bash
./build-debug-apk.sh

cp keystore.properties.example keystore.properties
# edit keystore.properties privately; never commit it
./build-release-local.sh
```

## Evidence output after a signed release build

```text
release/verification-v1.0.4/RELEASE-ARTIFACT-VERIFICATION.txt
release/verification-v1.0.4/RELEASE-ARTIFACTS.sha256
release/evidence-v1.0.4/
```

## Required external gates

- Gradle dependency resolution and Java compile on a machine with Android SDK access.
- Signed APK/AAB generation.
- SHA-256 release fingerprint registration with Samsung.
- Real Samsung-device smoke testing with Samsung Health installed.
- WordPress staging activation and live Health bridge route classification.

Do not declare final release-safe from this source package alone.
