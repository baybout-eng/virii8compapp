Virii8 Companion v0.9.7 store/distribution metadata package.
This package is a prep bundle, not final legal/store approval.
Verify public privacy/support URLs, Samsung approval, release signing, and real-device smoke tests before distribution.
