# Local release signing folder

Place your local release keystore here only on your private build machine if you are building release APK/AAB locally.

Do not commit keystore files. The root `.gitignore` blocks common keystore formats and `keystore.properties`.
