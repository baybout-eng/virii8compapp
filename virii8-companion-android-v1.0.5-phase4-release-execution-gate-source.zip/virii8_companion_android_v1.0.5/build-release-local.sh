#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

chmod +x ./gradlew scripts/*.sh 2>/dev/null || true
./scripts/verify-build-environment.sh
./scripts/verify-source-package.sh
./scripts/print-signing-fingerprints.sh
./gradlew --no-daemon clean printSigningStatus verifyReleaseSigningInputs assembleRelease bundleRelease
./scripts/verify-release-artifacts.sh
./scripts/collect-release-evidence-package.sh
./scripts/assert-release-evidence-complete.sh

printf '\nRelease APK output:\n'
find app/build/outputs/apk/release -maxdepth 2 -type f 2>/dev/null | sort || true
printf '\nRelease AAB output:\n'
find app/build/outputs/bundle/release -maxdepth 2 -type f 2>/dev/null | sort || true
printf '\nRelease evidence output:\n'
find release/evidence-v1.0.5 -maxdepth 2 -type f 2>/dev/null | sort || true
