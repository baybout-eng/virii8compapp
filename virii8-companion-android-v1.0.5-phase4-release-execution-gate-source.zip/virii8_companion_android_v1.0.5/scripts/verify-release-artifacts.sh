#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

APK_DIR="app/build/outputs/apk/release"
AAB_DIR="app/build/outputs/bundle/release"
OUT_DIR="release/verification-v1.0.5"
REPORT="$OUT_DIR/RELEASE-ARTIFACT-VERIFICATION.txt"
CHECKSUMS="$OUT_DIR/RELEASE-ARTIFACTS.sha256"

find_artifacts() {
  find "$APK_DIR" "$AAB_DIR" -type f \( -name '*.apk' -o -name '*.aab' \) 2>/dev/null | sort
}

ARTIFACTS="$(find_artifacts || true)"
if [ -z "$ARTIFACTS" ]; then
  echo 'No release APK/AAB artifacts found. Run build-release-local.sh or the release workflow after configuring signing.' >&2
  exit 1
fi

mkdir -p "$OUT_DIR"
: > "$CHECKSUMS"
{
  echo 'Virii8 Companion Android v1.0.5 release artifact verification'
  echo "Generated UTC: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  echo 'Application ID: com.miltonmarketing.virii8.health'
  echo 'Version: 1.0.5 / versionCode 24'
  echo 'Expected artifacts: signed release APK and/or signed release AAB'
  echo
  echo 'Artifact SHA-256:'
} > "$REPORT"

resolve_apksigner() {
  if command -v apksigner >/dev/null 2>&1; then
    command -v apksigner
    return 0
  fi
  if [ -n "${ANDROID_HOME:-}" ]; then
    find "$ANDROID_HOME/build-tools" -type f -name apksigner 2>/dev/null | sort -V | tail -n 1 && return 0
  fi
  if [ -n "${ANDROID_SDK_ROOT:-}" ]; then
    find "$ANDROID_SDK_ROOT/build-tools" -type f -name apksigner 2>/dev/null | sort -V | tail -n 1 && return 0
  fi
  return 1
}

APKSIGNER="$(resolve_apksigner || true)"

printf '%s\n' "$ARTIFACTS" | while IFS= read -r artifact; do
  [ -n "$artifact" ] || continue
  sha256sum "$artifact" | tee -a "$REPORT" >> "$CHECKSUMS"
  echo >> "$REPORT"
  echo "Signing / certificate evidence for $artifact:" >> "$REPORT"
  case "$artifact" in
    *.apk)
      if [ -n "$APKSIGNER" ]; then
        "$APKSIGNER" verify --print-certs "$artifact" >> "$REPORT" 2>&1 || echo 'apksigner verification failed; investigate before release.' >> "$REPORT"
      elif command -v keytool >/dev/null 2>&1; then
        keytool -printcert -jarfile "$artifact" 2>/dev/null | grep -E 'Owner:|Issuer:|SHA1:|SHA256:' >> "$REPORT" || echo 'Certificate details unavailable via keytool. Use apksigner verify --print-certs when Android build-tools are available.' >> "$REPORT"
      else
        echo 'Neither apksigner nor keytool is available.' >> "$REPORT"
      fi
      ;;
    *.aab)
      if command -v keytool >/dev/null 2>&1; then
        keytool -printcert -jarfile "$artifact" 2>/dev/null | grep -E 'Owner:|Issuer:|SHA1:|SHA256:' >> "$REPORT" || echo 'AAB certificate details unavailable via keytool. Verify in Play/Samsung tooling before release.' >> "$REPORT"
      else
        echo 'keytool unavailable for AAB certificate inspection.' >> "$REPORT"
      fi
      ;;
  esac
  echo >> "$REPORT"
done

cat "$REPORT"
echo
echo "Wrote checksum file: $CHECKSUMS"
