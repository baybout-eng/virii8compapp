#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

printf 'Virii8 Companion Android v1.0.5 Phase 4 release execution gate\n'
printf 'This gate requires Android SDK, Java 17, Gradle wrapper access, and configured release signing.\n\n'

chmod +x ./gradlew scripts/*.sh 2>/dev/null || true
./scripts/verify-build-environment.sh
./scripts/verify-source-package.sh
./scripts/print-signing-fingerprints.sh
./gradlew --no-daemon clean printSigningStatus verifyReleaseSigningInputs assembleRelease bundleRelease
./scripts/verify-release-artifacts.sh
./scripts/collect-release-evidence-package.sh
./scripts/assert-release-evidence-complete.sh
