#!/usr/bin/env bash
set -euo pipefail

KEYSTORE_PATH="${1:-release/virii8-companion-release.keystore}"
ALIAS="${2:-virii8-companion}"
VALIDITY_DAYS="${3:-10000}"

mkdir -p "$(dirname "$KEYSTORE_PATH")"

cat <<MSG
This creates a local Android release keystore.
Keep this file private. Losing it can prevent future updates with the same signing identity.

Keystore path: $KEYSTORE_PATH
Key alias:      $ALIAS
Validity days:  $VALIDITY_DAYS
MSG

keytool -genkeypair \
  -v \
  -keystore "$KEYSTORE_PATH" \
  -alias "$ALIAS" \
  -keyalg RSA \
  -keysize 4096 \
  -validity "$VALIDITY_DAYS"

cat <<MSG

Created: $KEYSTORE_PATH
Next:
1. Copy keystore.properties.example to keystore.properties.
2. Set storeFile=$KEYSTORE_PATH
3. Set storePassword/keyAlias/keyPassword.
4. Run ./gradlew --no-daemon printSigningStatus assembleRelease bundleRelease
MSG
