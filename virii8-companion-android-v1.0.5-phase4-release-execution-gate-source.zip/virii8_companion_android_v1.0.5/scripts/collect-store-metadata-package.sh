#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
OUT_DIR="$ROOT_DIR/release/store-metadata-v1.0.5"
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"

copy_required() {
  local src="$1"
  if [ ! -f "$ROOT_DIR/$src" ]; then
    echo "Required metadata file missing: $src" >&2
    exit 1
  fi
  cp "$ROOT_DIR/$src" "$OUT_DIR/"
}

copy_required docs/PRIVACY-POLICY-DRAFT-v0.9.7.md
copy_required docs/SUPPORT-CONTACTS-v0.9.7.md
copy_required docs/STORE-LISTING-METADATA-v0.9.7.md
copy_required docs/DATA-SAFETY-FORM-v0.9.7.md
copy_required docs/DISTRIBUTION-CHECKLIST-v0.9.7.md
copy_required docs/SAMSUNG-APP-REGISTRATION-v0.9.6.md
copy_required docs/SAMSUNG-APPROVAL-CHECKLIST-v0.9.6.md
cat > "$OUT_DIR/README.txt" <<'README_EOF'
Virii8 Companion v1.0.5 store/distribution metadata package.
This package is a prep bundle, not final legal/store approval.
Verify public privacy/support URLs, Samsung approval, release signing, and real-device smoke tests before distribution.
README_EOF
find "$OUT_DIR" -maxdepth 1 -type f -printf '%f
' | sort
