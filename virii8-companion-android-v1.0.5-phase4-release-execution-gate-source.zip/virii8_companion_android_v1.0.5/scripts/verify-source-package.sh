#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

grep -n "versionCode 24" app/build.gradle
grep -n "versionName '1.0.5'" app/build.gradle
grep -n 'APP_VERSION = "1.0.5"' app/src/main/java/com/miltonmarketing/virii8/health/MainActivity.java
grep -n 'APP_VERSION_CODE = 24' app/src/main/java/com/miltonmarketing/virii8/health/MainActivity.java
grep -n "verifyReleaseSigningInputs" app/build.gradle
test -f app/libs/samsung-health-data-api-1.1.0.aar
test -f docs/GITHUB-ACTIONS-ZIP-RELEASE-v1.0.5.yml
test -f docs/RELEASE-BUILD-READINESS-v1.0.5.md
test -f docs/RELEASE-ARTIFACT-WORKFLOW-v1.0.5.md
test -f docs/RELEASE-EXECUTION-GATE-v1.0.5.md
test -f docs/PATCH-REPORT-v1.0.5.txt
test -f docs/FILE-MANIFEST-v1.0.5.txt
test -f scripts/verify-build-environment.sh
test -f scripts/verify-release-artifacts.sh
test -f scripts/collect-release-evidence-package.sh
test -f scripts/assert-release-evidence-complete.sh
test -f scripts/phase4-release-execution-gate.sh
test -f scripts/print-signing-fingerprints.sh
test -f keystore.properties.example
printf 'Virii8 Companion Android v1.0.5 source package markers verified.\n'
