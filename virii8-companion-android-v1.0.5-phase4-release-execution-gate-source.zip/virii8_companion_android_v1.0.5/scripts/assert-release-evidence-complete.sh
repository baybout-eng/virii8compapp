#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

VERSION="1.0.5"
VERSION_CODE="24"
APP_ID="com.miltonmarketing.virii8.health"
VERIFY_DIR="release/verification-v${VERSION}"
EVIDENCE_DIR="release/evidence-v${VERSION}"
ARTIFACT_DIR="$EVIDENCE_DIR/artifacts"
REPORT="$VERIFY_DIR/RELEASE-ARTIFACT-VERIFICATION.txt"
ARTIFACT_SUMS="$VERIFY_DIR/RELEASE-ARTIFACTS.sha256"
EVIDENCE_SUMS="$EVIDENCE_DIR/EVIDENCE-BUNDLE.sha256"

fail() {
  echo "Release evidence gate failed: $*" >&2
  exit 1
}

printf 'Virii8 Companion Android v%s release evidence gate\n' "$VERSION"

[ -d "$VERIFY_DIR" ] || fail "verification directory missing: $VERIFY_DIR"
[ -d "$EVIDENCE_DIR" ] || fail "evidence directory missing: $EVIDENCE_DIR"
[ -d "$ARTIFACT_DIR" ] || fail "evidence artifacts directory missing: $ARTIFACT_DIR"
[ -s "$REPORT" ] || fail "verification report missing or empty: $REPORT"
[ -s "$ARTIFACT_SUMS" ] || fail "artifact checksum file missing or empty: $ARTIFACT_SUMS"
[ -s "$EVIDENCE_SUMS" ] || fail "evidence bundle checksum file missing or empty: $EVIDENCE_SUMS"
[ -s "$EVIDENCE_DIR/README-RELEASE-EVIDENCE.txt" ] || fail "evidence README missing"
[ -s "$EVIDENCE_DIR/SIGNING-FINGERPRINTS.txt" ] || fail "signing fingerprints file missing"

APK_COUNT="$(find "$ARTIFACT_DIR" -maxdepth 1 -type f -name '*.apk' | wc -l | tr -d ' ')"
AAB_COUNT="$(find "$ARTIFACT_DIR" -maxdepth 1 -type f -name '*.aab' | wc -l | tr -d ' ')"
[ "$APK_COUNT" -ge 1 ] || fail "no release APK copied into evidence artifacts"
[ "$AAB_COUNT" -ge 1 ] || fail "no release AAB copied into evidence artifacts"

grep -q "Application ID: $APP_ID" "$REPORT" || fail "verification report does not name expected application ID"
grep -q "Version: ${VERSION} / versionCode ${VERSION_CODE}" "$REPORT" || fail "verification report does not name expected version/versionCode"
grep -qi 'SHA-256\|SHA256' "$REPORT" || fail "verification report does not contain SHA-256/SHA256 evidence"
grep -q "Application ID: $APP_ID" "$EVIDENCE_DIR/README-RELEASE-EVIDENCE.txt" || fail "evidence README does not name expected application ID"
grep -q "Version: ${VERSION} / versionCode ${VERSION_CODE}" "$EVIDENCE_DIR/README-RELEASE-EVIDENCE.txt" || fail "evidence README does not name expected version/versionCode"

# Verify artifact checksums against the original Gradle output paths.
sha256sum -c "$ARTIFACT_SUMS" >/dev/null || fail "release artifact checksum verification failed"
# Verify packaged evidence checksums inside the evidence directory.
( cd "$EVIDENCE_DIR" && sha256sum -c EVIDENCE-BUNDLE.sha256 >/dev/null ) || fail "evidence bundle checksum verification failed"

# Redaction scan: evidence files must not contain private bridge/server credentials.
SENSITIVE_PATTERNS='bridge_token|oauth_token|refresh_token|access_token|client_secret|storePassword|keyPassword|raw_json|Authorization: Bearer|V8_RELEASE_STORE_PASSWORD|V8_RELEASE_KEY_PASSWORD'
if grep -RIEin "$SENSITIVE_PATTERNS" "$EVIDENCE_DIR" "$VERIFY_DIR" >/tmp/virii8-evidence-sensitive-hits.txt 2>/dev/null; then
  cat /tmp/virii8-evidence-sensitive-hits.txt >&2
  fail "potential secret/private payload text found in release evidence"
fi
rm -f /tmp/virii8-evidence-sensitive-hits.txt

printf 'Release evidence gate passed. APKs: %s, AABs: %s\n' "$APK_COUNT" "$AAB_COUNT"
printf 'Evidence directory: %s\n' "$EVIDENCE_DIR"
