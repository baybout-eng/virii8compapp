#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

printf 'Virii8 Companion Android v1.0.5 build environment check
'
command -v java >/dev/null || { echo 'java not found. Install Java 17.' >&2; exit 1; }
command -v keytool >/dev/null || { echo 'keytool not found. Install a JDK, not only a JRE.' >&2; exit 1; }
command -v unzip >/dev/null || { echo 'unzip not found.' >&2; exit 1; }
command -v sha256sum >/dev/null || { echo 'sha256sum not found.' >&2; exit 1; }

JAVA_VERSION_OUTPUT="$(java -version 2>&1 | head -n 1)"
printf 'Java: %s
' "$JAVA_VERSION_OUTPUT"
case "$JAVA_VERSION_OUTPUT" in
  *'17.'*|*'version "17'*|*'openjdk 17'*) ;;
  *) echo 'WARNING: Java 17 is required by this Android project. Current java -version did not clearly report 17.' >&2 ;;
esac

test -f settings.gradle || { echo 'settings.gradle missing. Run from project root.' >&2; exit 1; }
test -f app/build.gradle || { echo 'app/build.gradle missing.' >&2; exit 1; }
test -f gradlew || { echo 'gradlew missing.' >&2; exit 1; }
chmod +x ./gradlew
printf 'Gradle wrapper: present
'

if [ -n "${ANDROID_HOME:-}" ]; then
  printf 'ANDROID_HOME: %s
' "$ANDROID_HOME"
elif [ -n "${ANDROID_SDK_ROOT:-}" ]; then
  printf 'ANDROID_SDK_ROOT: %s
' "$ANDROID_SDK_ROOT"
else
  echo 'WARNING: ANDROID_HOME/ANDROID_SDK_ROOT is not set. GitHub Actions setup-android or Android Studio usually supplies it.' >&2
fi

printf 'Build environment preflight complete.
'
