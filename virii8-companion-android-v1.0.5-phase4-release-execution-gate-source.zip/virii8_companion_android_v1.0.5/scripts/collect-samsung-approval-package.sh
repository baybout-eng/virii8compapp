#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

OUT_DIR="release/samsung-approval-v1.0.5"
rm -rf "$OUT_DIR"
mkdir -p "$OUT_DIR"

{
  echo "Virii8 Companion Samsung Approval Package"
  echo "Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  echo
  echo "App label: Virii8 Companion"
  echo "Production package: com.miltonmarketing.virii8.health"
  echo "Debug package: com.miltonmarketing.virii8.health.debug"
  echo "Version: 1.0.5 / versionCode 24"
  echo "Samsung SDK: Samsung Health Data SDK 1.1.0"
  echo "Android SDK: minSdk 29 / targetSdk 34 / compileSdk 34"
  echo
  echo "Samsung approval docs:"
  echo "- docs/SAMSUNG-APP-REGISTRATION-v0.9.6.md"
  echo "- docs/SAMSUNG-APPROVAL-CHECKLIST-v0.9.6.md"
  echo
  echo "Signing fingerprints:"
} > "$OUT_DIR/SAMSUNG-APPROVAL-SUMMARY.txt"
./scripts/print-signing-fingerprints.sh >> "$OUT_DIR/SAMSUNG-APPROVAL-SUMMARY.txt" || true
cp docs/SAMSUNG-APP-REGISTRATION-v0.9.6.md "$OUT_DIR/"
cp docs/SAMSUNG-APPROVAL-CHECKLIST-v0.9.6.md "$OUT_DIR/"
cat "$OUT_DIR/SAMSUNG-APPROVAL-SUMMARY.txt"
