#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."

VERSION="1.0.5"
VERSION_CODE="24"
APP_ID="com.miltonmarketing.virii8.health"
EVIDENCE_DIR="release/evidence-v${VERSION}"
VERIFY_DIR="release/verification-v${VERSION}"
ARTIFACT_DIR="$EVIDENCE_DIR/artifacts"

mkdir -p "$ARTIFACT_DIR"

# Ensure verification exists and matches the current release artifacts.
./scripts/verify-release-artifacts.sh >/dev/null

find app/build/outputs/apk/release app/build/outputs/bundle/release -type f \( -name '*.apk' -o -name '*.aab' \) 2>/dev/null | sort | while read -r artifact; do
  cp "$artifact" "$ARTIFACT_DIR/"
done

cp "$VERIFY_DIR/RELEASE-ARTIFACT-VERIFICATION.txt" "$EVIDENCE_DIR/"
cp "$VERIFY_DIR/RELEASE-ARTIFACTS.sha256" "$EVIDENCE_DIR/"
./scripts/print-signing-fingerprints.sh > "$EVIDENCE_DIR/SIGNING-FINGERPRINTS.txt" || true

{
  echo "Virii8 Companion Android v${VERSION} release evidence package"
  echo "Generated UTC: $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  echo "Application ID: $APP_ID"
  echo "Version: ${VERSION} / versionCode ${VERSION_CODE}"
  echo "Source package: virii8-companion-android-v1.0.5-phase4-release-execution-gate-source.zip"
  echo
  echo 'Included evidence:'
  echo '- artifacts/*.apk and/or artifacts/*.aab copied from Gradle release outputs'
  echo '- RELEASE-ARTIFACT-VERIFICATION.txt'
  echo '- RELEASE-ARTIFACTS.sha256'
  echo '- SIGNING-FINGERPRINTS.txt'
  echo
  echo 'Still required before release-safe:'
  echo '- Register release SHA-256 with Samsung approval path.'
  echo '- Install and smoke-test on a real Samsung device with Samsung Health installed.'
  echo '- Verify Virii8 Core staging routes, cache/WAF no-store, tenant/person checks, and imported-data visibility.'
  echo '- Archive this evidence package with the exact source ZIP and docs bundle used to build it.'
} > "$EVIDENCE_DIR/README-RELEASE-EVIDENCE.txt"

( cd "$EVIDENCE_DIR" && sha256sum artifacts/* RELEASE-ARTIFACT-VERIFICATION.txt RELEASE-ARTIFACTS.sha256 SIGNING-FINGERPRINTS.txt README-RELEASE-EVIDENCE.txt 2>/dev/null | sort > EVIDENCE-BUNDLE.sha256 )

find "$EVIDENCE_DIR" -maxdepth 2 -type f | sort
