#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
chmod +x ./gradlew scripts/*.sh 2>/dev/null || true
./scripts/verify-build-environment.sh
./scripts/verify-source-package.sh
./gradlew --no-daemon clean printSigningStatus assembleDebug
printf 'Debug APK output:
'
find app/build/outputs/apk/debug -maxdepth 2 -type f -name '*.apk' | sort
