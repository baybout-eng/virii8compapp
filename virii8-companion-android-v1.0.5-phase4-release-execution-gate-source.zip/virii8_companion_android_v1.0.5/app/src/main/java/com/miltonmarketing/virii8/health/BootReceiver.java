package com.miltonmarketing.virii8.health;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/** Re-applies the selected inexact background-sync policy after device reboot. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent != null && Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            SharedPreferences prefs = context.getSharedPreferences("virii8_health_companion_preferences", Context.MODE_PRIVATE);
            BackgroundSyncScheduler.apply(context.getApplicationContext(), prefs);
        }
    }
}
