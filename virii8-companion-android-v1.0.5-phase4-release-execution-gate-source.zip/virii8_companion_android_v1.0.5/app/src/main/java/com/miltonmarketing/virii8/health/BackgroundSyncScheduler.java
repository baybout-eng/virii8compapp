package com.miltonmarketing.virii8.health;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Small AlarmManager-based scheduler for the private/test companion APK.
 * Uses inexact alarms only; no exact-alarm permission required.
 */
final class BackgroundSyncScheduler {
    static final String ACTION_BACKGROUND_SYNC = "com.miltonmarketing.virii8.health.BACKGROUND_SYNC";
    private static final int REQUEST_CODE = 8806;

    private BackgroundSyncScheduler() {}

    static void apply(Context context, SharedPreferences prefs) {
        String mode = prefs.getString(MainActivity.KEY_BACKGROUND_MODE, MainActivity.MODE_MANUAL);
        boolean paused = prefs.getBoolean(MainActivity.KEY_BACKGROUND_PAUSED, false);
        AlarmManager alarms = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarms == null) return;
        PendingIntent pi = pendingIntent(context);
        alarms.cancel(pi);

        if (paused || MainActivity.MODE_MANUAL.equals(mode)) {
            prefs.edit().putString(MainActivity.KEY_BACKGROUND_NEXT_HINT, paused ? stamp() + " • paused" : "manual-only / not scheduled").apply();
            return;
        }

        long interval = MainActivity.MODE_SIX_HOUR.equals(mode)
            ? AlarmManager.INTERVAL_HOUR * 6L
            : AlarmManager.INTERVAL_DAY;
        long first = System.currentTimeMillis() + Math.min(AlarmManager.INTERVAL_HOUR, interval);
        alarms.setInexactRepeating(AlarmManager.RTC_WAKEUP, first, interval, pi);
        prefs.edit().putString(MainActivity.KEY_BACKGROUND_NEXT_HINT, stamp() + " • next in about " + describe(interval)).apply();
    }

    static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, BackgroundSyncReceiver.class).setAction(ACTION_BACKGROUND_SYNC);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (android.os.Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, REQUEST_CODE, intent, flags);
    }

    private static String describe(long interval) {
        if (interval <= AlarmManager.INTERVAL_HOUR * 7L) return "6 hours";
        return "1 day";
    }

    private static String stamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
    }
}
