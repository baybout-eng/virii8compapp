package com.miltonmarketing.virii8.health;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;

import java.text.SimpleDateFormat;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final String APP_VERSION = "1.0.5";
    static final int APP_VERSION_CODE = 24;
    private static final String PREFS = "virii8_health_companion_preferences";
    private static final String KEY_THEME = "theme";
    private static final String KEY_COMPACT = "compact_mode";
    private static final String KEY_ADVANCED = "advanced_notes";
    private static final String KEY_LAST_SYNC = "last_sync_summary";
    private static final String KEY_SETUP_STEP = "setup_step";
    private static final String KEY_SETUP_DONE = "setup_done";
    private static final String KEY_LAST_QR_PAIRING = "last_qr_pairing_summary";
    private static final String KEY_SYNC_HISTORY = "sync_history";
    private static final String KEY_LAST_DIAGNOSTICS_EXPORT = "last_diagnostics_export";
    private static final String KEY_PENDING_QUEUE = "pending_sync_queue";
    private static final String KEY_QUEUE_LAST_CHANGE = "pending_sync_queue_last_change";
    private static final String KEY_PRIVACY_ACK = "privacy_dashboard_acknowledged";
    private static final String KEY_LAST_PRIVACY_ACTION = "last_privacy_action";
    private static final String KEY_ACTIVE_TAB = "active_tab";
    private static final String KEY_LARGE_TEXT = "large_text_mode";
    private static final String KEY_STATUS_HELP = "plain_language_status_help";
    private static final String TAB_HOME = "home";
    private static final String TAB_SYNC = "sync";
    private static final String TAB_DATA = "data";
    private static final String TAB_PRIVACY = "privacy";
    private static final String TAB_HELP = "help";
    static final String KEY_BACKGROUND_MODE = "background_sync_mode";
    static final String KEY_BACKGROUND_WIFI_ONLY = "background_sync_wifi_only";
    static final String KEY_BACKGROUND_CHARGING_ONLY = "background_sync_charging_only";
    static final String KEY_BACKGROUND_PAUSED = "background_sync_paused";
    static final String KEY_BACKGROUND_LAST_RUN = "background_sync_last_run";
    static final String KEY_BACKGROUND_LAST_RESULT = "background_sync_last_result";
    static final String KEY_BACKGROUND_NEXT_HINT = "background_sync_next_hint";
    static final String MODE_MANUAL = "manual";
    static final String MODE_DAILY = "daily";
    static final String MODE_SIX_HOUR = "six_hour";
    private static final int HISTORY_LIMIT = 24;
    private static final int QUEUE_LIMIT = 12;

    private static final String CAT_STEPS = "steps";
    private static final String CAT_SLEEP = "sleep";
    private static final String CAT_HEART = "heart";
    private static final String CAT_WORKOUTS = "workouts";
    private static final String CAT_NUTRITION = "nutrition";
    private static final String CAT_BODY = "body_metrics";

    private static final String STATE_SITE = "state_site";
    private static final String STATE_DEVICE = "state_device";
    private static final String STATE_STATUS = "state_status";

    private int bg;
    private int panel;
    private int panelAlt;
    private int panelSoft;
    private int text;
    private int muted;
    private int accent;
    private int accent2;
    private int warning;
    private int danger;
    private String themeName;

    private SecureTokenStore tokenStore;
    private SamsungHealthBridge samsungBridge;
    private SharedPreferences prefs;
    private EditText siteUrl;
    private EditText pairingToken;
    private EditText deviceLabel;
    private EditText qrPayload;
    private TextView status;
    private TextView bridgeSummary;
    private TextView selectedCategoriesSummary;
    private String lastStatus = "Ready. Start the setup wizard, pair this phone with Virii8, choose Health Bridge categories, grant Samsung permissions, then run Sync Today. v1.0.5 is the production release candidate: it reconciles the Android companion with Virii8 Core 1.6.1266, preserves the Samsung Health Data SDK bridge, release signing, Samsung approval prep, privacy/support/store metadata, all health readers, encrypted offline queue, background sync, privacy dashboard, bottom navigation, and accessibility polish.";
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tokenStore = new SecureTokenStore(this);
        samsungBridge = new SamsungHealthBridge(this);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        ensureDefaultCategoryPrefs();
        BackgroundSyncScheduler.apply(this, prefs);

        PairingPayload incomingPairing = savedInstanceState == null ? parsePairingIntent(getIntent()) : null;
        String initialSite = savedInstanceState != null ? savedInstanceState.getString(STATE_SITE, tokenStore.getSiteUrl()) : firstNonEmpty(incomingPairing.siteUrl, tokenStore.getSiteUrl());
        String initialToken = savedInstanceState != null ? "" : firstNonEmpty(incomingPairing.token, "");
        String initialDevice = savedInstanceState != null ? savedInstanceState.getString(STATE_DEVICE, tokenStore.getDeviceLabel()) : firstNonEmpty(incomingPairing.deviceLabel, tokenStore.getDeviceLabel());
        String initialStatus = savedInstanceState != null ? savedInstanceState.getString(STATE_STATUS, lastStatus) : (incomingPairing.hasPairing() ? "QR/deep-link pairing loaded. Review the Virii8 site, token, and device label, then tap Save secure pairing." : lastStatus);
        buildUi(initialSite, initialToken, initialDevice, initialStatus);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        String currentSite = siteUrl != null ? siteUrl.getText().toString() : tokenStore.getSiteUrl();
        String currentToken = pairingToken != null ? pairingToken.getText().toString() : "";
        String currentDevice = deviceLabel != null ? deviceLabel.getText().toString() : tokenStore.getDeviceLabel();
        String currentStatus = status != null ? status.getText().toString() : lastStatus;
        buildUi(currentSite, currentToken, currentDevice, currentStatus + "\nAdaptive layout refreshed for " + layoutModeLabel() + ".");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        PairingPayload incomingPairing = parsePairingIntent(intent);
        if (incomingPairing.hasPairing()) {
            applyPairingPayload(incomingPairing, false);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (siteUrl != null) outState.putString(STATE_SITE, siteUrl.getText().toString());
        if (deviceLabel != null) outState.putString(STATE_DEVICE, deviceLabel.getText().toString());
        if (status != null) outState.putString(STATE_STATUS, status.getText().toString());
    }

    @Override
    protected void onDestroy() {
        networkExecutor.shutdownNow();
        super.onDestroy();
    }

    private void buildUi(String initialSite, String initialToken, String initialDevice, String initialStatus) {
        applyThemeFromPreferences();
        Configuration cfg = getResources().getConfiguration();
        int widthDp = Math.max(320, cfg.screenWidthDp);
        int heightDp = Math.max(320, cfg.screenHeightDp);
        int smallestDp = Math.max(0, cfg.smallestScreenWidthDp);
        boolean landscape = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE || widthDp > heightDp;
        boolean twoColumn = widthDp >= 520 || smallestDp >= 600 || (landscape && widthDp >= 430);
        boolean largeCanvas = widthDp >= 720 || smallestDp >= 720;
        boolean compact = widthDp < 380 || prefs.getBoolean(KEY_COMPACT, false);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        outer.setPadding(dp(compact ? 10 : 20), dp(landscape ? 10 : 22), dp(compact ? 10 : 20), dp(24));
        scroll.addView(outer, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int maxWidthPx = largeCanvas ? dp(1280) : LinearLayout.LayoutParams.MATCH_PARENT;
        LinearLayout.LayoutParams rootParams = new LinearLayout.LayoutParams(maxWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT);
        rootParams.gravity = Gravity.CENTER_HORIZONTAL;
        outer.addView(root, rootParams);

        String activeTab = activeTab();
        root.addView(header(twoColumn, compact, landscape));
        root.addView(tabHeroCard(activeTab));
        root.addView(readinessCard(activeTab));
        renderActiveTab(root, activeTab, twoColumn, widthDp, heightDp, smallestDp, landscape, compact, initialSite, initialToken, initialDevice);

        status = text("", compact ? 13 : 14, text, false);
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        status.setGravity(Gravity.START);
        status.setBackground(rounded(panel, dp(18), panelAlt, 1));
        root.addView(status, matchWrapBottom(0));

        setContentView(screenWithBottomNavigation(scroll, activeTab, compact));
        updateBridgeSummary();
        updateSelectedCategoriesSummary();
        refreshStatus(initialStatus == null || initialStatus.trim().isEmpty() ? lastStatus : initialStatus);
    }


    private void renderActiveTab(LinearLayout root, String activeTab, boolean twoColumn, int widthDp, int heightDp, int smallestDp, boolean landscape, boolean compact, String initialSite, String initialToken, String initialDevice) {
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(twoColumn ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        body.setGravity(Gravity.TOP);
        body.setLayoutParams(matchWrapBottom(dp(14)));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);

        if (twoColumn) {
            LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.05f);
            leftParams.setMargins(0, 0, dp(8), 0);
            LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.95f);
            rightParams.setMargins(dp(8), 0, 0, 0);
            body.addView(left, leftParams);
            body.addView(right, rightParams);
        } else {
            body.addView(left, matchWrapBottom(0));
            body.addView(right, matchWrapBottom(0));
        }

        if (TAB_SYNC.equals(activeTab)) {
            left.addView(actionsCard());
            left.addView(backgroundSyncCard());
            left.addView(syncHistoryCard());
            right.addView(bridgeStatusCard());
            right.addView(categoryCard());
            right.addView(dataCoverageCard());
        } else if (TAB_DATA.equals(activeTab)) {
            left.addView(categoryCard());
            left.addView(dataCoverageCard());
            right.addView(commandCenterCard(widthDp, heightDp, smallestDp, landscape, twoColumn));
            right.addView(linksCard());
        } else if (TAB_PRIVACY.equals(activeTab)) {
            left.addView(privacyCard());
            left.addView(backgroundSyncCard());
            right.addView(bridgeStatusCard());
            right.addView(syncHistoryCard());
        } else if (TAB_HELP.equals(activeTab)) {
            left.addView(linksCard());
            left.addView(platformRoadmapCard());
            left.addView(samsungApprovalCard());
            left.addView(productionMetadataCard());
            left.addView(finalReconciliationCard());
            left.addView(qaChecklistCard());
            right.addView(commandCenterCard(widthDp, heightDp, smallestDp, landscape, twoColumn));
            right.addView(customizationCard(compact));
            right.addView(syncHistoryCard());
            right.addView(errorStatesCard());
        } else {
            left.addView(setupWizardCard(twoColumn));
            left.addView(pairingCard(initialSite, initialToken, initialDevice));
            left.addView(customizationCard(compact));
            left.addView(firstRunPolishCard());
            right.addView(commandCenterCard(widthDp, heightDp, smallestDp, landscape, twoColumn));
            right.addView(bridgeStatusCard());
            right.addView(categoryCard());
        }

        root.addView(body);
    }

    private View tabHeroCard(String activeTab) {
        LinearLayout card = card(panelSoft);
        card.addView(sectionTitle(tabTitle(activeTab)));
        card.addView(text(tabBody(activeTab), 13, muted, false));
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, dp(10), 0, 0);
        row.addView(chip("Active section", tabShortLabel(activeTab), accent), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(chip("Navigation", "Bottom tabs", accent2), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(row);
        return card;
    }


    private View readinessCard(String activeTab) {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Readiness and next best action"));
        card.addView(text(nextBestActionText(), 13, muted, false));

        LinearLayout badges = new LinearLayout(this);
        badges.setOrientation(LinearLayout.HORIZONTAL);
        badges.setPadding(0, dp(8), 0, 0);
        badges.addView(chip("Pairing", tokenStore.isPaired() ? "Ready" : "Needed", tokenStore.isPaired() ? accent2 : warning), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        badges.addView(chip("Privacy", prefs.getBoolean(KEY_PRIVACY_ACK, false) ? "Acknowledged" : "Review", prefs.getBoolean(KEY_PRIVACY_ACK, false) ? accent2 : warning), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        badges.addView(chip("Network", isNetworkAvailable() ? "Online" : "Offline", isNetworkAvailable() ? accent2 : warning), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(badges);

        if (!prefs.getBoolean(KEY_SETUP_DONE, false) || !tokenStore.isPaired()) {
            Button guide = button("Continue setup guidance", accent, readableOn(accent));
            guide.setContentDescription("Continue setup guidance for pairing, categories, permissions, and first sync");
            guide.setOnClickListener(v -> {
                prefs.edit().putString(KEY_ACTIVE_TAB, TAB_HOME).apply();
                if (!tokenStore.isPaired()) prefs.edit().putInt(KEY_SETUP_STEP, 2).apply();
                rebuildFromCurrent("Setup guidance opened. Start with pairing this phone, then choose categories, grant permissions, and run Sync Today.");
            });
            card.addView(guide);
        }

        Button copy = button("Copy current status", panelAlt, text);
        copy.setOnClickListener(v -> copyToClipboard("Virii8 Companion status", lastStatus));
        card.addView(copy);
        return card;
    }

    private View screenWithBottomNavigation(ScrollView scroll, String activeTab, boolean compact) {
        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackgroundColor(bg);
        screen.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        screen.addView(bottomNavigation(activeTab, compact), new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return screen;
    }

    private View bottomNavigation(String activeTab, boolean compact) {
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(compact ? 6 : 10), dp(8), dp(compact ? 6 : 10), dp(10));
        nav.setBackground(rounded(panel, dp(0), panelAlt, 1));
        nav.addView(navButton("Home", TAB_HOME, activeTab, compact), navParams());
        nav.addView(navButton("Sync", TAB_SYNC, activeTab, compact), navParams());
        nav.addView(navButton("Data", TAB_DATA, activeTab, compact), navParams());
        nav.addView(navButton("Privacy", TAB_PRIVACY, activeTab, compact), navParams());
        nav.addView(navButton("Help", TAB_HELP, activeTab, compact), navParams());
        return nav;
    }

    private LinearLayout.LayoutParams navParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        return p;
    }

    private Button navButton(String label, String tab, String activeTab, boolean compact) {
        boolean active = tab.equals(activeTab);
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(compact ? 11 : 12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(active ? readableOn(accent) : text);
        b.setBackground(rounded(active ? accent : panelAlt, dp(16), active ? accent : panelAlt, 0));
        b.setMinHeight(dp(compact ? 44 : 48));
        b.setContentDescription("Open " + label + " section");
        b.setOnClickListener(v -> setActiveTab(tab));
        return b;
    }

    private String activeTab() {
        String value = prefs.getString(KEY_ACTIVE_TAB, TAB_HOME);
        if (TAB_SYNC.equals(value) || TAB_DATA.equals(value) || TAB_PRIVACY.equals(value) || TAB_HELP.equals(value)) return value;
        return TAB_HOME;
    }

    private void setActiveTab(String tab) {
        prefs.edit().putString(KEY_ACTIVE_TAB, tab).apply();
        rebuildFromCurrent("Opened " + tabShortLabel(tab) + " section. Use the bottom navigation to switch sections without hunting through one long screen.");
    }

    private String tabShortLabel(String tab) {
        if (TAB_SYNC.equals(tab)) return "Sync";
        if (TAB_DATA.equals(tab)) return "Data";
        if (TAB_PRIVACY.equals(tab)) return "Privacy";
        if (TAB_HELP.equals(tab)) return "Help";
        return "Home";
    }

    private String tabTitle(String tab) {
        if (TAB_SYNC.equals(tab)) return "Sync operations";
        if (TAB_DATA.equals(tab)) return "Health data coverage";
        if (TAB_PRIVACY.equals(tab)) return "Privacy and device control";
        if (TAB_HELP.equals(tab)) return "Help, links, and diagnostics";
        return "Home and setup";
    }

    private String tabBody(String tab) {
        if (TAB_SYNC.equals(tab)) return "Run manual sync, configure background sync, review local sync history, retry queued batches, and verify the Virii8 bridge.";
        if (TAB_DATA.equals(tab)) return "Choose Health Bridge categories and review which Samsung Health data types the companion can send to Virii8 Core.";
        if (TAB_PRIVACY.equals(tab)) return "Review what this phone can send, open Samsung permissions, revoke the local bridge token, or clear local companion data.";
        if (TAB_HELP.equals(tab)) return "Open MiltonMarketing, Virii8 Workspace, Samsung SDK references, diagnostics, and the companion roadmap from one clean section.";
        return "Finish guided setup, pair this phone, check bridge status, and customize the companion app for this device.";
    }

    private View header(boolean twoColumn, boolean compact, boolean landscape) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(twoColumn && landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(0, 0, 0, dp(twoColumn ? 12 : 18));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("mm_logo", "drawable", getPackageName()));
        int logoSize = dp(compact ? 64 : (twoColumn ? 78 : 90));
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(logoSize, logoSize);
        logoParams.gravity = Gravity.CENTER;
        if (twoColumn && landscape) logoParams.setMargins(0, 0, dp(16), 0);
        logo.setLayoutParams(logoParams);
        logo.setAdjustViewBounds(true);
        header.addView(logo);

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setGravity(twoColumn && landscape ? Gravity.CENTER_VERTICAL : Gravity.CENTER_HORIZONTAL);

        TextView title = text("Virii8 Companion", twoColumn ? 22 : 25, text, true);
        title.setGravity(twoColumn && landscape ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        copy.addView(title);

        TextView subtitle = text("Ecosystem companion app • Health Bridge for Samsung devices", 14, muted, false);
        subtitle.setGravity(twoColumn && landscape ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, dp(5), 0, 0);
        copy.addView(subtitle);

        TextView version = text("v" + APP_VERSION + " production RC • " + themeName + " • " + layoutModeLabel(), 12, accent2, true);
        version.setGravity(twoColumn && landscape ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        version.setPadding(0, dp(6), 0, 0);
        copy.addView(version);

        header.addView(copy, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return header;
    }

    private View setupWizardCard(boolean twoColumn) {
        LinearLayout card = card(prefs.getBoolean(KEY_SETUP_DONE, false) ? panel : panelSoft);
        card.addView(sectionTitle("Guided setup wizard"));

        LinearLayout progress = new LinearLayout(this);
        progress.setOrientation(twoColumn ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        progress.setPadding(0, dp(4), 0, dp(8));
        for (int i = 1; i <= 6; i++) {
            int c = setupStep() == i ? accent : (prefs.getBoolean(KEY_SETUP_DONE, false) ? accent2 : panelAlt);
            progress.addView(chip("Step " + i, setupShortLabel(i), c), chipParams(twoColumn));
        }
        card.addView(progress);

        card.addView(text(setupStepTitle(setupStep()), 17, text, true));
        TextView body = text(setupStepBody(setupStep()), 13, muted, false);
        body.setPadding(0, dp(6), 0, dp(6));
        card.addView(body);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(twoColumn ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        row.setPadding(0, dp(6), 0, 0);

        Button back = button("Back", panelAlt, text);
        back.setEnabled(setupStep() > 1);
        back.setAlpha(setupStep() > 1 ? 1.0f : 0.45f);
        back.setOnClickListener(v -> setSetupStep(Math.max(1, setupStep() - 1), "Setup step changed: " + setupStepTitle(Math.max(1, setupStep() - 1))));
        row.addView(back, twoColumn ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) : matchWrapBottom(0));

        Button action = button(setupPrimaryButton(setupStep()), accent, readableOn(accent));
        action.setOnClickListener(v -> runSetupStepAction());
        row.addView(action, twoColumn ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) : matchWrapBottom(0));

        Button next = button(setupStep() >= 6 ? "Finish setup" : "Next", accent2, readableOn(accent2));
        next.setOnClickListener(v -> {
            if (setupStep() >= 6) {
                prefs.edit().putBoolean(KEY_SETUP_DONE, true).putInt(KEY_SETUP_STEP, 6).apply();
                rebuildFromCurrent("Setup marked complete. You can still change pairing, categories, permissions, and sync settings anytime.");
            } else {
                setSetupStep(setupStep() + 1, "Setup step changed: " + setupStepTitle(setupStep() + 1));
            }
        });
        row.addView(next, twoColumn ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) : matchWrapBottom(0));
        card.addView(row);

        if (prefs.getBoolean(KEY_SETUP_DONE, false)) {
            Button reopen = button("Reopen setup wizard", panelAlt, text);
            reopen.setOnClickListener(v -> {
                prefs.edit().putBoolean(KEY_SETUP_DONE, false).putInt(KEY_SETUP_STEP, 1).apply();
                rebuildFromCurrent("Setup wizard reopened.");
            });
            card.addView(reopen);
        }
        return card;
    }

    private int setupStep() {
        int step = prefs.getInt(KEY_SETUP_STEP, 1);
        if (step < 1) return 1;
        if (step > 6) return 6;
        return step;
    }

    private void setSetupStep(int step, String message) {
        int clean = Math.max(1, Math.min(6, step));
        prefs.edit().putInt(KEY_SETUP_STEP, clean).apply();
        rebuildFromCurrent(message);
    }

    private String setupShortLabel(int step) {
        switch (step) {
            case 1: return "Welcome";
            case 2: return "QR / Connect";
            case 3: return "Categories";
            case 4: return "Permissions";
            case 5: return "First sync";
            case 6: return "Done";
            default: return "Setup";
        }
    }

    private String setupStepTitle(int step) {
        switch (step) {
            case 1: return "Welcome to Virii8 Companion";
            case 2: return "Pair by QR or bridge token";
            case 3: return "Choose Health Bridge categories";
            case 4: return "Grant Samsung Health permissions";
            case 5: return "Run the first private sync";
            case 6: return "Review and finish";
            default: return "Guided setup";
        }
    }

    private String setupStepBody(int step) {
        switch (step) {
            case 1:
                return "This app is the Android companion for the Virii8 Ecosystem. The first active module is Health Bridge: Samsung Health stays on your phone, and approved records sync privately to Virii8 Core.";
            case 2:
                return "Scan a Virii8 pairing QR with Samsung Camera or paste the QR payload below. You can still type the Virii8 site URL, pairing token, and device label manually.";
            case 3:
                return "Pick the health categories this phone is allowed to request. Samsung Health still gives the final on-device approval before data can be read.";
            case 4:
                return "Open the Samsung permission request for the selected categories. Denied categories will not be synced.";
            case 5:
                return "Run Sync Today to send today’s enabled Samsung categories through the tokenized Virii8 bridge. If the network or Virii8 endpoint is unavailable, v1.0.5 queues the prepared payload locally using AndroidKeyStore-backed encrypted storage. You can retry manually or let background sync retry according to your policy.";
            case 6:
                return "Confirm the device is paired, categories are correct, the first sync has been tested, and diagnostics are available if an admin needs to troubleshoot.";
            default:
                return "Follow each step to connect this phone safely.";
        }
    }

    private String setupPrimaryButton(int step) {
        switch (step) {
            case 1: return "Open MiltonMarketing";
            case 2: return "Show QR pairing help";
            case 3: return "Show selected categories";
            case 4: return "Grant selected permissions";
            case 5: return "Run Sync Today";
            case 6: return "Open Virii8 Workspace";
            default: return "Continue";
        }
    }

    private void runSetupStepAction() {
        switch (setupStep()) {
            case 1:
                openUrl("https://miltonmarketing.com");
                break;
            case 2:
                refreshStatus("QR pairing supports virii8://pair-health links, virii8companion://pair links, JSON payloads, or query-string payloads. Scan with Samsung Camera or paste the payload in the Pair this phone card.");
                break;
            case 3:
                refreshStatus("Selected categories: " + selectedCategorySummary() + ". Adjust the Health Bridge categories card below.");
                break;
            case 4:
                requestSamsungPermissionsSelected();
                break;
            case 5:
                syncToday();
                break;
            case 6:
                openUrl(siteUrlText() + "/workspace/");
                break;
            default:
                refreshStatus("Continue through the setup steps.");
        }
    }


    private View firstRunPolishCard() {
        LinearLayout card = card(panelSoft);
        card.addView(sectionTitle("First-run polish"));
        if (!prefs.getBoolean(KEY_SETUP_DONE, false)) {
            card.addView(text("The app is not finished with setup yet. Complete the wizard once, then this card becomes a compact status note instead of a setup reminder.", 13, muted, false));
            card.addView(metricRow("Recommended order", "Pair → Categories → Samsung permissions → Sync Today → Privacy acknowledgement"));
        } else {
            card.addView(text("Setup is complete. You can still change every local companion preference from Home, Sync, Data, Privacy, and Help.", 13, muted, false));
        }
        card.addView(metricRow("Current next action", nextBestActionText()));
        return card;
    }

    private View errorStatesCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Troubleshooting and empty states"));
        card.addView(text("v1.0.5 keeps plain-language next steps when the app has no data, no pairing, no network, denied Samsung permissions, queued sync batches, a Virii8 bridge error, or production privacy/support metadata gaps.", 13, muted, false));
        card.addView(metricRow("No records", "Check Samsung Health data exists for today, enable the matching category, then grant Samsung permissions again."));
        card.addView(metricRow("Not paired", "Paste or scan a Virii8 pairing payload, review it, then tap Save secure pairing."));
        card.addView(metricRow("Offline", "The app queues prepared sync batches locally. Reconnect and tap Retry Queued Sync."));
        card.addView(metricRow("Bridge error", "Use Share Diagnostics. Token is excluded, but site/device/status/history are included."));
        Button copy = button("Copy troubleshooting summary", panelAlt, text);
        copy.setOnClickListener(v -> copyToClipboard("Virii8 Companion troubleshooting", buildTroubleshootingSummary()));
        card.addView(copy);
        return card;
    }

    private View qaChecklistCard() {
        LinearLayout card = card(panelSoft);
        card.addView(sectionTitle("Release/private testing QA checklist"));
        card.addView(text("v1.0.5 is the production release candidate. Use this checklist before trusting imported health records for dashboards, reports, Samsung approval submission, release artifacts, store metadata, support flows, or insights.", 13, muted, false));
        card.addView(metricRow("1. Install freshness", "Uninstall any older APK first, install the new debug or signed release APK, and confirm the header shows v1.0.5 production release candidate."));
        card.addView(metricRow("2. Release signing setup", "Use keystore.properties locally or GitHub Actions secrets. Never commit the keystore or passwords."));
        card.addView(metricRow("3. Release artifacts", "Build assembleRelease and bundleRelease only after signing is configured; keep debug APKs for private install testing."));
        card.addView(metricRow("4. Orientation", "Rotate portrait/landscape and confirm bottom navigation, cards, and two-column/foldable layout remain usable."));
        card.addView(metricRow("5. Pairing", "Pair manually or by QR/deep link, then test Virii8 bridge status. Do not share the bridge token in screenshots."));
        card.addView(metricRow("6. Permissions", "Grant only the Samsung Health categories you actually want to test. Denied categories should be handled gracefully."));
        card.addView(metricRow("7. Sync", "Run Sync Today with steps, sleep, heart, workouts, nutrition/hydration, and body metrics enabled where data exists."));
        card.addView(metricRow("8. Offline behavior", "Disable network, run sync, confirm queue count increases, reconnect, then Retry Queued Sync."));
        card.addView(metricRow("9. Background policy", "Test manual-only first, then daily or six-hour scheduling with Wi-Fi/charging constraints."));
        card.addView(metricRow("10. Privacy controls", "Review privacy summary, open Samsung settings, revoke local token, and confirm diagnostics exclude token values."));
        Button copy = button("Copy QA checklist", panelAlt, text);
        copy.setContentDescription("Copy the Virii8 Companion release/private testing QA checklist");
        copy.setOnClickListener(v -> copyToClipboard("Virii8 Companion QA checklist", buildQaChecklistText()));
        card.addView(copy);
        Button diagnostics = button("Share diagnostics for QA", panelAlt, text);
        diagnostics.setContentDescription("Share diagnostics without the bridge token for QA review");
        diagnostics.setOnClickListener(v -> shareDiagnostics());
        card.addView(diagnostics);
        return card;
    }

    private String buildQaChecklistText() {
        StringBuilder b = new StringBuilder();
        b.append("Virii8 Companion Release/Private Testing QA Checklist\n");
        b.append("Generated: ").append(nowStamp()).append("\n");
        b.append("App version: ").append(APP_VERSION).append("\n");
        b.append("Package: ").append(getPackageName()).append("\n");
        b.append("Device: ").append(android.os.Build.MANUFACTURER).append(' ').append(android.os.Build.MODEL).append("\n");
        b.append("Android SDK: ").append(android.os.Build.VERSION.SDK_INT).append("\n");
        b.append("Layout: ").append(layoutModeLabel()).append("\n");
        b.append("Paired: ").append(tokenStore.isPaired()).append("\n");
        b.append("Selected categories: ").append(selectedCategorySummary()).append("\n");
        b.append("Offline queue: ").append(pendingQueueCount()).append(" pending batch(es)\n");
        b.append("Last sync: ").append(prefs.getString(KEY_LAST_SYNC, "none")).append("\n\n");
        b.append("Checklist:\n");
        b.append("[ ] Uninstall older APK and install current debug APK or signed release APK.\n");
        b.append("[ ] Confirm header shows v1.0.5 production release candidate.\n");
        b.append("[ ] Confirm keystore.properties is local-only or GitHub secrets are configured.\n[ ] Confirm release APK/AAB artifacts are signed before external distribution.\n[ ] Rotate portrait/landscape and verify layout.\n");
        b.append("[ ] Pair device and test Virii8 bridge.\n");
        b.append("[ ] Grant selected Samsung Health permissions.\n");
        b.append("[ ] Run Sync Today for enabled categories.\n");
        b.append("[ ] Test offline queue and retry.\n");
        b.append("[ ] Test background sync policy.\n");
        b.append("[ ] Review privacy dashboard and diagnostics.\n");
        b.append("[ ] Confirm no bridge token appears in diagnostics or screenshots.\n");
        return b.toString();
    }

    private View commandCenterCard(int widthDp, int heightDp, int smallestDp, boolean landscape, boolean twoColumn) {
        LinearLayout card = card(panelSoft);
        card.addView(sectionTitle("Companion command center"));
        card.addView(text("Use the bottom navigation to move between Home, Sync, Data, Privacy, and Help. Customize the Health Bridge, choose sync categories, test the Virii8 endpoint, and keep Samsung Health permissions controlled on-device.", 13, muted, false));

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(twoColumn ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        metrics.setPadding(0, dp(10), 0, 0);
        metrics.addView(chip("Setup", prefs.getBoolean(KEY_SETUP_DONE, false) ? "Complete" : "Step " + setupStep(), prefs.getBoolean(KEY_SETUP_DONE, false) ? accent2 : warning), chipParams(twoColumn));
        metrics.addView(chip("Pairing", tokenStore.isPaired() ? "Paired" : "Not paired", tokenStore.isPaired() ? accent2 : warning), chipParams(twoColumn));
        metrics.addView(chip("Display", twoColumn ? "Two-column" : "Single-column", accent), chipParams(twoColumn));
        metrics.addView(chip("Categories", selectedCategories().size() + " selected", accent2), chipParams(twoColumn));
        card.addView(metrics);

        card.addView(metricRow("Viewport", widthDp + "dp × " + heightDp + "dp" + (smallestDp > 0 ? " • smallest " + smallestDp + "dp" : "")));
        card.addView(metricRow("Rotation", landscape ? "Landscape / wide" : "Portrait / tall"));
        card.addView(metricRow("Last sync", prefs.getString(KEY_LAST_SYNC, "No successful sync recorded on this device yet.")));
        card.addView(metricRow("Sync log", syncHistoryCount() + " local event(s) retained on this device."));
        card.addView(metricRow("Offline queue", pendingQueueCount() + " pending sync batch(es)" + (pendingQueueCount() > 0 ? " • " + prefs.getString(KEY_QUEUE_LAST_CHANGE, "queued") : "")));
        card.addView(metricRow("Network", isNetworkAvailable() ? "Available" : "Unavailable / offline"));
        card.addView(metricRow("Last diagnostics export", prefs.getString(KEY_LAST_DIAGNOSTICS_EXPORT, "No diagnostics export shared yet.")));
        card.addView(metricRow("Last privacy action", prefs.getString(KEY_LAST_PRIVACY_ACTION, "No local privacy action recorded yet.")));
        card.addView(metricRow("Last QR pairing", prefs.getString(KEY_LAST_QR_PAIRING, "No QR/deep-link pairing imported on this device yet.")));
        return card;
    }

    private LinearLayout.LayoutParams chipParams(boolean horizontal) {
        LinearLayout.LayoutParams p = horizontal ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) : matchWrapBottom(dp(8));
        if (horizontal) p.setMargins(0, 0, dp(8), 0);
        return p;
    }

    private View chip(String label, String value, int chipAccent) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.VERTICAL);
        chip.setPadding(dp(12), dp(10), dp(12), dp(10));
        chip.setBackground(rounded(panelAlt, dp(16), chipAccent, 1));
        chip.addView(text(label, 11, muted, true));
        chip.addView(text(value, 14, text, true));
        return chip;
    }

    private View bridgeStatusCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Bridge status"));
        bridgeSummary = text("", 13, muted, false);
        bridgeSummary.setPadding(0, dp(6), 0, 0);
        card.addView(bridgeSummary);
        return card;
    }

    private View pairingCard(String initialSite, String initialToken, String initialDevice) {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Pair this phone"));
        card.addView(text("Use a Virii8 pairing QR, deep link, or bridge token. The token is encrypted on this device and used only for private sync.", 13, muted, false));

        card.addView(label("QR / Deep-link payload"));
        qrPayload = input("Paste QR JSON, virii8://pair-health link, or query string", false);
        card.addView(qrPayload);

        Button importQr = button("Import QR / deep-link pairing", panelAlt, text);
        importQr.setOnClickListener(v -> importQrPayloadFromField());
        card.addView(importQr);

        Button pasteClipboard = button("Paste clipboard into QR payload", panelAlt, text);
        pasteClipboard.setOnClickListener(v -> pasteClipboardIntoQrPayload());
        card.addView(pasteClipboard);

        card.addView(label("Virii8 Site URL"));
        siteUrl = input("https://miltonmarketing.com", false);
        siteUrl.setText(initialSite == null || initialSite.trim().isEmpty() ? "https://miltonmarketing.com" : initialSite);
        card.addView(siteUrl);

        card.addView(label("Pairing Token"));
        pairingToken = input("Paste token generated in Virii8 Health admin", true);
        if (initialToken != null) pairingToken.setText(initialToken);
        card.addView(pairingToken);

        card.addView(label("Device Label"));
        deviceLabel = input("Samsung phone label", false);
        deviceLabel.setText(initialDevice == null || initialDevice.trim().isEmpty() ? android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL : initialDevice);
        card.addView(deviceLabel);

        Button save = button("Save secure pairing", accent, readableOn(accent));
        save.setOnClickListener(v -> savePairing());
        card.addView(save);
        return card;
    }

    private View actionsCard() {
        LinearLayout actions = card(panel);
        actions.addView(sectionTitle("Permissions and sync"));
        actions.addView(text("Request only the Samsung Health categories you enabled below. For v1.0.5, manual and scheduled sync can import today’s steps, sleep sessions/stages, sleep oxygen/temp, heart-rate records, workout summaries, nutrition/hydration records, and body metrics. If Virii8 or the network is unavailable, the prepared sync payload is queued locally using AndroidKeyStore-backed encrypted storage for retry.", 13, muted, false));

        Button permissions = button("Grant selected Samsung permissions", accent2, readableOn(accent2));
        permissions.setOnClickListener(v -> requestSamsungPermissionsSelected());
        actions.addView(permissions);

        Button testBridge = button("Test Virii8 bridge status", panelAlt, text);
        testBridge.setOnClickListener(v -> testVirii8Bridge());
        actions.addView(testBridge);

        Button sync = button("Sync Today", accent, readableOn(accent));
        sync.setOnClickListener(v -> syncToday());
        actions.addView(sync);

        Button retryQueue = button("Retry Queued Sync", accent2, readableOn(accent2));
        retryQueue.setOnClickListener(v -> retryPendingQueue());
        actions.addView(retryQueue);

        Button showQueue = button("Show Offline Queue", panelAlt, text);
        showQueue.setOnClickListener(v -> showPendingQueue());
        actions.addView(showQueue);

        Button history = button("Show Sync History", panelAlt, text);
        history.setOnClickListener(v -> showSyncHistory());
        actions.addView(history);

        Button diagnostics = button("Share Diagnostics", panelAlt, text);
        diagnostics.setOnClickListener(v -> shareDiagnostics());
        actions.addView(diagnostics);

        Button clearQueue = button("Clear Offline Queue", panelAlt, text);
        clearQueue.setOnClickListener(v -> clearPendingQueue());
        actions.addView(clearQueue);

        Button clearHistory = button("Clear Local Sync History", panelAlt, text);
        clearHistory.setOnClickListener(v -> clearSyncHistory());
        actions.addView(clearHistory);

        Button dashboard = button("Open Virii8 Health Dashboard", panelAlt, text);
        dashboard.setOnClickListener(v -> openUrl(siteUrlText() + "/workspace/"));
        actions.addView(dashboard);

        Button disconnect = button("Disconnect This Phone", panelAlt, text);
        disconnect.setOnClickListener(v -> {
            tokenStore.clear();
            pairingToken.setText("");
            appendHistory("pairing", "Device disconnected locally. Revoke the bridge token in Virii8 if this phone is lost or retired.");
            updateBridgeSummary();
            refreshStatus("Disconnected locally. Revoke the bridge token in Virii8 as well if this phone is lost or retired.");
        });
        actions.addView(disconnect);
        return actions;
    }

    private View backgroundSyncCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Background sync controls"));
        card.addView(text("Choose how aggressively this phone should sync Samsung Health data to Virii8. Manual-only is safest. Scheduled sync respects your Wi-Fi, charging, and pause settings.", 13, muted, false));
        card.addView(metricRow("Mode", backgroundModeLabel()));
        card.addView(metricRow("Policy", backgroundPolicySummary()));
        card.addView(metricRow("Last background run", prefs.getString(KEY_BACKGROUND_LAST_RUN, "none yet")));
        card.addView(metricRow("Last background result", prefs.getString(KEY_BACKGROUND_LAST_RESULT, "none yet")));
        card.addView(metricRow("Next schedule hint", prefs.getString(KEY_BACKGROUND_NEXT_HINT, "manual-only / not scheduled")));

        Button manual = button("Manual only", MODE_MANUAL.equals(backgroundMode()) ? accent : panelAlt, MODE_MANUAL.equals(backgroundMode()) ? readableOn(accent) : text);
        manual.setOnClickListener(v -> setBackgroundMode(MODE_MANUAL));
        card.addView(manual);

        Button daily = button("Daily background sync", MODE_DAILY.equals(backgroundMode()) ? accent : panelAlt, MODE_DAILY.equals(backgroundMode()) ? readableOn(accent) : text);
        daily.setOnClickListener(v -> setBackgroundMode(MODE_DAILY));
        card.addView(daily);

        Button sixHour = button("Every 6 hours", MODE_SIX_HOUR.equals(backgroundMode()) ? accent : panelAlt, MODE_SIX_HOUR.equals(backgroundMode()) ? readableOn(accent) : text);
        sixHour.setOnClickListener(v -> setBackgroundMode(MODE_SIX_HOUR));
        card.addView(sixHour);

        CheckBox wifi = checkbox("Wi-Fi only", prefs.getBoolean(KEY_BACKGROUND_WIFI_ONLY, true));
        wifi.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_BACKGROUND_WIFI_ONLY, isChecked).apply();
            BackgroundSyncScheduler.apply(this, prefs);
            appendHistory("background", "Wi-Fi-only background sync " + (isChecked ? "enabled" : "disabled") + ".");
            rebuildFromCurrent("Background sync Wi-Fi policy updated: " + backgroundPolicySummary());
        });
        card.addView(wifi);

        CheckBox charging = checkbox("While charging only", prefs.getBoolean(KEY_BACKGROUND_CHARGING_ONLY, false));
        charging.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_BACKGROUND_CHARGING_ONLY, isChecked).apply();
            BackgroundSyncScheduler.apply(this, prefs);
            appendHistory("background", "Charging-only background sync " + (isChecked ? "enabled" : "disabled") + ".");
            rebuildFromCurrent("Background sync charging policy updated: " + backgroundPolicySummary());
        });
        card.addView(charging);

        CheckBox paused = checkbox("Pause background sync", prefs.getBoolean(KEY_BACKGROUND_PAUSED, false));
        paused.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_BACKGROUND_PAUSED, isChecked).apply();
            BackgroundSyncScheduler.apply(this, prefs);
            appendHistory("background", "Background sync " + (isChecked ? "paused" : "resumed") + ".");
            rebuildFromCurrent("Background sync " + (isChecked ? "paused" : "resumed") + ": " + backgroundPolicySummary());
        });
        card.addView(paused);

        Button apply = button("Apply background schedule", accent2, readableOn(accent2));
        apply.setOnClickListener(v -> {
            BackgroundSyncScheduler.apply(this, prefs);
            appendHistory("background", "Background schedule applied: " + backgroundPolicySummary());
            refreshStatus("Background sync schedule applied. " + backgroundPolicySummary());
        });
        card.addView(apply);

        Button runNow = button("Run background sync check now", panelAlt, text);
        runNow.setOnClickListener(v -> {
            appendHistory("background", "Manual background policy check requested from UI.");
            BackgroundSyncReceiver.runNow(this);
            refreshStatus("Background sync check requested. Watch Sync history for the result.");
        });
        card.addView(runNow);
        return card;
    }

    private View customizationCard(boolean compact) {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Customize companion"));
        card.addView(text("These settings change this Android companion only. Virii8 Core still owns health data, privacy, tenant boundaries, and dashboard rendering.", 13, muted, false));
        card.addView(metricRow("Active theme", themeName));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(themeButton("Ocean", "ocean"), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row1.addView(themeButton("Matrix", "matrix"), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(themeButton("Light", "light"), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row2.addView(themeButton("Contrast", "contrast"), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(row2);

        CheckBox compactBox = checkbox("Compact cards / tighter spacing", prefs.getBoolean(KEY_COMPACT, false));
        compactBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_COMPACT, isChecked).apply();
            rebuildFromCurrent("Compact layout " + (isChecked ? "enabled" : "disabled") + ".");
        });
        card.addView(compactBox);

        CheckBox advancedBox = checkbox("Show advanced platform notes", prefs.getBoolean(KEY_ADVANCED, true));
        advancedBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_ADVANCED, isChecked).apply();
            rebuildFromCurrent("Advanced platform notes " + (isChecked ? "shown" : "hidden") + ".");
        });
        card.addView(advancedBox);

        CheckBox largeTextBox = checkbox("Larger text / accessibility spacing", prefs.getBoolean(KEY_LARGE_TEXT, false));
        largeTextBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_LARGE_TEXT, isChecked).apply();
            rebuildFromCurrent("Larger text mode " + (isChecked ? "enabled" : "disabled") + ".");
        });
        card.addView(largeTextBox);

        CheckBox statusHelpBox = checkbox("Plain-language status help", prefs.getBoolean(KEY_STATUS_HELP, true));
        statusHelpBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_STATUS_HELP, isChecked).apply();
            rebuildFromCurrent("Plain-language status help " + (isChecked ? "enabled" : "disabled") + ".");
        });
        card.addView(statusHelpBox);
        return card;
    }

    private Button themeButton(String label, String key) {
        Button b = button(label, prefs.getString(KEY_THEME, "ocean").equals(key) ? accent : panelAlt, prefs.getString(KEY_THEME, "ocean").equals(key) ? readableOn(accent) : text);
        b.setOnClickListener(v -> {
            prefs.edit().putString(KEY_THEME, key).apply();
            rebuildFromCurrent("Theme changed to " + label + ".");
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(4), dp(10), dp(4), 0);
        b.setLayoutParams(p);
        return b;
    }

    private View categoryCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Health Bridge categories"));
        card.addView(text("Choose what the companion should request and prepare for sync. You can still approve or deny categories inside Samsung Health.", 13, muted, false));
        selectedCategoriesSummary = text("", 13, accent2, true);
        selectedCategoriesSummary.setPadding(0, dp(8), 0, dp(4));
        card.addView(selectedCategoriesSummary);

        card.addView(categoryCheckbox(CAT_STEPS, "Activity / steps", "Live reader: hourly step aggregates."));
        card.addView(categoryCheckbox(CAT_SLEEP, "Sleep", "Live reader: sleep sessions, stages, sleep oxygen, and skin temperature where Samsung Health provides them."));
        card.addView(categoryCheckbox(CAT_HEART, "Heart", "Live reader: heart-rate samples for today, capped per sync batch for safety."));
        card.addView(categoryCheckbox(CAT_WORKOUTS, "Workouts", "Live reader: workout/exercise sessions and summary metadata. GPS route coordinates are withheld until an explicit route privacy toggle exists."));
        card.addView(categoryCheckbox(CAT_NUTRITION, "Nutrition + hydration", "Live reader: food, nutrients, calories, meal type, and water intake for today."));
        card.addView(categoryCheckbox(CAT_BODY, "Body metrics", "Live reader: blood pressure, glucose, body temperature, and body composition records for today."));
        return card;
    }

    private View categoryCheckbox(String key, String title, String description) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(8), 0, 0);
        CheckBox cb = checkbox(title, prefs.getBoolean("cat_" + key, CAT_STEPS.equals(key)));
        cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("cat_" + key, isChecked).apply();
            updateSelectedCategoriesSummary();
            refreshStatus("Health category updated: " + selectedCategorySummary() + ". Samsung permission changes still require Grant selected Samsung permissions.");
        });
        wrap.addView(cb);
        TextView d = text(description, 12, muted, false);
        d.setPadding(dp(32), 0, 0, 0);
        wrap.addView(d);
        return wrap;
    }


    private View syncHistoryCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Sync history + diagnostics"));
        card.addView(text("Recent local events are kept only on this phone to help you and Virii8 admins troubleshoot pairing, permission, bridge, and sync problems.", 13, muted, false));
        card.addView(metricRow("Events retained", String.valueOf(syncHistoryCount())));
        card.addView(metricRow("Offline queue", pendingQueueCount() + " pending batch(es)"));
        card.addView(metricRow("Latest event", latestHistoryLine()));

        TextView preview = text(syncHistoryPreview(6), 12, muted, false);
        preview.setPadding(0, dp(8), 0, dp(4));
        preview.setBackground(rounded(panelSoft, dp(14), panelAlt, 1));
        preview.setPadding(dp(12), dp(10), dp(12), dp(10));
        card.addView(preview, matchWrapBottom(0));

        Button show = button("Show Full Local History", panelAlt, text);
        show.setOnClickListener(v -> showSyncHistory());
        card.addView(show);

        Button share = button("Share Diagnostics", panelAlt, text);
        share.setOnClickListener(v -> shareDiagnostics());
        card.addView(share);

        Button copyStatus = button("Copy Current Status", panelAlt, text);
        copyStatus.setOnClickListener(v -> copyToClipboard("Virii8 Companion current status", lastStatus));
        card.addView(copyStatus);

        if (syncHistoryCount() == 0) {
            card.addView(text("Empty state: no sync events yet. Run Test Virii8 bridge status or Sync Today to create the first local diagnostic event.", 12, warning, true));
        }
        return card;
    }

    private View dataCoverageCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Capability roadmap"));
        card.addView(metricRow("Now", "Guided setup wizard, QR/deep-link pairing, local sync history, diagnostics export, manual Samsung health sync, offline queue, retry failed sync, network-aware sends, background sync controls, and privacy dashboard/revoke/clear actions."));
        card.addView(metricRow("Next", "Samsung app registration/SHA-256 approval prep, production privacy metadata, notifications, and final v1.0.5 release candidate validation."));
        card.addView(metricRow("Prepared", "Provider-neutral bridge model for Samsung Health, Health Connect, Fitbit, Apple Health export/import, and future wearables."));
        card.addView(metricRow("Protected", "Sleep apnea and irregular rhythm signals are sensitive wellness indicators, not diagnostic conclusions."));
        return card;
    }

    private View linksCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Helpful links"));
        card.addView(text("Quick links for setup, platform docs, and third-party health ecosystems. These links leave the app.", 13, muted, false));
        card.addView(linkButton("MiltonMarketing.com", "https://miltonmarketing.com"));
        card.addView(linkButton("Virii8 Health articles", "https://miltonmarketing.com/?s=Virii8+Health"));
        card.addView(linkButton("Virii8 Workspace", siteUrlText() + "/workspace/"));
        card.addView(linkButton("Virii8 Privacy Policy", siteUrlText() + "/privacy-policy/"));
        card.addView(linkButton("Virii8 Support / Contact", siteUrlText() + "/contact/"));
        card.addView(linkButton("Samsung Health Data SDK", "https://developer.samsung.com/health/data/guide/introduction.html"));
        card.addView(linkButton("Android Health Connect", "https://developer.android.com/health-and-fitness/health-connect"));
        card.addView(linkButton("Fitbit Web API", "https://developer.fitbit.com/build/reference/web-api/"));
        card.addView(linkButton("Apple HealthKit", "https://developer.apple.com/documentation/healthkit"));
        return card;
    }

    private View privacyCard() {
        LinearLayout privacy = card(panel);
        privacy.addView(sectionTitle("Privacy dashboard"));
        privacy.addView(text("This app reads only the Samsung Health categories you approve on this phone and sends them to your private Virii8 Health module using a bridge token. It does not replace Samsung Health, Health Connect, Apple Health, Fitbit, or medical care.", 13, muted, false));
        privacy.addView(text("Strong rule: the companion is a bridge. Virii8 Core remains the source of truth for consent records, retention policy, tenant boundaries, dashboards, analytics, and audit logs.", 13, muted, false));

        privacy.addView(metricRow("Paired device", tokenStore.isPaired() ? tokenStore.getDeviceLabel() : "Not paired"));
        privacy.addView(metricRow("Virii8 site", tokenStore.getSiteUrl()));
        privacy.addView(metricRow("Enabled categories", selectedCategorySummary()));
        privacy.addView(metricRow("Local queue", pendingQueueCount() + " pending batch(es) stored on this phone"));
        privacy.addView(metricRow("Local history", syncHistoryCount() + " event(s) stored on this phone"));
        privacy.addView(metricRow("Background sync", backgroundPolicySummary()));
        privacy.addView(metricRow("Last privacy action", prefs.getString(KEY_LAST_PRIVACY_ACTION, "No local privacy action recorded yet.")));
        privacy.addView(metricRow("Privacy policy URL", siteUrlText() + "/privacy-policy/"));
        privacy.addView(metricRow("Support URL", siteUrlText() + "/contact/"));

        CheckBox acknowledge = checkbox("I understand Virii8 Companion is a private bridge, not medical care", prefs.getBoolean(KEY_PRIVACY_ACK, false));
        acknowledge.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit()
                .putBoolean(KEY_PRIVACY_ACK, isChecked)
                .putString(KEY_LAST_PRIVACY_ACTION, nowStamp() + " • privacy acknowledgement " + (isChecked ? "accepted" : "cleared"))
                .apply();
            appendHistory("privacy", "Privacy acknowledgement " + (isChecked ? "accepted" : "cleared") + ".");
            refreshStatus("Privacy acknowledgement " + (isChecked ? "saved" : "cleared") + ".");
        });
        privacy.addView(acknowledge);

        Button show = button("Show Privacy Summary", panelAlt, text);
        show.setOnClickListener(v -> showPrivacySummary());
        privacy.addView(show);

        Button share = button("Share Privacy Summary", panelAlt, text);
        share.setOnClickListener(v -> sharePrivacySummary());
        privacy.addView(share);

        Button samsung = button("Open Samsung Health Permissions", accent2, readableOn(accent2));
        samsung.setOnClickListener(v -> openSamsungHealthPermissions());
        privacy.addView(samsung);

        Button virii8Privacy = button("Open Virii8 Privacy Policy", panelAlt, text);
        virii8Privacy.setOnClickListener(v -> openUrl(siteUrlText() + "/privacy-policy/"));
        privacy.addView(virii8Privacy);

        Button virii8Support = button("Open Virii8 Support / Contact", panelAlt, text);
        virii8Support.setOnClickListener(v -> openUrl(siteUrlText() + "/contact/"));
        privacy.addView(virii8Support);

        Button virii8Workspace = button("Open Virii8 Workspace", panelAlt, text);
        virii8Workspace.setOnClickListener(v -> openUrl(siteUrlText() + "/workspace/"));
        privacy.addView(virii8Workspace);

        Button appSettings = button("Open Android App Settings", panelAlt, text);
        appSettings.setOnClickListener(v -> openAndroidAppSettings());
        privacy.addView(appSettings);

        Button revoke = button("Revoke Local Bridge Token", danger, readableOn(danger));
        revoke.setOnClickListener(v -> revokeLocalBridgeToken());
        privacy.addView(revoke);

        Button clearLocal = button("Clear All Local Companion Data", danger, readableOn(danger));
        clearLocal.setOnClickListener(v -> clearAllLocalCompanionData());
        privacy.addView(clearLocal);

        privacy.addView(text("Local revoke/clear affects only this Android device. To remove imported records, revoke server-side tokens, or apply retention policy, use Virii8 Core/Workspace.", 12, muted, false));
        return privacy;
    }

    private void showPrivacySummary() {
        String summary = buildPrivacySummary();
        prefs.edit().putString(KEY_LAST_PRIVACY_ACTION, nowStamp() + " • privacy summary viewed").apply();
        appendHistory("privacy", "Privacy summary viewed locally.");
        refreshStatus(summary);
    }

    private void sharePrivacySummary() {
        String summary = buildPrivacySummary();
        prefs.edit().putString(KEY_LAST_PRIVACY_ACTION, nowStamp() + " • privacy summary shared/opened").apply();
        appendHistory("privacy", "Privacy summary share sheet opened.");
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, "Virii8 Companion privacy summary v" + APP_VERSION);
            send.putExtra(Intent.EXTRA_TEXT, summary);
            startActivity(Intent.createChooser(send, "Share Virii8 Companion privacy summary"));
            refreshStatus("Privacy summary prepared. No bridge token is included.");
        } catch (Exception e) {
            refreshStatus("Privacy summary share failed: " + e.getMessage() + "\n\n" + summary);
        }
    }

    private String buildPrivacySummary() {
        StringBuilder b = new StringBuilder();
        b.append("Virii8 Companion Privacy Summary\n");
        b.append("Generated: ").append(nowStamp()).append("\n");
        b.append("App version: ").append(APP_VERSION).append("\n");
        b.append("Paired: ").append(tokenStore.isPaired()).append("\n");
        b.append("Virii8 site: ").append(tokenStore.getSiteUrl()).append("\n");
        b.append("Device label: ").append(tokenStore.getDeviceLabel()).append("\n");
        b.append("Enabled categories: ").append(selectedCategorySummary()).append("\n");
        b.append("Background sync: ").append(backgroundPolicySummary()).append("\n");
        b.append("Encrypted offline queue count: ").append(pendingQueueCount()).append("\n");
        b.append("Local history count: ").append(syncHistoryCount()).append("\n");
        b.append("Privacy acknowledgement: ").append(prefs.getBoolean(KEY_PRIVACY_ACK, false)).append("\n");
        b.append("Privacy policy URL: ").append(siteUrlText()).append("/privacy-policy/\n");
        b.append("Support URL: ").append(siteUrlText()).append("/contact/\n");
        b.append("Last privacy action: ").append(prefs.getString(KEY_LAST_PRIVACY_ACTION, "none")).append("\n\n");
        b.append("What may sync now: ").append(selectedCategorySummary()).append(". Samsung Health permissions can still deny any selected category on-device.\n\n");
        b.append("This summary intentionally excludes the bridge token. Local revoke/clear affects this Android device only; Virii8 Core remains responsible for imported records, server-side token revocation, retention, audit, and tenant policy.\n");
        return b.toString();
    }

    private void openSamsungHealthPermissions() {
        appendHistory("privacy", "Open Samsung Health permissions/settings requested.");
        prefs.edit().putString(KEY_LAST_PRIVACY_ACTION, nowStamp() + " • opened Samsung Health permissions/settings").apply();
        try {
            Intent settings = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:com.sec.android.app.shealth"));
            startActivity(settings);
            refreshStatus("Opened Samsung Health app settings. Use Samsung Health permission controls to review or revoke allowed health categories.");
            return;
        } catch (Exception ignored) {
            // Fall through to launch Samsung Health if available.
        }
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage("com.sec.android.app.shealth");
            if (launch != null) {
                startActivity(launch);
                refreshStatus("Opened Samsung Health. Review connected apps/data permissions inside Samsung Health settings.");
                return;
            }
            refreshStatus("Samsung Health is not installed or not visible to this build. Install/update Samsung Health, then request permissions again.");
        } catch (Exception e) {
            refreshStatus("Could not open Samsung Health settings: " + e.getMessage());
        }
    }

    private void openAndroidAppSettings() {
        appendHistory("privacy", "Open Android app settings requested.");
        prefs.edit().putString(KEY_LAST_PRIVACY_ACTION, nowStamp() + " • opened Android app settings").apply();
        try {
            Intent settings = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(settings);
            refreshStatus("Opened Android settings for Virii8 Companion. Use this for Android-level app permissions, battery, storage, or uninstall controls.");
        } catch (Exception e) {
            refreshStatus("Could not open Android app settings: " + e.getMessage());
        }
    }

    private void revokeLocalBridgeToken() {
        tokenStore.clear();
        if (pairingToken != null) pairingToken.setText("");
        BackgroundSyncScheduler.apply(this, prefs);
        prefs.edit().putString(KEY_LAST_PRIVACY_ACTION, nowStamp() + " • local bridge token revoked").apply();
        appendHistory("privacy", "Local bridge token revoked. Server-side token/records must be managed in Virii8 Core.");
        updateBridgeSummary();
        refreshStatus("Local bridge token removed from this phone. Also revoke the server-side bridge token in Virii8 Core if this phone is lost, retired, or no longer trusted.");
    }

    private void clearAllLocalCompanionData() {
        tokenStore.clear();
        SharedPreferences.Editor editor = prefs.edit();
        editor.clear();
        editor.putString(KEY_LAST_PRIVACY_ACTION, nowStamp() + " • all local companion data cleared");
        editor.apply();
        ensureDefaultCategoryPrefs();
        BackgroundSyncScheduler.apply(this, prefs);
        if (pairingToken != null) pairingToken.setText("");
        rebuildFromCurrent("All local Virii8 Companion data on this phone has been cleared: pairing token, preferences, sync history, offline queue, setup state, and background sync policy. This does not delete imported Virii8 Core records or server audit logs.");
    }


    private View samsungApprovalCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Samsung approval / app registration prep"));
        card.addView(text("Use this summary when registering the Virii8 Companion with Samsung Health Data SDK access. Submit the final release identity, not the debug package, for production approval.", 13, muted, false));
        card.addView(metricRow("Production package", "com.miltonmarketing.virii8.health"));
        card.addView(metricRow("Debug package", "com.miltonmarketing.virii8.health.debug — private testing only"));
        card.addView(metricRow("App label", "Virii8 Companion"));
        card.addView(metricRow("Samsung SDK", "Samsung Health Data SDK 1.1.0 bundled as samsung-health-data-api-1.1.0.aar"));
        card.addView(metricRow("Android target", "minSdk 29 / targetSdk 34 / compileSdk 34"));
        card.addView(metricRow("Release fingerprint", "Generate from the private release keystore and submit SHA-256 for production."));
        card.addView(metricRow("Debug fingerprint", "Use only for development/testing approval if Samsung requests it."));
        card.addView(metricRow("Health access", selectedCategorySummary()));
        card.addView(text("Current bridge is read-only. The app does not write to Samsung Health and does not send workout GPS route coordinates in this candidate.", 13, muted, false));
        Button copy = button("Copy Samsung approval summary", panelAlt, text);
        copy.setContentDescription("Copy Samsung app registration and SHA-256 approval summary");
        copy.setOnClickListener(v -> copyToClipboard("Virii8 Samsung approval summary", buildSamsungApprovalSummary()));
        card.addView(copy);
        Button openDocs = button("Open Samsung Health Data SDK page", panelAlt, text);
        openDocs.setOnClickListener(v -> openUrl("https://developer.samsung.com/health/data"));
        card.addView(openDocs);
        return card;
    }

    private String buildSamsungApprovalSummary() {
        StringBuilder b = new StringBuilder();
        b.append("Virii8 Companion Samsung Approval Summary\n");
        b.append("Generated: ").append(nowStamp()).append("\n");
        b.append("App label: Virii8 Companion\n");
        b.append("App version: ").append(APP_VERSION).append(" / versionCode ").append(APP_VERSION_CODE).append("\n");
        b.append("Production package: com.miltonmarketing.virii8.health\n");
        b.append("Debug/private-test package: com.miltonmarketing.virii8.health.debug\n");
        b.append("Samsung SDK: Samsung Health Data SDK 1.1.0\n");
        b.append("Android SDK: minSdk 29 / targetSdk 34 / compileSdk 34\n");
        b.append("Virii8 site: ").append(tokenStore.getSiteUrl()).append("\n");
        b.append("Bridge endpoint: /wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/sync\n");
        b.append("Status endpoint: /wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/status\n");
        b.append("Read categories: ").append(selectedCategorySummary()).append("\n");
        b.append("Samsung data direction: read-only from Samsung Health to Virii8 Core\n");
        b.append("Samsung writeback: none\n");
        b.append("Workout GPS route coordinates: not synced in this candidate\n");
        b.append("Pairing token: excluded from this summary\n");
        b.append("Production SHA-256: generate from the private release keystore with scripts/print-signing-fingerprints.sh or Gradle signingReport.\n");
        b.append("Debug SHA-256: private testing only; do not treat it as the production identity.\n");
        b.append("Approval status: prep candidate only; final approval still requires Samsung developer submission and real-device smoke testing.\n");
        return b.toString();
    }


    private View productionMetadataCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Production privacy / support / store prep"));
        card.addView(text("Use this summary before any public distribution, Samsung approval attachment, Play/App distribution listing, or client handoff. The companion remains a private bridge; Virii8 Core owns the health records, consent, retention, tenant policy, and audit surface.", 13, muted, false));
        card.addView(metricRow("Candidate status", "v1.0.5 production release candidate — pending real-device/Core runtime verification"));
        card.addView(metricRow("Privacy policy URL", siteUrlText() + "/privacy-policy/"));
        card.addView(metricRow("Support URL", siteUrlText() + "/contact/"));
        card.addView(metricRow("Data direction", "Samsung Health on-device read → Virii8 Core tokenized bridge"));
        card.addView(metricRow("Data deletion", "Local clear in app; imported records/server tokens controlled by Virii8 Core"));
        card.addView(metricRow("Medical positioning", "Wellness/private data bridge only; not medical advice, diagnosis, or emergency monitoring"));
        card.addView(metricRow("Sensitive data", "Health and fitness records; no bridge token in diagnostics; no workout GPS route coordinates in this candidate"));
        Button copy = button("Copy Production Metadata Summary", panelAlt, text);
        copy.setContentDescription("Copy production privacy support and store metadata summary");
        copy.setOnClickListener(v -> copyToClipboard("Virii8 production metadata summary", buildProductionMetadataSummary()));
        card.addView(copy);
        Button privacy = button("Open Privacy Policy URL", panelAlt, text);
        privacy.setOnClickListener(v -> openUrl(siteUrlText() + "/privacy-policy/"));
        card.addView(privacy);
        Button support = button("Open Support URL", panelAlt, text);
        support.setOnClickListener(v -> openUrl(siteUrlText() + "/contact/"));
        card.addView(support);
        return card;
    }

    private String buildProductionMetadataSummary() {
        StringBuilder b = new StringBuilder();
        b.append("Virii8 Companion Production Metadata Summary\n");
        b.append("Generated: ").append(nowStamp()).append("\n");
        b.append("App label: Virii8 Companion\n");
        b.append("App version: ").append(APP_VERSION).append(" / versionCode ").append(APP_VERSION_CODE).append("\n");
        b.append("Production package: com.miltonmarketing.virii8.health\n");
        b.append("Debug/private-test package: com.miltonmarketing.virii8.health.debug\n");
        b.append("Privacy policy URL: ").append(siteUrlText()).append("/privacy-policy/\n");
        b.append("Support URL: ").append(siteUrlText()).append("/contact/\n");
        b.append("Primary purpose: private Samsung Health to Virii8 Core health data bridge.\n");
        b.append("Data direction: read-only from Samsung Health on this device to Virii8 Core.\n");
        b.append("Samsung Health writeback: none.\n");
        b.append("Workout GPS route coordinates: not synced in this candidate.\n");
        b.append("Possible synced data: ").append(selectedCategorySummary()).append(".\n");
        b.append("Local data: encrypted bridge token, pairing/site/device label, preferences, sync history, diagnostics text, and offline queued sync payloads.\n");
        b.append("Server data: imported health records, server-side bridge tokens, retention state, audit logs, and tenant policy are controlled by Virii8 Core.\n");
        b.append("Diagnostics: excludes the bridge token.\n");
        b.append("Medical disclaimer: wellness/private data bridge only; not medical advice, diagnosis, treatment, or emergency monitoring.\n");
        b.append("Release status: production release candidate only; requires public policy/support URLs, release signing, Samsung approval, and real-device smoke testing before production distribution.\n");
        return b.toString();
    }


    private View finalReconciliationCard() {
        LinearLayout card = card(panelSoft);
        card.addView(sectionTitle("Final release reconciliation"));
        card.addView(text("This v1.0.5 candidate is aligned to Virii8 Core 1.6.1266 for the Samsung Health Data SDK bridge. It is ready for controlled private production-candidate testing, not broad public distribution until the runtime gates below are complete.", 13, muted, false));
        card.addView(metricRow("Android candidate", "Virii8 Companion v" + APP_VERSION + " / versionCode " + APP_VERSION_CODE));
        card.addView(metricRow("Core baseline", "Virii8 Ecosystem Core 1.6.1266 Health Bridge reconciliation"));
        card.addView(metricRow("Samsung SDK", "Samsung Health Data SDK 1.1.0 / read-only"));
        card.addView(metricRow("Bridge contract", "v1-samsung-health-data-sdk-1-1-0-readiness"));
        card.addView(metricRow("Runtime gates", "Samsung approval, signed release SHA-256, install smoke, permission smoke, sync smoke, Core imported-data map verification"));
        Button copy = button("Copy Final Reconciliation Summary", panelAlt, text);
        copy.setContentDescription("Copy Virii8 Companion final production release candidate reconciliation summary");
        copy.setOnClickListener(v -> copyToClipboard("Virii8 Companion final reconciliation", buildFinalReconciliationSummary()));
        card.addView(copy);
        return card;
    }

    private String buildFinalReconciliationSummary() {
        StringBuilder b = new StringBuilder();
        b.append("Virii8 Companion Final Reconciliation Summary\n");
        b.append("Generated: ").append(nowStamp()).append("\n");
        b.append("Android app: Virii8 Companion v").append(APP_VERSION).append(" / versionCode ").append(APP_VERSION_CODE).append("\n");
        b.append("Production package: com.miltonmarketing.virii8.health\n");
        b.append("Debug package: com.miltonmarketing.virii8.health.debug\n");
        b.append("Core baseline: Virii8 Ecosystem Core 1.6.1266 Health Bridge production reconciliation\n");
        b.append("Samsung SDK: Samsung Health Data SDK 1.1.0\n");
        b.append("Bridge endpoint: /wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/sync\n");
        b.append("Status endpoint: /wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/status\n");
        b.append("Device dashboard: /wp-json/v8e/v1/personal-health/bridge/devices\n");
        b.append("Imported data map: /wp-json/v8e/v1/personal-health/data-visibility\n");
        b.append("Selected categories: ").append(selectedCategorySummary()).append("\n");
        b.append("Release gates still required: signed release artifact, release SHA-256 registration, Samsung approval, public privacy/support URLs, real-device Samsung permission smoke, tokenized sync smoke, Core device dashboard check, imported-data map check, and rollback plan.\n");
        b.append("Security: no bridge token in this summary or diagnostics; token remains encrypted locally and hashed server-side.\n");
        return b.toString();
    }

    private View platformRoadmapCard() {
        LinearLayout card = card(panelSoft);
        card.addView(sectionTitle("Virii8 Ecosystem companion direction"));
        card.addView(helpLine("A", "Samsung Health bridge first: phone-side SDK access, Virii8-side normalized private records."));
        card.addView(helpLine("B", "Provider-neutral companion shell: future Health Connect, Fitbit, Garmin/CSV, Apple Health export import, and custom device imports."));
        card.addView(helpLine("C", "User customizations: theme, compact mode, enabled health categories, device label, safe external links."));
        card.addView(helpLine("D", "QR onboarding: Virii8 Core can render a pairing QR that launches this app with a secure pairing payload."));
        card.addView(helpLine("E", "Enterprise polish later: notification controls, admin-managed policy banners, push/device trust, and organization-managed mobile policy."));
        return card;
    }

    private View helpLine(String number, String copy) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(10), 0, 0);

        TextView badge = text(number, 13, readableOn(accent2), true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(rounded(accent2, dp(14), accent2, 0));
        row.addView(badge, new LinearLayout.LayoutParams(dp(28), dp(28)));

        TextView body = text(copy, 13, muted, false);
        LinearLayout.LayoutParams bodyParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        bodyParams.setMargins(dp(10), 0, 0, 0);
        row.addView(body, bodyParams);
        return row;
    }

    private View metricRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(8), 0, 0);
        TextView l = text(label, 12, warning, true);
        TextView v = text(value, 13, muted, false);
        v.setPadding(0, dp(2), 0, 0);
        row.addView(l);
        row.addView(v);
        return row;
    }

    private Button linkButton(String label, String url) {
        Button b = button(label, panelAlt, text);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(v -> openUrl(url));
        return b;
    }


    private void copyToClipboard(String label, String value) {
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard == null) {
                refreshStatus("Clipboard is unavailable on this device.");
                return;
            }
            String safe = value == null ? "" : value;
            clipboard.setPrimaryClip(ClipData.newPlainText(label, safe));
            appendHistory("diagnostics", "Copied " + label + " to clipboard.");
            refreshStatus(label + " copied to clipboard. Bridge tokens are not included unless you manually typed them into the copied text.");
        } catch (Exception e) {
            refreshStatus("Copy failed: " + e.getMessage());
        }
    }

    private String buildTroubleshootingSummary() {
        StringBuilder b = new StringBuilder();
        b.append("Virii8 Companion Troubleshooting Summary\n");
        b.append("Generated: ").append(nowStamp()).append("\n");
        b.append("Version: ").append(APP_VERSION).append("\n");
        b.append("Paired: ").append(tokenStore.isPaired()).append("\n");
        b.append("Setup done: ").append(prefs.getBoolean(KEY_SETUP_DONE, false)).append("; step ").append(setupStep()).append("\n");
        b.append("Network: ").append(isNetworkAvailable() ? "online" : "offline").append("\n");
        b.append("Categories: ").append(selectedCategorySummary()).append("\n");
        b.append("Queue: ").append(pendingQueueCount()).append(" pending batch(es)\n");
        b.append("Last status: ").append(lastStatus).append("\n\n");
        b.append("Next best action: ").append(nextBestActionText()).append("\n\n");
        b.append("Recent history:\n").append(syncHistoryPreview(8)).append("\n\n");
        b.append("No bridge token is included.\n");
        return b.toString();
    }

    private void openUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            refreshStatus("Could not open link: " + e.getMessage());
        }
    }

    private void pasteClipboardIntoQrPayload() {
        try {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard == null || !clipboard.hasPrimaryClip()) {
                refreshStatus("Clipboard is empty. Copy a Virii8 pairing QR payload or deep link first.");
                return;
            }
            ClipData clip = clipboard.getPrimaryClip();
            if (clip == null || clip.getItemCount() < 1) {
                refreshStatus("Clipboard does not contain text.");
                return;
            }
            CharSequence value = clip.getItemAt(0).coerceToText(this);
            if (value == null || value.toString().trim().isEmpty()) {
                refreshStatus("Clipboard text is empty.");
                return;
            }
            qrPayload.setText(value.toString().trim());
            refreshStatus("Clipboard copied into QR payload. Tap Import QR / deep-link pairing to review it.");
        } catch (Exception e) {
            refreshStatus("Clipboard paste failed: " + e.getMessage());
        }
    }

    private void importQrPayloadFromField() {
        String raw = qrPayload != null ? qrPayload.getText().toString().trim() : "";
        PairingPayload payload = parsePairingPayload(raw);
        if (!payload.hasPairing()) {
            refreshStatus("Could not find a Virii8 site URL and pairing token in that QR payload. Expected JSON, virii8://pair-health?... or site_url=...&pairing_token=...");
            return;
        }
        applyPairingPayload(payload, false);
    }

    private void applyPairingPayload(PairingPayload payload, boolean saveImmediately) {
        if (payload.siteUrl != null && siteUrl != null) siteUrl.setText(payload.siteUrl);
        if (payload.token != null && pairingToken != null) pairingToken.setText(payload.token);
        if (payload.deviceLabel != null && deviceLabel != null) deviceLabel.setText(payload.deviceLabel);
        String summary = "Imported " + payload.source + " pairing payload" + (payload.deviceLabel != null ? " for " + payload.deviceLabel : "") + ".";
        prefs.edit().putString(KEY_LAST_QR_PAIRING, summary).apply();
        appendHistory("pairing", summary);
        updateBridgeSummary();
        if (saveImmediately) {
            savePairing();
        } else {
            refreshStatus(summary + " Review the values, then tap Save secure pairing.");
        }
    }

    private PairingPayload parsePairingIntent(Intent intent) {
        if (intent == null) return PairingPayload.empty();
        Uri data = intent.getData();
        if (data == null) return PairingPayload.empty();
        return parsePairingPayload(data.toString());
    }

    private PairingPayload parsePairingPayload(String raw) {
        PairingPayload out = new PairingPayload();
        if (raw == null) return out;
        String value = raw.trim();
        if (value.isEmpty()) return out;

        if (value.startsWith("{")) {
            try {
                JSONObject json = new JSONObject(value);
                out.siteUrl = firstNonEmpty(json.optString("site_url", null), json.optString("site", null), json.optString("url", null));
                out.token = firstNonEmpty(json.optString("pairing_token", null), json.optString("token", null), json.optString("bridge_token", null));
                out.deviceLabel = firstNonEmpty(json.optString("device_label", null), json.optString("device", null), json.optString("label", null));
                out.source = "JSON QR";
                return out;
            } catch (JSONException ignored) {
                // Fall through to URI/query-string parsing.
            }
        }

        try {
            Uri uri = Uri.parse(value);
            String scheme = uri.getScheme();
            if (scheme != null && (scheme.equalsIgnoreCase("virii8") || scheme.equalsIgnoreCase("virii8companion") || scheme.equalsIgnoreCase("https"))) {
                out.siteUrl = firstNonEmpty(uri.getQueryParameter("site_url"), uri.getQueryParameter("site"), uri.getQueryParameter("url"));
                out.token = firstNonEmpty(uri.getQueryParameter("pairing_token"), uri.getQueryParameter("token"), uri.getQueryParameter("bridge_token"));
                out.deviceLabel = firstNonEmpty(uri.getQueryParameter("device_label"), uri.getQueryParameter("device"), uri.getQueryParameter("label"));
                out.source = "deep-link QR";
                return out;
            }
        } catch (Exception ignored) {
            // Fall through to query-string parsing.
        }

        if (value.contains("=") && value.contains("&")) {
            out.siteUrl = queryValue(value, "site_url", "site", "url");
            out.token = queryValue(value, "pairing_token", "token", "bridge_token");
            out.deviceLabel = queryValue(value, "device_label", "device", "label");
            out.source = "query-string QR";
        }
        return out;
    }

    private String queryValue(String query, String... keys) {
        if (query == null) return null;
        String clean = query;
        int q = clean.indexOf('?');
        if (q >= 0 && q < clean.length() - 1) clean = clean.substring(q + 1);
        for (String pair : clean.split("&")) {
            int eq = pair.indexOf('=');
            if (eq <= 0) continue;
            String key = decode(pair.substring(0, eq));
            String value = decode(pair.substring(eq + 1));
            for (String wanted : keys) {
                if (wanted.equalsIgnoreCase(key)) return value;
            }
        }
        return null;
    }

    private String decode(String value) {
        try {
            return URLDecoder.decode(value, StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return value;
        }
    }

    private String firstNonEmpty(String... values) {
        if (values == null) return null;
        for (String value : values) {
            if (value != null && !value.trim().isEmpty() && !"null".equalsIgnoreCase(value.trim())) {
                return value.trim();
            }
        }
        return null;
    }

    private static class PairingPayload {
        String siteUrl;
        String token;
        String deviceLabel;
        String source = "manual";

        boolean hasPairing() {
            return siteUrl != null && !siteUrl.trim().isEmpty() && token != null && !token.trim().isEmpty();
        }

        static PairingPayload empty() {
            return new PairingPayload();
        }
    }

    private void savePairing() {
        try {
            String url = siteUrl.getText().toString().trim();
            String token = pairingToken.getText().toString().trim();
            String label = deviceLabel.getText().toString().trim();
            if (!url.startsWith("https://")) throw new IllegalArgumentException("Use an HTTPS Virii8 site URL.");
            if (token.length() < 16) throw new IllegalArgumentException("Pairing token looks too short.");
            if (label.isEmpty()) label = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
            tokenStore.savePairing(url, token, label);
            if (pairingToken != null) pairingToken.setText("");
            appendHistory("pairing", "Secure pairing saved for " + label + " at " + url + ". Visible pairing token field cleared after secure save.");
            updateBridgeSummary();
            refreshStatus("Pairing saved securely on this device. QR/deep-link status: " + prefs.getString(KEY_LAST_QR_PAIRING, "manual pairing"));
        } catch (Exception e) {
            appendHistory("error", "Pairing failed: " + e.getMessage());
            refreshStatus("Pairing failed: " + e.getMessage());
        }
    }

    private void testVirii8Bridge() {
        if (!tokenStore.isPaired()) {
            appendHistory("warning", "Bridge status test skipped because this device is not paired.");
            refreshStatus("Not paired yet. Save your Virii8 site URL and pairing token first.");
            return;
        }
        appendHistory("status", "Virii8 bridge status test started for " + tokenStore.getSiteUrl() + ".");
        refreshStatus("Testing Virii8 Samsung bridge status…");
        networkExecutor.execute(() -> {
            try {
                String response = Virii8HealthApi.getBridgeStatus(tokenStore.getSiteUrl(), tokenStore.getToken());
                appendHistory("status", "Bridge status OK: " + shortResponse(response));
                runOnUiThread(() -> refreshStatus("Bridge status response: " + response));
            } catch (Exception e) {
                appendHistory("error", "Bridge status error: " + e.getMessage());
                runOnUiThread(() -> refreshStatus("Virii8 bridge status error: " + e.getMessage()));
            }
        });
    }


    private void requestSamsungPermissionsSelected() {
        Set<String> cats = selectedCategories();
        appendHistory("permissions", "Samsung permission request started for: " + selectedCategorySummary());
        samsungBridge.requestPermissions(
            cats,
            message -> {
                appendHistory("permissions", message);
                refreshStatus(message);
            },
            e -> {
                appendHistory("error", "Samsung permission error: " + e.getMessage());
                refreshStatus("Samsung permission error: " + e.getMessage());
            }
        );
    }

    private void syncToday() {
        if (!tokenStore.isPaired()) {
            appendHistory("warning", "Sync skipped because this device is not paired.");
            refreshStatus("Not paired yet. Save your Virii8 site URL and pairing token first.");
            return;
        }
        Set<String> cats = selectedCategories();
        if (cats.isEmpty()) {
            appendHistory("warning", "Sync skipped because no Health Bridge categories are selected.");
            refreshStatus("No Health Bridge categories are enabled. Enable at least one Health Bridge category before syncing.");
            return;
        }
        appendHistory("sync", "Started manual Sync Today for selected Samsung categories: " + selectedCategorySummary() + ".");
        refreshStatus("Reading today's selected Samsung Health records: steps, sleep, heart, and/or workouts depending on your enabled categories…");
        samsungBridge.readTodaySelectedRecords(cats, records -> {
            if (records.isEmpty()) {
                appendHistory("warning", "Samsung returned zero records for selected categories: " + selectedCategorySummary() + ".");
                refreshStatus("No records returned for selected categories. Check Samsung Health permissions, watch/phone data availability, and category toggles.");
                return;
            }
            appendHistory("sync", "Samsung returned " + records.size() + " health record(s); preparing Virii8 payload.");
            refreshStatus("Read " + records.size() + " Samsung Health records. Preparing Virii8 payload…");
            networkExecutor.execute(() -> {
                JSONObject payload = null;
                try {
                    payload = samsungBridge.buildSyncPayload(tokenStore.getDeviceLabel(), records, selectedCategories(), APP_VERSION);
                    if (!isNetworkAvailable()) {
                        queuePayload(payload, "network unavailable before send");
                        runOnUiThread(() -> refreshStatus("Network is unavailable. Prepared " + records.size() + " record(s) and queued the sync batch locally. Tap Retry Queued Sync when online."));
                        return;
                    }
                    String response = Virii8HealthApi.postSync(tokenStore.getSiteUrl(), tokenStore.getToken(), payload);
                    String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()) + " • " + records.size() + " health records • " + selectedCategorySummary();
                    prefs.edit().putString(KEY_LAST_SYNC, stamp).apply();
                    appendHistory("success", "Sync complete: " + records.size() + " health record(s). Virii8: " + shortResponse(response));
                    runOnUiThread(() -> refreshStatus("Sync complete. Virii8 response: " + response));
                } catch (Exception e) {
                    if (payload != null) {
                        queuePayload(payload, "Virii8 send failed: " + e.getMessage());
                        runOnUiThread(() -> refreshStatus("Virii8 sync error: " + e.getMessage() + "\nThe prepared batch was queued locally for retry."));
                    } else {
                        appendHistory("error", "Virii8 payload/sync error: " + e.getMessage());
                        runOnUiThread(() -> refreshStatus("Virii8 payload/sync error: " + e.getMessage()));
                    }
                }
            });
        }, e -> {
            appendHistory("error", "Samsung read error: " + e.getMessage());
            refreshStatus("Samsung read error: " + e.getMessage());
        });
    }

    private void updateBridgeSummary() {
        if (bridgeSummary == null || tokenStore == null) return;
        String paired = tokenStore.isPaired() ? "Paired" : "Not paired";
        String device = tokenStore.getDeviceLabel();
        String site = tokenStore.getSiteUrl();
        bridgeSummary.setText(paired + " • " + device + " • " + site + "\nSetup: " + (prefs.getBoolean(KEY_SETUP_DONE, false) ? "complete" : "step " + setupStep()) + " • Samsung SDK bridge: Virii8 Ecosystem companion v" + APP_VERSION + ". Selected categories: " + selectedCategorySummary() + ".");
    }

    private void updateSelectedCategoriesSummary() {
        if (selectedCategoriesSummary != null) {
            selectedCategoriesSummary.setText("Selected: " + selectedCategorySummary());
        }
        if (bridgeSummary != null) updateBridgeSummary();
    }

    private void rebuildFromCurrent(String message) {
        String currentSite = siteUrl != null ? siteUrl.getText().toString() : tokenStore.getSiteUrl();
        String currentToken = pairingToken != null ? pairingToken.getText().toString() : "";
        String currentDevice = deviceLabel != null ? deviceLabel.getText().toString() : tokenStore.getDeviceLabel();
        buildUi(currentSite, currentToken, currentDevice, message);
    }

    private LinearLayout card(int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(rounded(color, dp(20), panelAlt, 1));
        card.setLayoutParams(matchWrapBottom(dp(14)));
        return card;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 16, text, true);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 12, muted, true);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private EditText input(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextColor(text);
        e.setHintTextColor(muted);
        e.setBackground(rounded(panelAlt, dp(14), panelAlt, 0));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setMinHeight(dp(prefs.getBoolean(KEY_LARGE_TEXT, false) ? 54 : 48));
        e.setContentDescription(hint);
        e.setInputType(password ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return e;
    }

    private Button button(String s, int buttonBg, int buttonFg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(buttonFg);
        b.setTextSize(prefs.getBoolean(KEY_LARGE_TEXT, false) ? 15 : 14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setContentDescription(s);
        b.setBackground(rounded(buttonBg, dp(16), buttonBg, 0));
        b.setMinHeight(dp(prefs.getBoolean(KEY_LARGE_TEXT, false) ? 56 : 48));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(10), 0, 0);
        b.setLayoutParams(p);
        return b;
    }

    private CheckBox checkbox(String s, boolean checked) {
        CheckBox cb = new CheckBox(this);
        cb.setText(s);
        cb.setTextColor(text);
        cb.setTextSize(prefs.getBoolean(KEY_LARGE_TEXT, false) ? 15 : 14);
        cb.setTypeface(Typeface.DEFAULT_BOLD);
        cb.setChecked(checked);
        cb.setContentDescription(s + (checked ? ", checked" : ", not checked"));
        cb.setMinHeight(dp(prefs.getBoolean(KEY_LARGE_TEXT, false) ? 48 : 42));
        cb.setPadding(0, dp(8), 0, 0);
        return cb;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp + (prefs != null && prefs.getBoolean(KEY_LARGE_TEXT, false) ? 1 : 0));
        t.setTextColor(color);
        t.setLineSpacing(dp(1), prefs != null && prefs.getBoolean(KEY_LARGE_TEXT, false) ? 1.14f : 1.08f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }



    private void showPendingQueue() {
        refreshStatus("Offline queue:\n" + pendingQueuePreview());
    }

    private void clearPendingQueue() {
        removePendingQueue(nowStamp() + " • encrypted queue cleared locally");
        appendHistory("queue", "Encrypted offline queue cleared locally. This does not delete Virii8 Core health records or server audit logs.");
        refreshStatus("Encrypted offline queue cleared on this phone.");
    }

    private void retryPendingQueue() {
        if (!tokenStore.isPaired()) {
            appendHistory("warning", "Queued sync retry skipped because this device is not paired.");
            refreshStatus("Not paired yet. Save your Virii8 site URL and pairing token before retrying queued sync batches.");
            return;
        }
        JSONArray queue = loadPendingQueue();
        if (queue.length() == 0) {
            refreshStatus("Offline queue is empty. Nothing to retry.");
            return;
        }
        if (!isNetworkAvailable()) {
            appendHistory("warning", "Queued sync retry skipped because Android reports no active network.");
            refreshStatus("Network is unavailable. Queued batches remain on this device.");
            return;
        }
        appendHistory("queue", "Retrying " + queue.length() + " queued sync batch(es).");
        refreshStatus("Retrying " + queue.length() + " queued sync batch(es)…");
        networkExecutor.execute(() -> {
            JSONArray remaining = new JSONArray();
            int sent = 0;
            int failed = 0;
            for (int i = 0; i < queue.length(); i++) {
                JSONObject envelope = queue.optJSONObject(i);
                JSONObject payload = envelope == null ? null : envelope.optJSONObject("payload");
                if (payload == null) {
                    failed++;
                    continue;
                }
                try {
                    String response = Virii8HealthApi.postSync(tokenStore.getSiteUrl(), tokenStore.getToken(), payload);
                    sent++;
                    appendHistory("success", "Queued sync batch sent. Virii8: " + shortResponse(response));
                } catch (Exception e) {
                    failed++;
                    try {
                        if (envelope != null) {
                            envelope.put("last_error", sanitizeHistory(e.getMessage()));
                            envelope.put("last_retry_at", nowStamp());
                            remaining.put(envelope);
                        }
                    } catch (JSONException ignored) {
                        if (envelope != null) remaining.put(envelope);
                    }
                    appendHistory("error", "Queued sync retry failed: " + e.getMessage());
                }
            }
            savePendingQueue(remaining, nowStamp() + " • secure retry complete: " + sent + " sent, " + failed + " failed");
            int finalSent = sent;
            int finalFailed = failed;
            runOnUiThread(() -> refreshStatus("Queued sync retry complete. Sent: " + finalSent + "; still queued/failed: " + finalFailed + "."));
        });
    }

    private void queuePayload(JSONObject payload, String reason) {
        if (payload == null) return;
        JSONArray old = loadPendingQueue();
        JSONArray next = new JSONArray();
        int start = Math.max(0, old.length() - (QUEUE_LIMIT - 1));
        for (int i = start; i < old.length(); i++) {
            Object item = old.opt(i);
            if (item != null) next.put(item);
        }
        JSONObject envelope = new JSONObject();
        try {
            envelope.put("queued_at", nowStamp());
            envelope.put("reason", sanitizeHistory(reason));
            envelope.put("site_url", tokenStore.getSiteUrl());
            envelope.put("device_label", tokenStore.getDeviceLabel());
            envelope.put("selected_categories", selectedCategorySummary());
            envelope.put("payload", payload);
        } catch (JSONException ignored) {
            return;
        }
        next.put(envelope);
        if (savePendingQueue(next, nowStamp() + " • encrypted queued batch: " + sanitizeHistory(reason))) {
            appendHistory("queue", "Queued sync batch locally using AndroidKeyStore-backed encrypted storage: " + reason + ". Pending queue: " + next.length());
        } else {
            appendHistory("error", "Prepared sync batch could not be queued securely. The batch was not written to plaintext preferences.");
        }
    }

    private JSONArray loadPendingQueue() {
        migratePlainPendingQueueIfNeeded();
        String raw = "[]";
        try {
            raw = tokenStore.getSecureValue(KEY_PENDING_QUEUE, "[]");
        } catch (Exception e) {
            prefs.edit().putString(KEY_QUEUE_LAST_CHANGE, nowStamp() + " • secure queue read failed: " + sanitizeHistory(e.getMessage())).apply();
            appendHistory("error", "Encrypted offline queue could not be read: " + e.getMessage());
            return new JSONArray();
        }
        if (raw == null || raw.trim().isEmpty()) raw = "[]";
        try {
            return new JSONArray(raw);
        } catch (JSONException e) {
            removePendingQueue(nowStamp() + " • encrypted queue reset after malformed JSON");
            appendHistory("error", "Encrypted offline queue reset after malformed JSON: " + e.getMessage());
            return new JSONArray();
        }
    }

    private void migratePlainPendingQueueIfNeeded() {
        String plain = prefs.getString(KEY_PENDING_QUEUE, null);
        if (plain == null || plain.trim().isEmpty() || "[]".equals(plain.trim())) {
            if (plain != null) prefs.edit().remove(KEY_PENDING_QUEUE).apply();
            return;
        }
        try {
            String existingSecure = tokenStore.getSecureValue(KEY_PENDING_QUEUE, "[]");
            if (existingSecure == null || existingSecure.trim().isEmpty() || "[]".equals(existingSecure.trim())) {
                tokenStore.saveSecureValue(KEY_PENDING_QUEUE, plain);
                prefs.edit()
                    .remove(KEY_PENDING_QUEUE)
                    .putString(KEY_QUEUE_LAST_CHANGE, nowStamp() + " • migrated plaintext queue to AndroidKeyStore-backed encrypted storage")
                    .apply();
                appendHistory("queue", "Migrated existing offline queue into AndroidKeyStore-backed encrypted storage.");
            }
        } catch (Exception e) {
            prefs.edit().putString(KEY_QUEUE_LAST_CHANGE, nowStamp() + " • secure queue migration failed: " + sanitizeHistory(e.getMessage())).apply();
            appendHistory("error", "Encrypted offline queue migration failed; existing queue was not modified: " + e.getMessage());
        }
    }

    private boolean savePendingQueue(JSONArray queue, String changeSummary) {
        try {
            tokenStore.saveSecureValue(KEY_PENDING_QUEUE, queue == null ? "[]" : queue.toString());
            prefs.edit()
                .remove(KEY_PENDING_QUEUE)
                .putString(KEY_QUEUE_LAST_CHANGE, changeSummary)
                .apply();
            return true;
        } catch (Exception e) {
            prefs.edit().putString(KEY_QUEUE_LAST_CHANGE, nowStamp() + " • secure queue save failed: " + sanitizeHistory(e.getMessage())).apply();
            appendHistory("error", "Encrypted offline queue save failed: " + e.getMessage());
            return false;
        }
    }

    private void removePendingQueue(String changeSummary) {
        tokenStore.removeSecureValue(KEY_PENDING_QUEUE);
        prefs.edit().remove(KEY_PENDING_QUEUE).putString(KEY_QUEUE_LAST_CHANGE, changeSummary).apply();
    }

    private int pendingQueueCount() {
        return loadPendingQueue().length();
    }

    private String pendingQueuePreview() {
        JSONArray queue = loadPendingQueue();
        if (queue.length() == 0) return "No queued sync batches.";
        StringBuilder b = new StringBuilder();
        int limit = Math.min(queue.length(), 6);
        for (int i = 0; i < limit; i++) {
            JSONObject envelope = queue.optJSONObject(i);
            if (envelope == null) continue;
            if (b.length() > 0) b.append('\n');
            JSONObject payload = envelope.optJSONObject("payload");
            int records = payload == null ? 0 : payload.optJSONArray("records") == null ? 0 : payload.optJSONArray("records").length();
            b.append(i + 1).append(". ")
                .append(envelope.optString("queued_at", "queued"))
                .append(" • ").append(records).append(" record(s)")
                .append(" • ").append(envelope.optString("reason", "pending"));
        }
        if (queue.length() > limit) b.append("\n… ").append(queue.length() - limit).append(" more queued batch(es)");
        return b.toString();
    }

    private boolean isNetworkAvailable() {
        try {
            ConnectivityManager manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (manager == null) return true;
            NetworkInfo info = manager.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception ignored) {
            return true;
        }
    }

    private void showSyncHistory() {
        refreshStatus("Recent local sync history:\n" + syncHistoryPreview(HISTORY_LIMIT));
    }

    private void clearSyncHistory() {
        prefs.edit().remove(KEY_SYNC_HISTORY).apply();
        refreshStatus("Local sync history cleared on this phone. This does not delete Virii8 Core health records or server audit logs.");
    }

    private void shareDiagnostics() {
        String diagnostics = buildDiagnosticsReport();
        String stamp = nowStamp() + " • diagnostics shared/opened";
        prefs.edit().putString(KEY_LAST_DIAGNOSTICS_EXPORT, stamp).apply();
        appendHistory("diagnostics", "Diagnostics share sheet opened.");
        try {
            Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("text/plain");
            send.putExtra(Intent.EXTRA_SUBJECT, "Virii8 Companion diagnostics v" + APP_VERSION);
            send.putExtra(Intent.EXTRA_TEXT, diagnostics);
            startActivity(Intent.createChooser(send, "Share Virii8 Companion diagnostics"));
            refreshStatus("Diagnostics prepared. Choose where to send or copy them. No pairing token is included.");
        } catch (Exception e) {
            refreshStatus("Diagnostics share failed: " + e.getMessage() + "\n\n" + diagnostics);
        }
    }

    private String buildDiagnosticsReport() {
        StringBuilder b = new StringBuilder();
        b.append("Virii8 Companion Diagnostics\n");
        b.append("Generated: ").append(nowStamp()).append("\n");
        b.append("App version: ").append(APP_VERSION).append("\n");
        b.append("Package: ").append(getPackageName()).append("\n");
        b.append("Device: ").append(android.os.Build.MANUFACTURER).append(' ').append(android.os.Build.MODEL).append("\n");
        b.append("Android SDK: ").append(android.os.Build.VERSION.SDK_INT).append("\n");
        b.append("Layout: ").append(layoutModeLabel()).append("\n");
        b.append("Theme: ").append(themeName).append("\n");
        b.append("Compact mode: ").append(prefs.getBoolean(KEY_COMPACT, false)).append("\n");
        b.append("Setup done: ").append(prefs.getBoolean(KEY_SETUP_DONE, false)).append("; step ").append(setupStep()).append("\n");
        b.append("Paired: ").append(tokenStore.isPaired()).append("\n");
        b.append("Virii8 site: ").append(tokenStore.getSiteUrl()).append("\n");
        b.append("Device label: ").append(tokenStore.getDeviceLabel()).append("\n");
        b.append("Selected categories: ").append(selectedCategorySummary()).append("\n");
        b.append("Last sync: ").append(prefs.getString(KEY_LAST_SYNC, "none")).append("\n");
        b.append("Background mode: ").append(backgroundModeLabel()).append("\n");
        b.append("Background policy: ").append(backgroundPolicySummary()).append("\n");
        b.append("Background last run: ").append(prefs.getString(KEY_BACKGROUND_LAST_RUN, "none")).append("\n");
        b.append("Background last result: ").append(prefs.getString(KEY_BACKGROUND_LAST_RESULT, "none")).append("\n");
        b.append("Background next hint: ").append(prefs.getString(KEY_BACKGROUND_NEXT_HINT, "none")).append("\n");
        b.append("Privacy acknowledgement: ").append(prefs.getBoolean(KEY_PRIVACY_ACK, false)).append("\n");
        b.append("Privacy policy URL: ").append(siteUrlText()).append("/privacy-policy/\n");
        b.append("Support URL: ").append(siteUrlText()).append("/contact/\n");
        b.append("Last privacy action: ").append(prefs.getString(KEY_LAST_PRIVACY_ACTION, "none")).append("\n");
        b.append("Privacy policy URL: ").append(siteUrlText()).append("/privacy-policy/\n");
        b.append("Support URL: ").append(siteUrlText()).append("/contact/\n");
        b.append("Network available: ").append(isNetworkAvailable()).append("\n");
        b.append("Encrypted offline queue count: ").append(pendingQueueCount()).append("\n");
        b.append("Encrypted offline queue last change: ").append(prefs.getString(KEY_QUEUE_LAST_CHANGE, "none")).append("\n");
        b.append("Last QR pairing: ").append(prefs.getString(KEY_LAST_QR_PAIRING, "none")).append("\n");
        b.append("Last diagnostics export: ").append(prefs.getString(KEY_LAST_DIAGNOSTICS_EXPORT, "none")).append("\n");
        b.append("Production release candidate: v1.0.5 reconciles Android app identity, Samsung Health Data SDK 1.1.0, Core 1.6.1266 bridge endpoints, signing/SHA-256 workflow, privacy/support metadata, data-safety prep, and private testing checklist. Still requires Samsung approval, final signed artifact, public policy/support URLs, and real-device Core sync smoke testing before external production distribution.\n");
        b.append("QA next best action: ").append(nextBestActionText()).append("\n");
        b.append("\nOffline queue preview:\n").append(pendingQueuePreview()).append("\n");
        b.append("\nLocal sync history:\n").append(syncHistoryPreview(HISTORY_LIMIT)).append("\n");
        b.append("\nSecurity note: bridge tokens are intentionally excluded from this diagnostics report.\n");
        return b.toString();
    }

    private void appendHistory(String type, String message) {
        String line = nowStamp() + " • " + sanitizeHistory(type) + " • " + sanitizeHistory(message);
        String existing = prefs.getString(KEY_SYNC_HISTORY, "");
        String[] oldLines = existing == null || existing.trim().isEmpty() ? new String[0] : existing.split("\n");
        StringBuilder b = new StringBuilder(line);
        int kept = 1;
        for (String old : oldLines) {
            if (old == null || old.trim().isEmpty()) continue;
            if (kept >= HISTORY_LIMIT) break;
            b.append('\n').append(old.trim());
            kept++;
        }
        prefs.edit().putString(KEY_SYNC_HISTORY, b.toString()).apply();
    }

    private String syncHistoryPreview(int maxLines) {
        String history = prefs.getString(KEY_SYNC_HISTORY, "");
        if (history == null || history.trim().isEmpty()) return "No local sync events recorded yet.";
        String[] lines = history.split("\n");
        StringBuilder b = new StringBuilder();
        int limit = Math.max(1, Math.min(maxLines, lines.length));
        for (int i = 0; i < limit; i++) {
            if (lines[i] == null || lines[i].trim().isEmpty()) continue;
            if (b.length() > 0) b.append('\n');
            b.append(lines[i].trim());
        }
        if (lines.length > limit) b.append("\n… ").append(lines.length - limit).append(" older event(s) hidden");
        return b.toString();
    }

    private String latestHistoryLine() {
        String history = prefs.getString(KEY_SYNC_HISTORY, "");
        if (history == null || history.trim().isEmpty()) return "No local events yet.";
        String[] lines = history.split("\n");
        return lines.length > 0 ? lines[0] : "No local events yet.";
    }

    private int syncHistoryCount() {
        String history = prefs.getString(KEY_SYNC_HISTORY, "");
        if (history == null || history.trim().isEmpty()) return 0;
        int count = 0;
        for (String line : history.split("\n")) {
            if (line != null && !line.trim().isEmpty()) count++;
        }
        return count;
    }

    private String shortResponse(String response) {
        if (response == null) return "empty response";
        String clean = response.replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() > 180 ? clean.substring(0, 180) + "…" : clean;
    }

    private String nowStamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
    }

    private String sanitizeHistory(String value) {
        if (value == null) return "";
        String clean = value.replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() > 260 ? clean.substring(0, 260) + "…" : clean;
    }


    private String nextBestActionText() {
        if (!tokenStore.isPaired()) return "Pair this phone with Virii8 first. Use QR/deep-link pairing or paste the bridge token, then tap Save secure pairing.";
        if (selectedCategories().isEmpty()) return "Choose at least one Health Bridge category before requesting Samsung permissions or syncing.";
        if (!prefs.getBoolean(KEY_PRIVACY_ACK, false)) return "Review the Privacy tab and acknowledge that Virii8 Companion is a private wellness-data bridge, not medical care.";
        if (!isNetworkAvailable() && pendingQueueCount() > 0) return "Network is offline. Queued sync batches are safe locally; reconnect and tap Retry Queued Sync.";
        if (pendingQueueCount() > 0) return "Queued sync batches are waiting. Tap Retry Queued Sync from the Sync tab.";
        if (!prefs.getBoolean(KEY_SETUP_DONE, false)) return "Finish the setup wizard so the companion starts in a clean ready state next time.";
        return "Ready. Test the Virii8 bridge, run Sync Today, or adjust background sync from the Sync tab.";
    }

    private String augmentStatusMessage(String message) {
        String clean = message == null ? "" : message;
        if (!prefs.getBoolean(KEY_STATUS_HELP, true) || clean.contains("Next step:")) return clean;
        String lower = clean.toLowerCase(Locale.US);
        String help = null;
        if (lower.contains("not paired") || lower.contains("pairing failed")) {
            help = "Next step: open Home, paste or scan a Virii8 pairing payload, review the site/token/device label, then tap Save secure pairing.";
        } else if (lower.contains("network is unavailable") || lower.contains("offline")) {
            help = "Next step: reconnect to Wi-Fi/mobile data. Prepared batches remain in the local offline queue until Retry Queued Sync succeeds.";
        } else if (lower.contains("samsung permission") || lower.contains("permission")) {
            help = "Next step: open Privacy → Samsung Health permissions, approve only the categories you want, then run Sync Today again.";
        } else if (lower.contains("no records returned") || lower.contains("zero records")) {
            help = "Next step: confirm Samsung Health has data for today and that the matching category is enabled in the Data tab.";
        } else if (lower.contains("bridge status error") || lower.contains("virii8 sync error") || lower.contains("payload/sync error")) {
            help = "Next step: use Share Diagnostics from Help or Sync. The diagnostics exclude the bridge token.";
        } else if (lower.contains("sync complete") || lower.contains("bridge status response")) {
            help = "Next step: review Sync history or open the Virii8 Health dashboard to confirm imported records.";
        }
        return help == null ? clean : clean + "\n\n" + help;
    }

    private void refreshStatus(String message) {
        lastStatus = augmentStatusMessage(message);
        if (status != null) {
            status.setText(lastStatus);
            status.setContentDescription("Current Virii8 Companion status. " + lastStatus);
        }
    }

    private String layoutModeLabel() {
        Configuration cfg = getResources().getConfiguration();
        int widthDp = Math.max(320, cfg.screenWidthDp);
        int heightDp = Math.max(320, cfg.screenHeightDp);
        int smallestDp = Math.max(0, cfg.smallestScreenWidthDp);
        boolean landscape = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE || widthDp > heightDp;
        boolean tablet = smallestDp >= 600 || widthDp >= 720;
        boolean foldableWide = widthDp >= 520 && heightDp >= 520;
        if (landscape && tablet) return "landscape tablet";
        if (landscape) return "landscape phone/foldable";
        if (tablet) return "portrait tablet";
        if (foldableWide) return "portrait foldable/wide";
        return "portrait phone";
    }

    private void ensureDefaultCategoryPrefs() {
        if (!prefs.contains("cat_" + CAT_STEPS)) {
            prefs.edit()
                .putBoolean("cat_" + CAT_STEPS, true)
                .putBoolean("cat_" + CAT_SLEEP, true)
                .putBoolean("cat_" + CAT_HEART, true)
                .putBoolean("cat_" + CAT_WORKOUTS, false)
                .putBoolean("cat_" + CAT_NUTRITION, false)
                .putBoolean("cat_" + CAT_BODY, false)
                .putBoolean(KEY_ADVANCED, true)
                .putBoolean(KEY_LARGE_TEXT, false)
                .putBoolean(KEY_STATUS_HELP, true)
                .putString(KEY_BACKGROUND_MODE, MODE_MANUAL)
                .putBoolean(KEY_BACKGROUND_WIFI_ONLY, true)
                .putBoolean(KEY_BACKGROUND_CHARGING_ONLY, false)
                .putBoolean(KEY_BACKGROUND_PAUSED, false)
                .apply();
        }
    }

    private Set<String> selectedCategories() {
        Set<String> out = new LinkedHashSet<>();
        for (String key : Arrays.asList(CAT_STEPS, CAT_SLEEP, CAT_HEART, CAT_WORKOUTS, CAT_NUTRITION, CAT_BODY)) {
            if (prefs.getBoolean("cat_" + key, CAT_STEPS.equals(key))) out.add(key);
        }
        return out;
    }

    private String selectedCategorySummary() {
        Set<String> cats = selectedCategories();
        if (cats.isEmpty()) return "none";
        StringBuilder b = new StringBuilder();
        for (String key : cats) {
            if (b.length() > 0) b.append(", ");
            b.append(categoryLabel(key));
        }
        return b.toString();
    }

    private String categoryLabel(String key) {
        if (CAT_STEPS.equals(key)) return "steps";
        if (CAT_SLEEP.equals(key)) return "sleep";
        if (CAT_HEART.equals(key)) return "heart";
        if (CAT_WORKOUTS.equals(key)) return "workouts";
        if (CAT_NUTRITION.equals(key)) return "nutrition/hydration";
        if (CAT_BODY.equals(key)) return "body metrics";
        return key;
    }

    private String backgroundMode() {
        return prefs.getString(KEY_BACKGROUND_MODE, MODE_MANUAL);
    }

    private String backgroundModeLabel() {
        String mode = backgroundMode();
        if (MODE_DAILY.equals(mode)) return "Daily";
        if (MODE_SIX_HOUR.equals(mode)) return "Every 6 hours";
        return "Manual only";
    }

    private void setBackgroundMode(String mode) {
        String clean = MODE_DAILY.equals(mode) || MODE_SIX_HOUR.equals(mode) ? mode : MODE_MANUAL;
        prefs.edit().putString(KEY_BACKGROUND_MODE, clean).apply();
        BackgroundSyncScheduler.apply(this, prefs);
        appendHistory("background", "Background sync mode changed to " + backgroundModeLabel() + ".");
        rebuildFromCurrent("Background sync mode changed to " + backgroundModeLabel() + ". " + backgroundPolicySummary());
    }

    private String backgroundPolicySummary() {
        if (prefs.getBoolean(KEY_BACKGROUND_PAUSED, false)) return backgroundModeLabel() + " • paused";
        StringBuilder b = new StringBuilder(backgroundModeLabel());
        if (prefs.getBoolean(KEY_BACKGROUND_WIFI_ONLY, true)) b.append(" • Wi-Fi only"); else b.append(" • any network");
        if (prefs.getBoolean(KEY_BACKGROUND_CHARGING_ONLY, false)) b.append(" • charging only");
        if (!tokenStore.isPaired()) b.append(" • not paired");
        return b.toString();
    }

    private void applyThemeFromPreferences() {
        String theme = prefs.getString(KEY_THEME, "ocean");
        if ("matrix".equals(theme)) {
            themeName = "Matrix";
            bg = Color.rgb(2, 8, 4);
            panel = Color.rgb(7, 26, 14);
            panelAlt = Color.rgb(13, 45, 25);
            panelSoft = Color.rgb(4, 20, 11);
            text = Color.rgb(232, 255, 236);
            muted = Color.rgb(157, 205, 166);
            accent = Color.rgb(34, 197, 94);
            accent2 = Color.rgb(132, 204, 22);
            warning = Color.rgb(250, 204, 21);
            danger = Color.rgb(248, 113, 113);
        } else if ("light".equals(theme)) {
            themeName = "Light";
            bg = Color.rgb(242, 247, 251);
            panel = Color.WHITE;
            panelAlt = Color.rgb(225, 235, 244);
            panelSoft = Color.rgb(232, 245, 249);
            text = Color.rgb(12, 29, 43);
            muted = Color.rgb(75, 95, 110);
            accent = Color.rgb(7, 119, 182);
            accent2 = Color.rgb(0, 150, 136);
            warning = Color.rgb(160, 99, 0);
            danger = Color.rgb(185, 28, 28);
        } else if ("contrast".equals(theme)) {
            themeName = "High contrast";
            bg = Color.BLACK;
            panel = Color.rgb(12, 12, 12);
            panelAlt = Color.rgb(32, 32, 32);
            panelSoft = Color.rgb(20, 20, 20);
            text = Color.WHITE;
            muted = Color.rgb(220, 220, 220);
            accent = Color.rgb(255, 213, 0);
            accent2 = Color.rgb(0, 229, 255);
            warning = Color.rgb(255, 213, 0);
            danger = Color.rgb(255, 82, 82);
        } else {
            themeName = "Ocean";
            bg = Color.rgb(7, 19, 31);
            panel = Color.rgb(14, 34, 53);
            panelAlt = Color.rgb(19, 43, 66);
            panelSoft = Color.rgb(11, 28, 45);
            text = Color.rgb(243, 250, 255);
            muted = Color.rgb(159, 183, 200);
            accent = Color.rgb(34, 211, 238);
            accent2 = Color.rgb(94, 234, 212);
            warning = Color.rgb(251, 191, 36);
            danger = Color.rgb(248, 113, 113);
        }
    }

    private int readableOn(int color) {
        int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
        double luminance = (0.299 * r + 0.587 * g + 0.114 * b);
        return luminance > 150 ? Color.rgb(4, 18, 28) : Color.WHITE;
    }

    private GradientDrawable rounded(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (strokeWidth > 0) drawable.setStroke(dp(strokeWidth), strokeColor);
        return drawable;
    }

    private String siteUrlText() {
        String url = siteUrl != null ? siteUrl.getText().toString().trim() : tokenStore.getSiteUrl();
        if (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url.isEmpty() ? "https://miltonmarketing.com" : url;
    }

    private LinearLayout.LayoutParams matchWrapBottom(int bottomMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 0, 0, bottomMargin);
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
