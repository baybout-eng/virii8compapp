package com.miltonmarketing.virii8.health;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

final class Virii8HealthApi {
    private Virii8HealthApi() {}

    static String postSync(String siteUrl, String bearerToken, JSONObject payload) throws Exception {
        String base = siteUrl.endsWith("/") ? siteUrl.substring(0, siteUrl.length() - 1) : siteUrl;
        URL url = new URL(base + "/wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/sync");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(30000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + bearerToken);
        byte[] bytes = payload.toString().getBytes(StandardCharsets.UTF_8);
        try (OutputStream os = connection.getOutputStream()) {
            os.write(bytes);
        }
        int status = connection.getResponseCode();
        String body = readResponseBody(connection, status);
        if (status < 200 || status >= 300) {
            throw new IllegalStateException("Virii8 sync failed: HTTP " + status + safeResponseMessage(connection));
        }
        return body;
    }
    static String getBridgeStatus(String siteUrl, String bearerToken) throws Exception {
        String base = siteUrl.endsWith("/") ? siteUrl.substring(0, siteUrl.length() - 1) : siteUrl;
        URL url = new URL(base + "/wp-json/v8e/v1/personal-health/bridge/samsung-health-data-sdk/status");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(15000);
        connection.setReadTimeout(30000);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Authorization", "Bearer " + bearerToken);
        int status = connection.getResponseCode();
        String body = readResponseBody(connection, status);
        if (status < 200 || status >= 300) {
            throw new IllegalStateException("Virii8 bridge status failed: HTTP " + status + safeResponseMessage(connection));
        }
        return body;
    }

    private static String readResponseBody(HttpURLConnection connection, int status) throws Exception {
        InputStream stream = status >= 200 && status < 300 ? connection.getInputStream() : connection.getErrorStream();
        if (stream == null) return "";
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            StringBuilder body = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) body.append(line);
            return body.toString();
        }
    }

    private static String safeResponseMessage(HttpURLConnection connection) {
        try {
            String message = connection.getResponseMessage();
            return message == null || message.trim().isEmpty() ? "" : " " + message.trim();
        } catch (Exception ignored) {
            return "";
        }
    }

}
