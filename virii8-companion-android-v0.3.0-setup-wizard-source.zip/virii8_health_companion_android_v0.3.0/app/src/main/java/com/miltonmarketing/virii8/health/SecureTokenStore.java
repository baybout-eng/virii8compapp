package com.miltonmarketing.virii8.health;

import android.content.Context;
import android.content.SharedPreferences;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Small AndroidKeyStore-backed token store. Keeps Virii8 bridge tokens out of plain SharedPreferences.
 */
final class SecureTokenStore {
    private static final String PREFS = "virii8_health_secure";
    private static final String KEY_ALIAS = "virii8_health_bridge_token_v1";
    private static final String TOKEN_BLOB = "token_blob";
    private static final String TOKEN_IV = "token_iv";
    private static final String SITE_URL = "site_url";
    private static final String DEVICE_LABEL = "device_label";
    private static final String ANDROID_KEYSTORE = "AndroidKeyStore";
    private static final String AES_GCM = "AES/GCM/NoPadding";

    private final SharedPreferences prefs;

    SecureTokenStore(Context context) {
        this.prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    void savePairing(String siteUrl, String token, String deviceLabel) throws Exception {
        SecretKey key = getOrCreateKey();
        byte[] iv = new byte[12];
        new SecureRandom().nextBytes(iv);
        Cipher cipher = Cipher.getInstance(AES_GCM);
        cipher.init(Cipher.ENCRYPT_MODE, key, new GCMParameterSpec(128, iv));
        byte[] encrypted = cipher.doFinal(token.getBytes(StandardCharsets.UTF_8));
        prefs.edit()
            .putString(SITE_URL, siteUrl.trim())
            .putString(DEVICE_LABEL, deviceLabel.trim())
            .putString(TOKEN_IV, Base64.getEncoder().encodeToString(iv))
            .putString(TOKEN_BLOB, Base64.getEncoder().encodeToString(encrypted))
            .apply();
    }

    String getSiteUrl() {
        return prefs.getString(SITE_URL, "https://miltonmarketing.com");
    }

    String getDeviceLabel() {
        return prefs.getString(DEVICE_LABEL, android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
    }

    boolean isPaired() {
        return prefs.contains(TOKEN_BLOB) && prefs.contains(TOKEN_IV);
    }

    String getToken() throws Exception {
        String blob = prefs.getString(TOKEN_BLOB, null);
        String ivString = prefs.getString(TOKEN_IV, null);
        if (blob == null || ivString == null) return "";
        SecretKey key = getOrCreateKey();
        Cipher cipher = Cipher.getInstance(AES_GCM);
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, Base64.getDecoder().decode(ivString)));
        byte[] plain = cipher.doFinal(Base64.getDecoder().decode(blob));
        return new String(plain, StandardCharsets.UTF_8);
    }

    void clear() {
        prefs.edit().clear().apply();
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore keyStore = KeyStore.getInstance(ANDROID_KEYSTORE);
        keyStore.load(null);
        if (keyStore.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) keyStore.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator generator = KeyGenerator.getInstance("AES", ANDROID_KEYSTORE);
        android.security.keystore.KeyGenParameterSpec spec = new android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT | android.security.keystore.KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true)
            .build();
        generator.init(spec);
        return generator.generateKey();
    }
}
