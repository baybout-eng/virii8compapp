package com.miltonmarketing.virii8.health;

import android.app.Activity;
import android.os.Looper;

import com.samsung.android.sdk.health.data.HealthDataService;
import com.samsung.android.sdk.health.data.HealthDataStore;
import com.samsung.android.sdk.health.data.data.AggregatedData;
import com.samsung.android.sdk.health.data.permission.AccessType;
import com.samsung.android.sdk.health.data.permission.Permission;
import com.samsung.android.sdk.health.data.request.DataType;
import com.samsung.android.sdk.health.data.request.DataTypes;
import com.samsung.android.sdk.health.data.request.LocalTimeFilter;
import com.samsung.android.sdk.health.data.request.LocalTimeGroup;
import com.samsung.android.sdk.health.data.request.LocalTimeGroupUnit;
import com.samsung.android.sdk.health.data.request.Ordering;
import com.samsung.android.sdk.health.data.response.DataResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/** Samsung SDK-facing bridge. v0.3.0 supports selected category permissions and reads step aggregates for the first live sync reader. */
final class SamsungHealthBridge {
    private final Activity activity;
    private final HealthDataStore store;

    SamsungHealthBridge(Activity activity) {
        this.activity = activity;
        this.store = HealthDataService.getStore(activity);
    }

    Set<Permission> permissionsForCategories(Set<String> categories) {
        Set<Permission> permissions = new HashSet<>();
        if (categories == null || categories.contains("steps")) {
            permissions.add(Permission.of(DataTypes.STEPS, AccessType.READ));
        }
        if (categories != null && categories.contains("sleep")) {
            permissions.add(Permission.of(DataTypes.SLEEP, AccessType.READ));
            permissions.add(Permission.of(DataTypes.BLOOD_OXYGEN, AccessType.READ));
            permissions.add(Permission.of(DataTypes.SKIN_TEMPERATURE, AccessType.READ));
        }
        if (categories != null && categories.contains("heart")) {
            permissions.add(Permission.of(DataTypes.HEART_RATE, AccessType.READ));
        }
        if (categories != null && categories.contains("nutrition")) {
            permissions.add(Permission.of(DataTypes.NUTRITION, AccessType.READ));
            permissions.add(Permission.of(DataTypes.WATER_INTAKE, AccessType.READ));
        }
        if (categories != null && categories.contains("workouts")) {
            permissions.add(Permission.of(DataTypes.EXERCISE, AccessType.READ));
        }
        return permissions;
    }

    void requestPermissions(Set<String> categories, Consumer<String> success, Consumer<Throwable> failure) {
        Set<Permission> requested = permissionsForCategories(categories);
        if (requested.isEmpty()) {
            success.accept("No Samsung permission categories selected. Enable at least Activity / steps for the current live reader.");
            return;
        }
        store.requestPermissionsAsync(requested, activity).setCallback(
            Looper.getMainLooper(),
            granted -> {
                int grantedCount = granted == null ? 0 : granted.size();
                success.accept("Samsung Health permissions granted: " + grantedCount + " / " + requested.size());
            },
            failure
        );
    }

    void readTodaySteps(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        LocalTimeFilter filter = LocalTimeFilter.of(start, end);
        LocalTimeGroup group = LocalTimeGroup.of(LocalTimeGroupUnit.HOURLY, 1);
        com.samsung.android.sdk.health.data.request.AggregateRequest<Long> request = DataType.StepsType.TOTAL
            .getRequestBuilder()
            .setLocalTimeFilterWithGroup(filter, group)
            .setOrdering(Ordering.ASC)
            .build();

        store.aggregateDataAsync(request).setCallback(
            Looper.getMainLooper(),
            response -> success.accept(toStepRecords(response)),
            failure
        );
    }

    JSONObject buildSyncPayload(String deviceLabel, List<JSONObject> records, Set<String> selectedCategories, String companionVersion) throws Exception {
        JSONObject root = new JSONObject();
        JSONObject sdk = new JSONObject();
        sdk.put("provider", "samsung_health");
        sdk.put("sdk_version", "1.1.0");
        sdk.put("companion_version", companionVersion == null ? "0.3.0" : companionVersion);
        root.put("contract_version", "v1-samsung-health-data-sdk-1-1-0-readiness");
        root.put("device_label", deviceLabel);
        root.put("sdk", sdk);
        JSONArray categories = new JSONArray();
        if (selectedCategories != null) {
            for (String category : selectedCategories) categories.put(category);
        }
        root.put("selected_categories", categories);
        JSONArray array = new JSONArray();
        for (JSONObject record : records) array.put(record);
        root.put("records", array);
        return root;
    }

    private List<JSONObject> toStepRecords(DataResponse<AggregatedData<Long>> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (AggregatedData<Long> item : response.getDataList()) {
            try {
                JSONObject r = new JSONObject();
                r.put("recordType", "STEPS");
                r.put("startTime", item.getStartLocalDateTime().toString());
                r.put("endTime", item.getEndLocalDateTime().toString());
                r.put("value", item.getValueOrDefault(0L));
                r.put("unit", "count");
                records.add(r);
            } catch (Exception ignored) {
                // Skip malformed point rather than breaking a whole sync batch.
            }
        }
        return records;
    }
}
