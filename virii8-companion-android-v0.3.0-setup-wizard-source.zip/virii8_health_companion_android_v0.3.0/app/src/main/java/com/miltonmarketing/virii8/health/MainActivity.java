package com.miltonmarketing.virii8.health;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String APP_VERSION = "0.3.0";
    private static final String PREFS = "virii8_health_companion_preferences";
    private static final String KEY_THEME = "theme";
    private static final String KEY_COMPACT = "compact_mode";
    private static final String KEY_ADVANCED = "advanced_notes";
    private static final String KEY_LAST_SYNC = "last_sync_summary";
    private static final String KEY_SETUP_STEP = "setup_step";
    private static final String KEY_SETUP_DONE = "setup_done";

    private static final String CAT_STEPS = "steps";
    private static final String CAT_SLEEP = "sleep";
    private static final String CAT_HEART = "heart";
    private static final String CAT_WORKOUTS = "workouts";
    private static final String CAT_NUTRITION = "nutrition";
    private static final String CAT_BODY = "body_metrics";

    private static final String STATE_SITE = "state_site";
    private static final String STATE_TOKEN = "state_token";
    private static final String STATE_DEVICE = "state_device";
    private static final String STATE_STATUS = "state_status";

    private int bg;
    private int panel;
    private int panelAlt;
    private int panelSoft;
    private int text;
    private int muted;
    private int accent;
    private int accent2;
    private int warning;
    private int danger;
    private String themeName;

    private SecureTokenStore tokenStore;
    private SamsungHealthBridge samsungBridge;
    private SharedPreferences prefs;
    private EditText siteUrl;
    private EditText pairingToken;
    private EditText deviceLabel;
    private TextView status;
    private TextView bridgeSummary;
    private TextView selectedCategoriesSummary;
    private String lastStatus = "Ready. Start the setup wizard, pair this phone with Virii8, choose Health Bridge categories, grant Samsung permissions, then run Sync Today.";
    private final ExecutorService networkExecutor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tokenStore = new SecureTokenStore(this);
        samsungBridge = new SamsungHealthBridge(this);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        ensureDefaultCategoryPrefs();

        String initialSite = savedInstanceState != null ? savedInstanceState.getString(STATE_SITE, tokenStore.getSiteUrl()) : tokenStore.getSiteUrl();
        String initialToken = savedInstanceState != null ? savedInstanceState.getString(STATE_TOKEN, "") : "";
        String initialDevice = savedInstanceState != null ? savedInstanceState.getString(STATE_DEVICE, tokenStore.getDeviceLabel()) : tokenStore.getDeviceLabel();
        String initialStatus = savedInstanceState != null ? savedInstanceState.getString(STATE_STATUS, lastStatus) : lastStatus;
        buildUi(initialSite, initialToken, initialDevice, initialStatus);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        String currentSite = siteUrl != null ? siteUrl.getText().toString() : tokenStore.getSiteUrl();
        String currentToken = pairingToken != null ? pairingToken.getText().toString() : "";
        String currentDevice = deviceLabel != null ? deviceLabel.getText().toString() : tokenStore.getDeviceLabel();
        String currentStatus = status != null ? status.getText().toString() : lastStatus;
        buildUi(currentSite, currentToken, currentDevice, currentStatus + "\nAdaptive layout refreshed for " + layoutModeLabel() + ".");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (siteUrl != null) outState.putString(STATE_SITE, siteUrl.getText().toString());
        if (pairingToken != null) outState.putString(STATE_TOKEN, pairingToken.getText().toString());
        if (deviceLabel != null) outState.putString(STATE_DEVICE, deviceLabel.getText().toString());
        if (status != null) outState.putString(STATE_STATUS, status.getText().toString());
    }

    @Override
    protected void onDestroy() {
        networkExecutor.shutdownNow();
        super.onDestroy();
    }

    private void buildUi(String initialSite, String initialToken, String initialDevice, String initialStatus) {
        applyThemeFromPreferences();
        Configuration cfg = getResources().getConfiguration();
        int widthDp = Math.max(320, cfg.screenWidthDp);
        int heightDp = Math.max(320, cfg.screenHeightDp);
        int smallestDp = Math.max(0, cfg.smallestScreenWidthDp);
        boolean landscape = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE || widthDp > heightDp;
        boolean twoColumn = widthDp >= 520 || smallestDp >= 600 || (landscape && widthDp >= 430);
        boolean largeCanvas = widthDp >= 720 || smallestDp >= 720;
        boolean compact = widthDp < 380 || prefs.getBoolean(KEY_COMPACT, false);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);

        LinearLayout outer = new LinearLayout(this);
        outer.setOrientation(LinearLayout.VERTICAL);
        outer.setGravity(Gravity.CENTER_HORIZONTAL);
        outer.setPadding(dp(compact ? 10 : 20), dp(landscape ? 10 : 22), dp(compact ? 10 : 20), dp(24));
        scroll.addView(outer, new ScrollView.LayoutParams(ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int maxWidthPx = largeCanvas ? dp(1280) : LinearLayout.LayoutParams.MATCH_PARENT;
        LinearLayout.LayoutParams rootParams = new LinearLayout.LayoutParams(maxWidthPx, LinearLayout.LayoutParams.WRAP_CONTENT);
        rootParams.gravity = Gravity.CENTER_HORIZONTAL;
        outer.addView(root, rootParams);

        root.addView(header(twoColumn, compact, landscape));
        root.addView(setupWizardCard(twoColumn));
        root.addView(commandCenterCard(widthDp, heightDp, smallestDp, landscape, twoColumn));
        root.addView(bridgeStatusCard());

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(twoColumn ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        body.setGravity(Gravity.TOP);
        body.setLayoutParams(matchWrapBottom(dp(14)));

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);

        if (twoColumn) {
            LinearLayout.LayoutParams leftParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1.05f);
            leftParams.setMargins(0, 0, dp(8), 0);
            LinearLayout.LayoutParams rightParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 0.95f);
            rightParams.setMargins(dp(8), 0, 0, 0);
            body.addView(left, leftParams);
            body.addView(right, rightParams);
        } else {
            body.addView(left, matchWrapBottom(0));
            body.addView(right, matchWrapBottom(0));
        }

        left.addView(pairingCard(initialSite, initialToken, initialDevice));
        left.addView(actionsCard());
        left.addView(customizationCard(compact));

        right.addView(categoryCard());
        right.addView(dataCoverageCard());
        right.addView(linksCard());
        right.addView(privacyCard());

        if (prefs.getBoolean(KEY_ADVANCED, true)) {
            right.addView(platformRoadmapCard());
        }

        root.addView(body);

        status = text("", compact ? 13 : 14, text, false);
        status.setPadding(dp(14), dp(14), dp(14), dp(14));
        status.setGravity(Gravity.START);
        status.setBackground(rounded(panel, dp(18), panelAlt, 1));
        root.addView(status, matchWrapBottom(0));

        setContentView(scroll);
        updateBridgeSummary();
        updateSelectedCategoriesSummary();
        refreshStatus(initialStatus == null || initialStatus.trim().isEmpty() ? lastStatus : initialStatus);
    }

    private View header(boolean twoColumn, boolean compact, boolean landscape) {
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(twoColumn && landscape ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(0, 0, 0, dp(twoColumn ? 12 : 18));

        ImageView logo = new ImageView(this);
        logo.setImageResource(getResources().getIdentifier("mm_logo", "drawable", getPackageName()));
        int logoSize = dp(compact ? 64 : (twoColumn ? 78 : 90));
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(logoSize, logoSize);
        logoParams.gravity = Gravity.CENTER;
        if (twoColumn && landscape) logoParams.setMargins(0, 0, dp(16), 0);
        logo.setLayoutParams(logoParams);
        logo.setAdjustViewBounds(true);
        header.addView(logo);

        LinearLayout copy = new LinearLayout(this);
        copy.setOrientation(LinearLayout.VERTICAL);
        copy.setGravity(twoColumn && landscape ? Gravity.CENTER_VERTICAL : Gravity.CENTER_HORIZONTAL);

        TextView title = text("Virii8 Companion", twoColumn ? 22 : 25, text, true);
        title.setGravity(twoColumn && landscape ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        copy.addView(title);

        TextView subtitle = text("Ecosystem companion app • Health Bridge for Samsung devices", 14, muted, false);
        subtitle.setGravity(twoColumn && landscape ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        subtitle.setPadding(0, dp(5), 0, 0);
        copy.addView(subtitle);

        TextView version = text("v" + APP_VERSION + " setup wizard • " + themeName + " • " + layoutModeLabel(), 12, accent2, true);
        version.setGravity(twoColumn && landscape ? Gravity.START : Gravity.CENTER_HORIZONTAL);
        version.setPadding(0, dp(6), 0, 0);
        copy.addView(version);

        header.addView(copy, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        return header;
    }

    private View setupWizardCard(boolean twoColumn) {
        LinearLayout card = card(prefs.getBoolean(KEY_SETUP_DONE, false) ? panel : panelSoft);
        card.addView(sectionTitle("Guided setup wizard"));

        LinearLayout progress = new LinearLayout(this);
        progress.setOrientation(twoColumn ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        progress.setPadding(0, dp(4), 0, dp(8));
        for (int i = 1; i <= 6; i++) {
            int c = setupStep() == i ? accent : (prefs.getBoolean(KEY_SETUP_DONE, false) ? accent2 : panelAlt);
            progress.addView(chip("Step " + i, setupShortLabel(i), c), chipParams(twoColumn));
        }
        card.addView(progress);

        card.addView(text(setupStepTitle(setupStep()), 17, text, true));
        TextView body = text(setupStepBody(setupStep()), 13, muted, false);
        body.setPadding(0, dp(6), 0, dp(6));
        card.addView(body);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(twoColumn ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        row.setPadding(0, dp(6), 0, 0);

        Button back = button("Back", panelAlt, text);
        back.setEnabled(setupStep() > 1);
        back.setAlpha(setupStep() > 1 ? 1.0f : 0.45f);
        back.setOnClickListener(v -> setSetupStep(Math.max(1, setupStep() - 1), "Setup step changed: " + setupStepTitle(Math.max(1, setupStep() - 1))));
        row.addView(back, twoColumn ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) : matchWrapBottom(0));

        Button action = button(setupPrimaryButton(setupStep()), accent, readableOn(accent));
        action.setOnClickListener(v -> runSetupStepAction());
        row.addView(action, twoColumn ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) : matchWrapBottom(0));

        Button next = button(setupStep() >= 6 ? "Finish setup" : "Next", accent2, readableOn(accent2));
        next.setOnClickListener(v -> {
            if (setupStep() >= 6) {
                prefs.edit().putBoolean(KEY_SETUP_DONE, true).putInt(KEY_SETUP_STEP, 6).apply();
                rebuildFromCurrent("Setup marked complete. You can still change pairing, categories, permissions, and sync settings anytime.");
            } else {
                setSetupStep(setupStep() + 1, "Setup step changed: " + setupStepTitle(setupStep() + 1));
            }
        });
        row.addView(next, twoColumn ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) : matchWrapBottom(0));
        card.addView(row);

        if (prefs.getBoolean(KEY_SETUP_DONE, false)) {
            Button reopen = button("Reopen setup wizard", panelAlt, text);
            reopen.setOnClickListener(v -> {
                prefs.edit().putBoolean(KEY_SETUP_DONE, false).putInt(KEY_SETUP_STEP, 1).apply();
                rebuildFromCurrent("Setup wizard reopened.");
            });
            card.addView(reopen);
        }
        return card;
    }

    private int setupStep() {
        int step = prefs.getInt(KEY_SETUP_STEP, 1);
        if (step < 1) return 1;
        if (step > 6) return 6;
        return step;
    }

    private void setSetupStep(int step, String message) {
        int clean = Math.max(1, Math.min(6, step));
        prefs.edit().putInt(KEY_SETUP_STEP, clean).apply();
        rebuildFromCurrent(message);
    }

    private String setupShortLabel(int step) {
        switch (step) {
            case 1: return "Welcome";
            case 2: return "Connect";
            case 3: return "Categories";
            case 4: return "Permissions";
            case 5: return "First sync";
            case 6: return "Done";
            default: return "Setup";
        }
    }

    private String setupStepTitle(int step) {
        switch (step) {
            case 1: return "Welcome to Virii8 Companion";
            case 2: return "Connect this device to Virii8";
            case 3: return "Choose Health Bridge categories";
            case 4: return "Grant Samsung Health permissions";
            case 5: return "Run the first private sync";
            case 6: return "Review and finish";
            default: return "Guided setup";
        }
    }

    private String setupStepBody(int step) {
        switch (step) {
            case 1:
                return "This app is the Android companion for the Virii8 Ecosystem. The first active module is Health Bridge: Samsung Health stays on your phone, and approved records sync privately to Virii8 Core.";
            case 2:
                return "Generate a Samsung Health bridge token in Virii8, then paste your Virii8 site URL, pairing token, and device label in the Pair this phone card below.";
            case 3:
                return "Pick the health categories this phone is allowed to request. Samsung Health still gives the final on-device approval before data can be read.";
            case 4:
                return "Open the Samsung permission request for the selected categories. Denied categories will not be synced.";
            case 5:
                return "Run Sync Today to send today’s Samsung step aggregates through the tokenized Virii8 bridge. More readers are staged for later passes.";
            case 6:
                return "Confirm the device is paired, categories are correct, and the first sync has been tested. You can reopen this wizard anytime.";
            default:
                return "Follow each step to connect this phone safely.";
        }
    }

    private String setupPrimaryButton(int step) {
        switch (step) {
            case 1: return "Open MiltonMarketing";
            case 2: return "Show pairing instructions";
            case 3: return "Show selected categories";
            case 4: return "Grant selected permissions";
            case 5: return "Run Sync Today";
            case 6: return "Open Virii8 Workspace";
            default: return "Continue";
        }
    }

    private void runSetupStepAction() {
        switch (setupStep()) {
            case 1:
                openUrl("https://miltonmarketing.com");
                break;
            case 2:
                refreshStatus("Use the Pair this phone card below. Virii8 site URL must use HTTPS. Pairing token is encrypted locally after saving.");
                break;
            case 3:
                refreshStatus("Selected categories: " + selectedCategorySummary() + ". Adjust the Health Bridge categories card below.");
                break;
            case 4:
                samsungBridge.requestPermissions(
                    selectedCategories(),
                    this::refreshStatus,
                    e -> refreshStatus("Samsung permission error: " + e.getMessage())
                );
                break;
            case 5:
                syncToday();
                break;
            case 6:
                openUrl(siteUrlText() + "/workspace/");
                break;
            default:
                refreshStatus("Continue through the setup steps.");
        }
    }

    private View commandCenterCard(int widthDp, int heightDp, int smallestDp, boolean landscape, boolean twoColumn) {
        LinearLayout card = card(panelSoft);
        card.addView(sectionTitle("Companion command center"));
        card.addView(text("Use the setup wizard, customize the Health Bridge, choose sync categories, test the Virii8 endpoint, and keep Samsung Health permissions controlled on-device.", 13, muted, false));

        LinearLayout metrics = new LinearLayout(this);
        metrics.setOrientation(twoColumn ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        metrics.setPadding(0, dp(10), 0, 0);
        metrics.addView(chip("Setup", prefs.getBoolean(KEY_SETUP_DONE, false) ? "Complete" : "Step " + setupStep(), prefs.getBoolean(KEY_SETUP_DONE, false) ? accent2 : warning), chipParams(twoColumn));
        metrics.addView(chip("Pairing", tokenStore.isPaired() ? "Paired" : "Not paired", tokenStore.isPaired() ? accent2 : warning), chipParams(twoColumn));
        metrics.addView(chip("Display", twoColumn ? "Two-column" : "Single-column", accent), chipParams(twoColumn));
        metrics.addView(chip("Categories", selectedCategories().size() + " selected", accent2), chipParams(twoColumn));
        card.addView(metrics);

        card.addView(metricRow("Viewport", widthDp + "dp × " + heightDp + "dp" + (smallestDp > 0 ? " • smallest " + smallestDp + "dp" : "")));
        card.addView(metricRow("Rotation", landscape ? "Landscape / wide" : "Portrait / tall"));
        card.addView(metricRow("Last sync", prefs.getString(KEY_LAST_SYNC, "No successful sync recorded on this device yet.")));
        return card;
    }

    private LinearLayout.LayoutParams chipParams(boolean horizontal) {
        LinearLayout.LayoutParams p = horizontal ? new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f) : matchWrapBottom(dp(8));
        if (horizontal) p.setMargins(0, 0, dp(8), 0);
        return p;
    }

    private View chip(String label, String value, int chipAccent) {
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.VERTICAL);
        chip.setPadding(dp(12), dp(10), dp(12), dp(10));
        chip.setBackground(rounded(panelAlt, dp(16), chipAccent, 1));
        chip.addView(text(label, 11, muted, true));
        chip.addView(text(value, 14, text, true));
        return chip;
    }

    private View bridgeStatusCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Bridge status"));
        bridgeSummary = text("", 13, muted, false);
        bridgeSummary.setPadding(0, dp(6), 0, 0);
        card.addView(bridgeSummary);
        return card;
    }

    private View pairingCard(String initialSite, String initialToken, String initialDevice) {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Pair this phone"));
        card.addView(text("Paste the bridge token generated by Virii8 Health admin. The token is encrypted on this device and used only for private sync.", 13, muted, false));

        card.addView(label("Virii8 Site URL"));
        siteUrl = input("https://miltonmarketing.com", false);
        siteUrl.setText(initialSite == null || initialSite.trim().isEmpty() ? "https://miltonmarketing.com" : initialSite);
        card.addView(siteUrl);

        card.addView(label("Pairing Token"));
        pairingToken = input("Paste token generated in Virii8 Health admin", true);
        if (initialToken != null) pairingToken.setText(initialToken);
        card.addView(pairingToken);

        card.addView(label("Device Label"));
        deviceLabel = input("Samsung phone label", false);
        deviceLabel.setText(initialDevice == null || initialDevice.trim().isEmpty() ? android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL : initialDevice);
        card.addView(deviceLabel);

        Button save = button("Save secure pairing", accent, readableOn(accent));
        save.setOnClickListener(v -> savePairing());
        card.addView(save);
        return card;
    }

    private View actionsCard() {
        LinearLayout actions = card(panel);
        actions.addView(sectionTitle("Permissions and sync"));
        actions.addView(text("Request only the Samsung Health categories you enabled below. For v0.3.0, manual sync imports today’s step aggregates while the setup wizard prepares the companion for the next Health Bridge readers.", 13, muted, false));

        Button permissions = button("Grant selected Samsung permissions", accent2, readableOn(accent2));
        permissions.setOnClickListener(v -> samsungBridge.requestPermissions(
            selectedCategories(),
            this::refreshStatus,
            e -> refreshStatus("Samsung permission error: " + e.getMessage())
        ));
        actions.addView(permissions);

        Button testBridge = button("Test Virii8 bridge status", panelAlt, text);
        testBridge.setOnClickListener(v -> testVirii8Bridge());
        actions.addView(testBridge);

        Button sync = button("Sync Today", accent, readableOn(accent));
        sync.setOnClickListener(v -> syncToday());
        actions.addView(sync);

        Button dashboard = button("Open Virii8 Health Dashboard", panelAlt, text);
        dashboard.setOnClickListener(v -> openUrl(siteUrlText() + "/workspace/"));
        actions.addView(dashboard);

        Button disconnect = button("Disconnect This Phone", panelAlt, text);
        disconnect.setOnClickListener(v -> {
            tokenStore.clear();
            pairingToken.setText("");
            updateBridgeSummary();
            refreshStatus("Disconnected locally. Revoke the bridge token in Virii8 as well if this phone is lost or retired.");
        });
        actions.addView(disconnect);
        return actions;
    }

    private View customizationCard(boolean compact) {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Customize companion"));
        card.addView(text("These settings change this Android companion only. Virii8 Core still owns health data, privacy, tenant boundaries, and dashboard rendering.", 13, muted, false));
        card.addView(metricRow("Active theme", themeName));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(themeButton("Ocean", "ocean"), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row1.addView(themeButton("Matrix", "matrix"), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(row1);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(themeButton("Light", "light"), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        row2.addView(themeButton("Contrast", "contrast"), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(row2);

        CheckBox compactBox = checkbox("Compact cards / tighter spacing", prefs.getBoolean(KEY_COMPACT, false));
        compactBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_COMPACT, isChecked).apply();
            rebuildFromCurrent("Compact layout " + (isChecked ? "enabled" : "disabled") + ".");
        });
        card.addView(compactBox);

        CheckBox advancedBox = checkbox("Show advanced platform notes", prefs.getBoolean(KEY_ADVANCED, true));
        advancedBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_ADVANCED, isChecked).apply();
            rebuildFromCurrent("Advanced platform notes " + (isChecked ? "shown" : "hidden") + ".");
        });
        card.addView(advancedBox);
        return card;
    }

    private Button themeButton(String label, String key) {
        Button b = button(label, prefs.getString(KEY_THEME, "ocean").equals(key) ? accent : panelAlt, prefs.getString(KEY_THEME, "ocean").equals(key) ? readableOn(accent) : text);
        b.setOnClickListener(v -> {
            prefs.edit().putString(KEY_THEME, key).apply();
            rebuildFromCurrent("Theme changed to " + label + ".");
        });
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(4), dp(10), dp(4), 0);
        b.setLayoutParams(p);
        return b;
    }

    private View categoryCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Health Bridge categories"));
        card.addView(text("Choose what the companion should request and prepare for sync. You can still approve or deny categories inside Samsung Health.", 13, muted, false));
        selectedCategoriesSummary = text("", 13, accent2, true);
        selectedCategoriesSummary.setPadding(0, dp(8), 0, dp(4));
        card.addView(selectedCategoriesSummary);

        card.addView(categoryCheckbox(CAT_STEPS, "Activity / steps", "Current live reader: hourly step aggregates."));
        card.addView(categoryCheckbox(CAT_SLEEP, "Sleep", "Prepared: sleep sessions, stages, sleep oxygen, skin temperature."));
        card.addView(categoryCheckbox(CAT_HEART, "Heart", "Prepared: heart-rate samples and summaries."));
        card.addView(categoryCheckbox(CAT_WORKOUTS, "Workouts", "Prepared: exercise sessions and workout metadata."));
        card.addView(categoryCheckbox(CAT_NUTRITION, "Nutrition + hydration", "Prepared: food, nutrients, and water intake."));
        card.addView(categoryCheckbox(CAT_BODY, "Body metrics", "Prepared: blood pressure, glucose, temperature, body composition."));
        return card;
    }

    private View categoryCheckbox(String key, String title, String description) {
        LinearLayout wrap = new LinearLayout(this);
        wrap.setOrientation(LinearLayout.VERTICAL);
        wrap.setPadding(0, dp(8), 0, 0);
        CheckBox cb = checkbox(title, prefs.getBoolean("cat_" + key, CAT_STEPS.equals(key)));
        cb.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean("cat_" + key, isChecked).apply();
            updateSelectedCategoriesSummary();
            refreshStatus("Health category updated: " + selectedCategorySummary() + ". Samsung permission changes still require Grant selected Samsung permissions.");
        });
        wrap.addView(cb);
        TextView d = text(description, 12, muted, false);
        d.setPadding(dp(32), 0, 0, 0);
        wrap.addView(d);
        return wrap;
    }

    private View dataCoverageCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Capability roadmap"));
        card.addView(metricRow("Now", "Guided setup wizard plus manual Samsung step aggregate sync for today."));
        card.addView(metricRow("Next", "Sleep, heart-rate, workout, nutrition, hydration, and body metric readers."));
        card.addView(metricRow("Prepared", "Provider-neutral bridge model for Samsung Health, Health Connect, Fitbit, Apple Health export/import, and future wearables."));
        card.addView(metricRow("Protected", "Sleep apnea and irregular rhythm signals are sensitive wellness indicators, not diagnostic conclusions."));
        return card;
    }

    private View linksCard() {
        LinearLayout card = card(panel);
        card.addView(sectionTitle("Helpful links"));
        card.addView(text("Quick links for setup, platform docs, and third-party health ecosystems. These links leave the app.", 13, muted, false));
        card.addView(linkButton("MiltonMarketing.com", "https://miltonmarketing.com"));
        card.addView(linkButton("Virii8 Health articles", "https://miltonmarketing.com/?s=Virii8+Health"));
        card.addView(linkButton("Virii8 Workspace", siteUrlText() + "/workspace/"));
        card.addView(linkButton("Samsung Health Data SDK", "https://developer.samsung.com/health/data/guide/introduction.html"));
        card.addView(linkButton("Android Health Connect", "https://developer.android.com/health-and-fitness/health-connect"));
        card.addView(linkButton("Fitbit Web API", "https://developer.fitbit.com/build/reference/web-api/"));
        card.addView(linkButton("Apple HealthKit", "https://developer.apple.com/documentation/healthkit"));
        return card;
    }

    private View privacyCard() {
        LinearLayout privacy = card(panel);
        privacy.addView(sectionTitle("Privacy boundary"));
        privacy.addView(text("This app reads only the Samsung Health categories you approve on this phone and sends them to your private Virii8 Health module using a bridge token. It does not replace Samsung Health, Health Connect, Apple Health, Fitbit, or medical care.", 13, muted, false));
        privacy.addView(text("Strong rule: the companion is a bridge. Virii8 Core remains the source of truth for consent records, retention policy, tenant boundaries, dashboards, analytics, and audit logs.", 13, muted, false));
        return privacy;
    }

    private View platformRoadmapCard() {
        LinearLayout card = card(panelSoft);
        card.addView(sectionTitle("Virii8 Ecosystem companion direction"));
        card.addView(helpLine("A", "Samsung Health bridge first: phone-side SDK access, Virii8-side normalized private records."));
        card.addView(helpLine("B", "Provider-neutral companion shell: future Health Connect, Fitbit, Garmin/CSV, Apple Health export import, and custom device imports."));
        card.addView(helpLine("C", "User customizations: theme, compact mode, enabled health categories, device label, safe external links."));
        card.addView(helpLine("D", "Enterprise polish later: background sync, notification controls, offline queue, sync history, and admin-managed policy banners."));
        return card;
    }

    private View helpLine(String number, String copy) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.TOP);
        row.setPadding(0, dp(10), 0, 0);

        TextView badge = text(number, 13, readableOn(accent2), true);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(rounded(accent2, dp(14), accent2, 0));
        row.addView(badge, new LinearLayout.LayoutParams(dp(28), dp(28)));

        TextView body = text(copy, 13, muted, false);
        LinearLayout.LayoutParams bodyParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        bodyParams.setMargins(dp(10), 0, 0, 0);
        row.addView(body, bodyParams);
        return row;
    }

    private View metricRow(String label, String value) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(8), 0, 0);
        TextView l = text(label, 12, warning, true);
        TextView v = text(value, 13, muted, false);
        v.setPadding(0, dp(2), 0, 0);
        row.addView(l);
        row.addView(v);
        return row;
    }

    private Button linkButton(String label, String url) {
        Button b = button(label, panelAlt, text);
        b.setGravity(Gravity.CENTER);
        b.setOnClickListener(v -> openUrl(url));
        return b;
    }

    private void openUrl(String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception e) {
            refreshStatus("Could not open link: " + e.getMessage());
        }
    }

    private void savePairing() {
        try {
            String url = siteUrl.getText().toString().trim();
            String token = pairingToken.getText().toString().trim();
            String label = deviceLabel.getText().toString().trim();
            if (!url.startsWith("https://")) throw new IllegalArgumentException("Use an HTTPS Virii8 site URL.");
            if (token.length() < 16) throw new IllegalArgumentException("Pairing token looks too short.");
            if (label.isEmpty()) label = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
            tokenStore.savePairing(url, token, label);
            updateBridgeSummary();
            refreshStatus("Pairing saved securely on this device.");
        } catch (Exception e) {
            refreshStatus("Pairing failed: " + e.getMessage());
        }
    }

    private void testVirii8Bridge() {
        if (!tokenStore.isPaired()) {
            refreshStatus("Not paired yet. Save your Virii8 site URL and pairing token first.");
            return;
        }
        refreshStatus("Testing Virii8 Samsung bridge status…");
        networkExecutor.execute(() -> {
            try {
                String response = Virii8HealthApi.getBridgeStatus(tokenStore.getSiteUrl(), tokenStore.getToken());
                runOnUiThread(() -> refreshStatus("Bridge status response: " + response));
            } catch (Exception e) {
                runOnUiThread(() -> refreshStatus("Virii8 bridge status error: " + e.getMessage()));
            }
        });
    }

    private void syncToday() {
        if (!tokenStore.isPaired()) {
            refreshStatus("Not paired yet. Save your Virii8 site URL and pairing token first.");
            return;
        }
        if (!selectedCategories().contains(CAT_STEPS)) {
            refreshStatus("Steps are disabled in Health categories. Enable Activity / steps for the current v0.3.0 live sync reader.");
            return;
        }
        refreshStatus("Reading today's Samsung Health step aggregates…");
        samsungBridge.readTodaySteps(records -> {
            if (records.isEmpty()) {
                refreshStatus("No step records returned for today. Check Samsung Health permissions and data availability.");
                return;
            }
            refreshStatus("Read " + records.size() + " step records. Sending to Virii8…");
            networkExecutor.execute(() -> {
                try {
                    JSONObject payload = samsungBridge.buildSyncPayload(tokenStore.getDeviceLabel(), records, selectedCategories(), APP_VERSION);
                    String response = Virii8HealthApi.postSync(tokenStore.getSiteUrl(), tokenStore.getToken(), payload);
                    String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date()) + " • " + records.size() + " step records";
                    prefs.edit().putString(KEY_LAST_SYNC, stamp).apply();
                    runOnUiThread(() -> refreshStatus("Sync complete. Virii8 response: " + response));
                } catch (Exception e) {
                    runOnUiThread(() -> refreshStatus("Virii8 sync error: " + e.getMessage()));
                }
            });
        }, e -> refreshStatus("Samsung read error: " + e.getMessage()));
    }

    private void updateBridgeSummary() {
        if (bridgeSummary == null || tokenStore == null) return;
        String paired = tokenStore.isPaired() ? "Paired" : "Not paired";
        String device = tokenStore.getDeviceLabel();
        String site = tokenStore.getSiteUrl();
        bridgeSummary.setText(paired + " • " + device + " • " + site + "\nSetup: " + (prefs.getBoolean(KEY_SETUP_DONE, false) ? "complete" : "step " + setupStep()) + " • Samsung SDK bridge: Virii8 Ecosystem companion v" + APP_VERSION + ". Selected categories: " + selectedCategorySummary() + ".");
    }

    private void updateSelectedCategoriesSummary() {
        if (selectedCategoriesSummary != null) {
            selectedCategoriesSummary.setText("Selected: " + selectedCategorySummary());
        }
        if (bridgeSummary != null) updateBridgeSummary();
    }

    private void rebuildFromCurrent(String message) {
        String currentSite = siteUrl != null ? siteUrl.getText().toString() : tokenStore.getSiteUrl();
        String currentToken = pairingToken != null ? pairingToken.getText().toString() : "";
        String currentDevice = deviceLabel != null ? deviceLabel.getText().toString() : tokenStore.getDeviceLabel();
        buildUi(currentSite, currentToken, currentDevice, message);
    }

    private LinearLayout card(int color) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(rounded(color, dp(20), panelAlt, 1));
        card.setLayoutParams(matchWrapBottom(dp(14)));
        return card;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 16, text, true);
        t.setPadding(0, 0, 0, dp(6));
        return t;
    }

    private TextView label(String s) {
        TextView t = text(s, 12, muted, true);
        t.setPadding(0, dp(10), 0, dp(4));
        return t;
    }

    private EditText input(String hint, boolean password) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextColor(text);
        e.setHintTextColor(muted);
        e.setBackground(rounded(panelAlt, dp(14), panelAlt, 0));
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setInputType(password ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return e;
    }

    private Button button(String s, int buttonBg, int buttonFg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(buttonFg);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setAllCaps(false);
        b.setBackground(rounded(buttonBg, dp(16), buttonBg, 0));
        b.setMinHeight(dp(48));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(10), 0, 0);
        b.setLayoutParams(p);
        return b;
    }

    private CheckBox checkbox(String s, boolean checked) {
        CheckBox cb = new CheckBox(this);
        cb.setText(s);
        cb.setTextColor(text);
        cb.setTextSize(14);
        cb.setTypeface(Typeface.DEFAULT_BOLD);
        cb.setChecked(checked);
        cb.setPadding(0, dp(8), 0, 0);
        return cb;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setLineSpacing(dp(1), 1.08f);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private void refreshStatus(String message) {
        lastStatus = message == null ? "" : message;
        if (status != null) {
            status.setText(lastStatus);
        }
    }

    private String layoutModeLabel() {
        Configuration cfg = getResources().getConfiguration();
        int widthDp = Math.max(320, cfg.screenWidthDp);
        int heightDp = Math.max(320, cfg.screenHeightDp);
        int smallestDp = Math.max(0, cfg.smallestScreenWidthDp);
        boolean landscape = cfg.orientation == Configuration.ORIENTATION_LANDSCAPE || widthDp > heightDp;
        boolean tablet = smallestDp >= 600 || widthDp >= 720;
        boolean foldableWide = widthDp >= 520 && heightDp >= 520;
        if (landscape && tablet) return "landscape tablet";
        if (landscape) return "landscape phone/foldable";
        if (tablet) return "portrait tablet";
        if (foldableWide) return "portrait foldable/wide";
        return "portrait phone";
    }

    private void ensureDefaultCategoryPrefs() {
        if (!prefs.contains("cat_" + CAT_STEPS)) {
            prefs.edit()
                .putBoolean("cat_" + CAT_STEPS, true)
                .putBoolean("cat_" + CAT_SLEEP, true)
                .putBoolean("cat_" + CAT_HEART, true)
                .putBoolean("cat_" + CAT_WORKOUTS, false)
                .putBoolean("cat_" + CAT_NUTRITION, false)
                .putBoolean("cat_" + CAT_BODY, false)
                .putBoolean(KEY_ADVANCED, true)
                .apply();
        }
    }

    private Set<String> selectedCategories() {
        Set<String> out = new LinkedHashSet<>();
        for (String key : Arrays.asList(CAT_STEPS, CAT_SLEEP, CAT_HEART, CAT_WORKOUTS, CAT_NUTRITION, CAT_BODY)) {
            if (prefs.getBoolean("cat_" + key, CAT_STEPS.equals(key))) out.add(key);
        }
        return out;
    }

    private String selectedCategorySummary() {
        Set<String> cats = selectedCategories();
        if (cats.isEmpty()) return "none";
        StringBuilder b = new StringBuilder();
        for (String key : cats) {
            if (b.length() > 0) b.append(", ");
            b.append(categoryLabel(key));
        }
        return b.toString();
    }

    private String categoryLabel(String key) {
        if (CAT_STEPS.equals(key)) return "steps";
        if (CAT_SLEEP.equals(key)) return "sleep";
        if (CAT_HEART.equals(key)) return "heart";
        if (CAT_WORKOUTS.equals(key)) return "workouts";
        if (CAT_NUTRITION.equals(key)) return "nutrition/hydration";
        if (CAT_BODY.equals(key)) return "body metrics";
        return key;
    }

    private void applyThemeFromPreferences() {
        String theme = prefs.getString(KEY_THEME, "ocean");
        if ("matrix".equals(theme)) {
            themeName = "Matrix";
            bg = Color.rgb(2, 8, 4);
            panel = Color.rgb(7, 26, 14);
            panelAlt = Color.rgb(13, 45, 25);
            panelSoft = Color.rgb(4, 20, 11);
            text = Color.rgb(232, 255, 236);
            muted = Color.rgb(157, 205, 166);
            accent = Color.rgb(34, 197, 94);
            accent2 = Color.rgb(132, 204, 22);
            warning = Color.rgb(250, 204, 21);
            danger = Color.rgb(248, 113, 113);
        } else if ("light".equals(theme)) {
            themeName = "Light";
            bg = Color.rgb(242, 247, 251);
            panel = Color.WHITE;
            panelAlt = Color.rgb(225, 235, 244);
            panelSoft = Color.rgb(232, 245, 249);
            text = Color.rgb(12, 29, 43);
            muted = Color.rgb(75, 95, 110);
            accent = Color.rgb(7, 119, 182);
            accent2 = Color.rgb(0, 150, 136);
            warning = Color.rgb(160, 99, 0);
            danger = Color.rgb(185, 28, 28);
        } else if ("contrast".equals(theme)) {
            themeName = "High contrast";
            bg = Color.BLACK;
            panel = Color.rgb(12, 12, 12);
            panelAlt = Color.rgb(32, 32, 32);
            panelSoft = Color.rgb(20, 20, 20);
            text = Color.WHITE;
            muted = Color.rgb(220, 220, 220);
            accent = Color.rgb(255, 213, 0);
            accent2 = Color.rgb(0, 229, 255);
            warning = Color.rgb(255, 213, 0);
            danger = Color.rgb(255, 82, 82);
        } else {
            themeName = "Ocean";
            bg = Color.rgb(7, 19, 31);
            panel = Color.rgb(14, 34, 53);
            panelAlt = Color.rgb(19, 43, 66);
            panelSoft = Color.rgb(11, 28, 45);
            text = Color.rgb(243, 250, 255);
            muted = Color.rgb(159, 183, 200);
            accent = Color.rgb(34, 211, 238);
            accent2 = Color.rgb(94, 234, 212);
            warning = Color.rgb(251, 191, 36);
            danger = Color.rgb(248, 113, 113);
        }
    }

    private int readableOn(int color) {
        int r = Color.red(color), g = Color.green(color), b = Color.blue(color);
        double luminance = (0.299 * r + 0.587 * g + 0.114 * b);
        return luminance > 150 ? Color.rgb(4, 18, 28) : Color.WHITE;
    }

    private GradientDrawable rounded(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        if (strokeWidth > 0) drawable.setStroke(dp(strokeWidth), strokeColor);
        return drawable;
    }

    private String siteUrlText() {
        String url = siteUrl != null ? siteUrl.getText().toString().trim() : tokenStore.getSiteUrl();
        if (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url.isEmpty() ? "https://miltonmarketing.com" : url;
    }

    private LinearLayout.LayoutParams matchWrapBottom(int bottomMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 0, 0, bottomMargin);
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
