# Virii8 Companion Android v0.3.0

Professional Android companion app for the Virii8 Ecosystem.

The first active companion module is **Health Bridge**, which syncs approved Samsung Health data from a real Android/Samsung device into Virii8 Core through the tokenized Samsung Health Data SDK bridge.

## What v0.3.0 adds

- Renames product direction to **Virii8 Companion**.
- Adds a guided six-step setup wizard.
- Adds first-run onboarding language for Health Bridge.
- Adds setup progress chips.
- Adds wizard actions for pairing guidance, category review, Samsung permissions, first sync, and Virii8 workspace launch.
- Keeps responsive portrait/landscape/foldable layout from v0.2.0.
- Keeps theme chooser: Ocean, Matrix, Light, High Contrast.
- Keeps compact card mode and advanced notes toggle.
- Keeps health category preferences.
- Keeps Virii8 bridge status test button.
- Keeps manual Samsung step aggregate sync.
- Keeps local last-sync summary.

## Setup flow

1. Welcome to Virii8 Companion.
2. Connect this device to Virii8.
3. Choose Health Bridge categories.
4. Grant Samsung Health permissions.
5. Run the first private sync.
6. Review and finish.

## Important boundary

Samsung Health Data SDK runs on Android. Virii8 Core runs in WordPress. This app is only the phone-side companion bridge.

Virii8 Core owns:

- health records
- dashboards
- insights
- privacy/consent
- retention
- audit logs
- tenant/person/org boundaries

## Build with GitHub Actions

Upload this ZIP to the GitHub repo root using the filename your current workflow expects, then run the APK build Action.

The app version shown in the header must read:

`v0.3.0 setup wizard`

If the app still shows an older version, uninstall the old debug app and install the newly built APK.
