# Virii8 Companion Android

Version: 0.9.0 private testing candidate

Virii8 Companion is the Android-side bridge for the Virii8 Ecosystem. The first active module is Health Bridge for Samsung Health Data SDK 1.1.0.

The app pairs with Virii8 Core using a tokenized bridge, requests Samsung Health permissions on-device, reads approved health categories, and syncs normalized records to Virii8 Core.

## Build

Use GitHub Actions or a local Android build machine:

```bash
./gradlew --no-daemon clean assembleDebug
```

Expected private-testing artifact:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## Private testing checklist

See:

```text
docs/PRIVATE-TESTING-CHECKLIST-v0.9.0.md
```

## Not production-ready yet

This is not a store/release APK. Production still requires Samsung app approval/registration, release signing, privacy policy/store metadata, AAB/APK release build, and real-device smoke testing.
