#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
echo "Virii8 Companion source verification"
grep -n "versionCode 15" app/build.gradle
grep -n "versionName '0.9.0'" app/build.gradle
grep -n 'APP_VERSION = "0.9.0"' app/src/main/java/com/miltonmarketing/virii8/health/MainActivity.java
test -f app/libs/samsung-health-data-api-1.1.0.aar
find app/src/main -type f | sort
