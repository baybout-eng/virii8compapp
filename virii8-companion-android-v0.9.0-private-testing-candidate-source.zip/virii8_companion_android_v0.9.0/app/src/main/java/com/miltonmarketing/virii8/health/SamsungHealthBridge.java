package com.miltonmarketing.virii8.health;

import android.app.Activity;
import android.content.Context;
import android.os.Looper;

import com.samsung.android.sdk.health.data.HealthDataService;
import com.samsung.android.sdk.health.data.HealthDataStore;
import com.samsung.android.sdk.health.data.data.AggregatedData;
import com.samsung.android.sdk.health.data.data.AssociatedDataPoints;
import com.samsung.android.sdk.health.data.data.HealthDataPoint;
import com.samsung.android.sdk.health.data.data.entries.ExerciseLog;
import com.samsung.android.sdk.health.data.data.entries.ExerciseLocation;
import com.samsung.android.sdk.health.data.data.entries.ExerciseSession;
import com.samsung.android.sdk.health.data.data.entries.SleepSession;
import com.samsung.android.sdk.health.data.permission.AccessType;
import com.samsung.android.sdk.health.data.permission.Permission;
import com.samsung.android.sdk.health.data.request.AssociatedReadRequest;
import com.samsung.android.sdk.health.data.request.DataType;
import com.samsung.android.sdk.health.data.request.DataTypes;
import com.samsung.android.sdk.health.data.request.IdFilter;
import com.samsung.android.sdk.health.data.request.LocalTimeFilter;
import com.samsung.android.sdk.health.data.request.LocalTimeGroup;
import com.samsung.android.sdk.health.data.request.LocalTimeGroupUnit;
import com.samsung.android.sdk.health.data.request.Ordering;
import com.samsung.android.sdk.health.data.response.DataResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/** Samsung SDK-facing bridge. v0.6.0 supports manual and scheduled read-only sync while preserving steps, sleep, heart, workout, nutrition, hydration, and body metric readers. */
final class SamsungHealthBridge {
    private final Context context;
    private final Activity activity;
    private final HealthDataStore store;

    SamsungHealthBridge(Activity activity) {
        this.context = activity;
        this.activity = activity;
        this.store = HealthDataService.getStore(activity);
    }

    SamsungHealthBridge(Context context) {
        this.context = context.getApplicationContext();
        this.activity = null;
        this.store = HealthDataService.getStore(this.context);
    }

    Set<Permission> permissionsForCategories(Set<String> categories) {
        Set<Permission> permissions = new HashSet<>();
        if (categories == null || categories.contains("steps")) {
            permissions.add(Permission.of(DataTypes.STEPS, AccessType.READ));
        }
        if (categories != null && categories.contains("sleep")) {
            permissions.add(Permission.of(DataTypes.SLEEP, AccessType.READ));
            permissions.add(Permission.of(DataTypes.BLOOD_OXYGEN, AccessType.READ));
            permissions.add(Permission.of(DataTypes.SKIN_TEMPERATURE, AccessType.READ));
        }
        if (categories != null && categories.contains("heart")) {
            permissions.add(Permission.of(DataTypes.HEART_RATE, AccessType.READ));
        }
        if (categories != null && categories.contains("nutrition")) {
            permissions.add(Permission.of(DataTypes.NUTRITION, AccessType.READ));
            permissions.add(Permission.of(DataTypes.WATER_INTAKE, AccessType.READ));
        }
        if (categories != null && categories.contains("workouts")) {
            permissions.add(Permission.of(DataTypes.EXERCISE, AccessType.READ));
        }
        if (categories != null && categories.contains("body_metrics")) {
            permissions.add(Permission.of(DataTypes.BLOOD_PRESSURE, AccessType.READ));
            permissions.add(Permission.of(DataTypes.BLOOD_GLUCOSE, AccessType.READ));
            permissions.add(Permission.of(DataTypes.BODY_TEMPERATURE, AccessType.READ));
            permissions.add(Permission.of(DataTypes.BODY_COMPOSITION, AccessType.READ));
        }
        return permissions;
    }

    void requestPermissions(Set<String> categories, Consumer<String> success, Consumer<Throwable> failure) {
        if (activity == null) {
            failure.accept(new IllegalStateException("Samsung permission prompt requires opening Virii8 Companion."));
            return;
        }
        Set<Permission> requested = permissionsForCategories(categories);
        if (requested.isEmpty()) {
            success.accept("No Samsung permission categories selected. Enable at least one Health Bridge category before requesting Samsung Health permissions.");
            return;
        }
        store.requestPermissionsAsync(requested, activity).setCallback(
            Looper.getMainLooper(),
            granted -> {
                int grantedCount = granted == null ? 0 : granted.size();
                success.accept("Samsung Health permissions granted: " + grantedCount + " / " + requested.size());
            },
            failure
        );
    }

    void readTodaySelectedRecords(Set<String> categories, Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        if (categories == null || categories.isEmpty()) {
            success.accept(new ArrayList<>());
            return;
        }
        List<String> order = new ArrayList<>();
        if (categories.contains("steps")) order.add("steps");
        if (categories.contains("sleep")) order.add("sleep");
        if (categories.contains("heart")) order.add("heart");
        if (categories.contains("workouts")) order.add("workouts");
        if (categories.contains("nutrition")) order.add("nutrition");
        if (categories.contains("body_metrics")) order.add("body_metrics");
        readCategoryChain(order, 0, new ArrayList<>(), success, failure);
    }

    private void readCategoryChain(List<String> order, int index, List<JSONObject> records, Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        if (index >= order.size()) {
            success.accept(records);
            return;
        }
        String category = order.get(index);
        Consumer<List<JSONObject>> next = categoryRecords -> {
            if (categoryRecords != null) records.addAll(categoryRecords);
            readCategoryChain(order, index + 1, records, success, failure);
        };
        if ("steps".equals(category)) {
            readTodaySteps(next, failure);
        } else if ("sleep".equals(category)) {
            readTodaySleep(next, failure);
        } else if ("heart".equals(category)) {
            readTodayHeartRate(next, failure);
        } else if ("workouts".equals(category)) {
            readTodayWorkouts(next, failure);
        } else if ("nutrition".equals(category)) {
            readTodayNutritionAndHydration(next, failure);
        } else if ("body_metrics".equals(category)) {
            readTodayBodyMetrics(next, failure);
        } else {
            readCategoryChain(order, index + 1, records, success, failure);
        }
    }

    void readTodaySteps(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        LocalTimeFilter filter = LocalTimeFilter.of(start, end);
        LocalTimeGroup group = LocalTimeGroup.of(LocalTimeGroupUnit.HOURLY, 1);
        com.samsung.android.sdk.health.data.request.AggregateRequest<Long> request = DataType.StepsType.TOTAL
            .getRequestBuilder()
            .setLocalTimeFilterWithGroup(filter, group)
            .setOrdering(Ordering.ASC)
            .build();

        store.aggregateDataAsync(request).setCallback(
            Looper.getMainLooper(),
            response -> success.accept(toStepRecords(response)),
            failure
        );
    }

    void readTodayHeartRate(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        com.samsung.android.sdk.health.data.request.ReadDataRequest<HealthDataPoint> request = DataTypes.HEART_RATE
            .getReadDataRequestBuilder()
            .setLocalTimeFilter(LocalTimeFilter.of(start, end))
            .setOrdering(Ordering.ASC)
            .setLimit(500)
            .build();

        store.readDataAsync(request).setCallback(
            Looper.getMainLooper(),
            response -> success.accept(toHeartRateRecords(response)),
            failure
        );
    }

    void readTodayWorkouts(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        com.samsung.android.sdk.health.data.request.ReadDataRequest<HealthDataPoint> request = DataTypes.EXERCISE
            .getReadDataRequestBuilder()
            .setLocalTimeFilter(LocalTimeFilter.of(start, end))
            .setOrdering(Ordering.ASC)
            .setLimit(100)
            .build();

        store.readDataAsync(request).setCallback(
            Looper.getMainLooper(),
            response -> success.accept(toWorkoutRecords(response)),
            failure
        );
    }


    void readTodayNutritionAndHydration(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        readTodayNutrition(nutritionRecords -> readTodayWaterIntake(waterRecords -> {
            if (waterRecords != null) nutritionRecords.addAll(waterRecords);
            success.accept(nutritionRecords);
        }, failure), failure);
    }

    private void readTodayNutrition(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        com.samsung.android.sdk.health.data.request.ReadDataRequest<HealthDataPoint> request = DataTypes.NUTRITION
            .getReadDataRequestBuilder()
            .setLocalTimeFilter(LocalTimeFilter.of(start, end))
            .setOrdering(Ordering.ASC)
            .setLimit(200)
            .build();

        store.readDataAsync(request).setCallback(
            Looper.getMainLooper(),
            response -> success.accept(toNutritionRecords(response)),
            failure
        );
    }

    private void readTodayWaterIntake(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        com.samsung.android.sdk.health.data.request.ReadDataRequest<HealthDataPoint> request = DataTypes.WATER_INTAKE
            .getReadDataRequestBuilder()
            .setLocalTimeFilter(LocalTimeFilter.of(start, end))
            .setOrdering(Ordering.ASC)
            .setLimit(200)
            .build();

        store.readDataAsync(request).setCallback(
            Looper.getMainLooper(),
            response -> success.accept(toWaterIntakeRecords(response)),
            failure
        );
    }

    void readTodayBodyMetrics(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        readTodayBloodPressure(records -> readTodayBloodGlucose(glucose -> {
            if (glucose != null) records.addAll(glucose);
            readTodayBodyTemperature(temp -> {
                if (temp != null) records.addAll(temp);
                readTodayBodyComposition(comp -> {
                    if (comp != null) records.addAll(comp);
                    success.accept(records);
                }, failure);
            }, failure);
        }, failure), failure);
    }

    private void readTodayBloodPressure(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        com.samsung.android.sdk.health.data.request.ReadDataRequest<HealthDataPoint> request = DataTypes.BLOOD_PRESSURE
            .getReadDataRequestBuilder()
            .setLocalTimeFilter(LocalTimeFilter.of(start, end))
            .setOrdering(Ordering.ASC)
            .setLimit(100)
            .build();
        store.readDataAsync(request).setCallback(Looper.getMainLooper(), response -> success.accept(toBloodPressureRecords(response)), failure);
    }

    private void readTodayBloodGlucose(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        com.samsung.android.sdk.health.data.request.ReadDataRequest<HealthDataPoint> request = DataTypes.BLOOD_GLUCOSE
            .getReadDataRequestBuilder()
            .setLocalTimeFilter(LocalTimeFilter.of(start, end))
            .setOrdering(Ordering.ASC)
            .setLimit(100)
            .build();
        store.readDataAsync(request).setCallback(Looper.getMainLooper(), response -> success.accept(toBloodGlucoseRecords(response)), failure);
    }

    private void readTodayBodyTemperature(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        com.samsung.android.sdk.health.data.request.ReadDataRequest<HealthDataPoint> request = DataTypes.BODY_TEMPERATURE
            .getReadDataRequestBuilder()
            .setLocalTimeFilter(LocalTimeFilter.of(start, end))
            .setOrdering(Ordering.ASC)
            .setLimit(100)
            .build();
        store.readDataAsync(request).setCallback(Looper.getMainLooper(), response -> success.accept(toBodyTemperatureRecords(response)), failure);
    }

    private void readTodayBodyComposition(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        com.samsung.android.sdk.health.data.request.ReadDataRequest<HealthDataPoint> request = DataTypes.BODY_COMPOSITION
            .getReadDataRequestBuilder()
            .setLocalTimeFilter(LocalTimeFilter.of(start, end))
            .setOrdering(Ordering.ASC)
            .setLimit(100)
            .build();
        store.readDataAsync(request).setCallback(Looper.getMainLooper(), response -> success.accept(toBodyCompositionRecords(response)), failure);
    }

    void readTodaySleep(Consumer<List<JSONObject>> success, Consumer<Throwable> failure) {
        LocalDate today = LocalDate.now();
        LocalDateTime start = today.atStartOfDay();
        LocalDateTime end = start.plusDays(1);
        com.samsung.android.sdk.health.data.request.ReadDataRequest<HealthDataPoint> request = DataTypes.SLEEP
            .getReadDataRequestBuilder()
            .setLocalTimeFilter(LocalTimeFilter.of(start, end))
            .setOrdering(Ordering.ASC)
            .setLimit(100)
            .build();

        store.readDataAsync(request).setCallback(
            Looper.getMainLooper(),
            response -> {
                List<HealthDataPoint> sleepPoints = response == null || response.getDataList() == null ? new ArrayList<>() : response.getDataList();
                List<JSONObject> records = toSleepRecords(sleepPoints);
                if (sleepPoints.isEmpty()) {
                    success.accept(records);
                    return;
                }
                IdFilter.Builder ids = IdFilter.builder();
                for (HealthDataPoint point : sleepPoints) {
                    if (point != null && point.getUid() != null) ids.addDataUid(point.getUid());
                }
                AssociatedReadRequest associatedRequest = DataTypes.SLEEP
                    .getAssociatedReadRequestBuilder()
                    .setIdFilter(ids.build())
                    .addAssociatedDataType(DataType.SleepType.Associates.SKIN_TEMPERATURE)
                    .addAssociatedDataType(DataType.SleepType.Associates.BLOOD_OXYGEN)
                    .build();
                store.readAssociatedDataAsync(associatedRequest).setCallback(
                    Looper.getMainLooper(),
                    associatedResponse -> {
                        records.addAll(toSleepAssociatedRecords(associatedResponse));
                        success.accept(records);
                    },
                    associatedError -> success.accept(records)
                );
            },
            failure
        );
    }

    JSONObject buildSyncPayload(String deviceLabel, List<JSONObject> records, Set<String> selectedCategories, String companionVersion) throws Exception {
        JSONObject root = new JSONObject();
        JSONObject sdk = new JSONObject();
        sdk.put("provider", "samsung_health");
        sdk.put("sdk_version", "1.1.0");
        sdk.put("companion_version", companionVersion == null ? "0.5.0" : companionVersion);
        root.put("contract_version", "v1-samsung-health-data-sdk-1-1-0-readiness");
        root.put("device_label", deviceLabel);
        root.put("sdk", sdk);
        JSONArray categories = new JSONArray();
        if (selectedCategories != null) {
            for (String category : selectedCategories) categories.put(category);
        }
        root.put("selected_categories", categories);
        JSONArray array = new JSONArray();
        for (JSONObject record : records) array.put(record);
        root.put("records", array);
        return root;
    }

    private List<JSONObject> toStepRecords(DataResponse<AggregatedData<Long>> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (AggregatedData<Long> item : response.getDataList()) {
            try {
                JSONObject r = new JSONObject();
                r.put("recordType", "STEPS");
                r.put("startTime", safeStart(item.getStartLocalDateTime()));
                r.put("endTime", safeEnd(item.getEndLocalDateTime()));
                r.put("value", item.getValueOrDefault(0L));
                r.put("unit", "count");
                records.add(r);
            } catch (Exception ignored) {
                // Skip malformed point rather than breaking a whole sync batch.
            }
        }
        return records;
    }

    private List<JSONObject> toHeartRateRecords(DataResponse<HealthDataPoint> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (HealthDataPoint point : response.getDataList()) {
            try {
                JSONObject r = new JSONObject();
                r.put("recordType", "HEART_RATE");
                r.put("sourceUid", point.getUid());
                r.put("startTime", safeStart(point.getStartLocalDateTime()));
                r.put("endTime", safeEnd(point.getEndLocalDateTime()));
                JSONObject fields = new JSONObject();
                Float heartRate = point.getValue(DataType.HeartRateType.HEART_RATE);
                Float min = point.getValue(DataType.HeartRateType.MIN_HEART_RATE);
                Float max = point.getValue(DataType.HeartRateType.MAX_HEART_RATE);
                if (heartRate != null) fields.put("HEART_RATE", heartRate);
                if (min != null) fields.put("MIN_HEART_RATE", min);
                if (max != null) fields.put("MAX_HEART_RATE", max);
                r.put("fields", fields);
                r.put("unit", "bpm");
                records.add(r);
            } catch (Exception ignored) {
                // Skip malformed point rather than breaking a whole sync batch.
            }
        }
        return records;
    }

    private List<JSONObject> toWorkoutRecords(DataResponse<HealthDataPoint> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (HealthDataPoint point : response.getDataList()) {
            try {
                JSONObject top = new JSONObject();
                top.put("recordType", "EXERCISE");
                top.put("sourceUid", point.getUid());
                top.put("startTime", safeStart(point.getStartLocalDateTime()));
                top.put("endTime", safeEnd(point.getEndLocalDateTime()));
                JSONObject fields = new JSONObject();
                Object exerciseType = point.getValue(DataType.ExerciseType.EXERCISE_TYPE);
                String customTitle = point.getValue(DataType.ExerciseType.CUSTOM_TITLE);
                if (exerciseType != null) fields.put("EXERCISE_TYPE", enumName(exerciseType));
                if (customTitle != null && !customTitle.trim().isEmpty()) fields.put("CUSTOM_TITLE", customTitle);
                top.put("fields", fields);
                top.put("privacy", workoutPrivacyNotice());
                records.add(top);

                List<ExerciseSession> sessions = point.getValue(DataType.ExerciseType.SESSIONS);
                if (sessions != null) {
                    for (ExerciseSession session : sessions) {
                        if (session == null) continue;
                        records.add(toWorkoutSessionRecord(point.getUid(), session));
                    }
                }
            } catch (Exception ignored) {
                // Skip malformed exercise point rather than breaking a whole sync batch.
            }
        }
        return records;
    }

    private JSONObject toWorkoutSessionRecord(String parentUid, ExerciseSession session) throws Exception {
        JSONObject r = new JSONObject();
        r.put("recordType", "EXERCISE_SESSION");
        r.put("parentUid", parentUid);
        r.put("startTime", safeInstant(session.getStartTime()));
        r.put("endTime", safeInstant(session.getEndTime()));
        if (session.getDuration() != null) r.put("durationSeconds", session.getDuration().getSeconds());
        JSONObject fields = new JSONObject();
        putIfPresent(fields, "CUSTOM_TITLE", session.getCustomTitle());
        putIfPresent(fields, "EXERCISE_TYPE", enumName(session.getExerciseType()));
        putIfPresent(fields, "COUNT_TYPE", enumName(session.getCountType()));
        fields.put("CALORIES", session.getCalories());
        putIfPresent(fields, "DISTANCE_METERS", session.getDistance());
        putIfPresent(fields, "ALTITUDE_GAIN", session.getAltitudeGain());
        putIfPresent(fields, "ALTITUDE_LOSS", session.getAltitudeLoss());
        putIfPresent(fields, "COUNT", session.getCount());
        putIfPresent(fields, "MAX_SPEED", session.getMaxSpeed());
        putIfPresent(fields, "MEAN_SPEED", session.getMeanSpeed());
        putIfPresent(fields, "MAX_CALORIE_BURN_RATE", session.getMaxCalorieBurnRate());
        putIfPresent(fields, "MEAN_CALORIE_BURN_RATE", session.getMeanCalorieBurnRate());
        putIfPresent(fields, "MAX_CADENCE", session.getMaxCadence());
        putIfPresent(fields, "MEAN_CADENCE", session.getMeanCadence());
        putIfPresent(fields, "MAX_HEART_RATE", session.getMaxHeartRate());
        putIfPresent(fields, "MEAN_HEART_RATE", session.getMeanHeartRate());
        putIfPresent(fields, "MIN_HEART_RATE", session.getMinHeartRate());
        putIfPresent(fields, "MAX_ALTITUDE", session.getMaxAltitude());
        putIfPresent(fields, "MIN_ALTITUDE", session.getMinAltitude());
        putIfPresent(fields, "INCLINE_DISTANCE", session.getInclineDistance());
        putIfPresent(fields, "DECLINE_DISTANCE", session.getDeclineDistance());
        putIfPresent(fields, "MAX_POWER", session.getMaxPower());
        putIfPresent(fields, "MEAN_POWER", session.getMeanPower());
        putIfPresent(fields, "MAX_RPM", session.getMaxRpm());
        putIfPresent(fields, "MEAN_RPM", session.getMeanRpm());
        putIfPresent(fields, "VO2_MAX", session.getVo2Max());
        putIfPresent(fields, "AUTO_DETECTED", session.getAutoDetected());
        if (session.getComment() != null && !session.getComment().trim().isEmpty()) fields.put("COMMENT_PRESENT", true);

        List<ExerciseLocation> route = session.getRoute();
        List<ExerciseLog> logs = session.getLog();
        fields.put("ROUTE_POINT_COUNT", route == null ? 0 : route.size());
        fields.put("LOG_POINT_COUNT", logs == null ? 0 : logs.size());
        if (logs != null && !logs.isEmpty()) fields.put("LOG_SUMMARY", summarizeWorkoutLogs(logs));
        r.put("fields", fields);
        r.put("privacy", workoutPrivacyNotice());
        return r;
    }

    private JSONObject summarizeWorkoutLogs(List<ExerciseLog> logs) throws Exception {
        JSONObject summary = new JSONObject();
        int heartCount = 0;
        float heartTotal = 0f;
        Float minHeart = null;
        Float maxHeart = null;
        int speedCount = 0;
        float speedTotal = 0f;
        Float maxSpeed = null;
        int powerCount = 0;
        float powerTotal = 0f;
        Float maxPower = null;
        for (ExerciseLog log : logs) {
            if (log == null) continue;
            Float heart = log.getHeartRate();
            if (heart != null) {
                heartCount++;
                heartTotal += heart;
                minHeart = minHeart == null ? heart : Math.min(minHeart, heart);
                maxHeart = maxHeart == null ? heart : Math.max(maxHeart, heart);
            }
            Float speed = log.getSpeed();
            if (speed != null) {
                speedCount++;
                speedTotal += speed;
                maxSpeed = maxSpeed == null ? speed : Math.max(maxSpeed, speed);
            }
            Float power = log.getPower();
            if (power != null) {
                powerCount++;
                powerTotal += power;
                maxPower = maxPower == null ? power : Math.max(maxPower, power);
            }
        }
        if (heartCount > 0) {
            summary.put("HEART_LOG_COUNT", heartCount);
            summary.put("MEAN_HEART_RATE", heartTotal / heartCount);
            summary.put("MIN_HEART_RATE", minHeart);
            summary.put("MAX_HEART_RATE", maxHeart);
        }
        if (speedCount > 0) {
            summary.put("SPEED_LOG_COUNT", speedCount);
            summary.put("MEAN_SPEED", speedTotal / speedCount);
            summary.put("MAX_SPEED", maxSpeed);
        }
        if (powerCount > 0) {
            summary.put("POWER_LOG_COUNT", powerCount);
            summary.put("MEAN_POWER", powerTotal / powerCount);
            summary.put("MAX_POWER", maxPower);
        }
        return summary;
    }

    private JSONObject workoutPrivacyNotice() throws Exception {
        JSONObject privacy = new JSONObject();
        privacy.put("route_coordinates_included", false);
        privacy.put("route_policy", "v0.5.0 syncs workout summaries and route/log counts only. Exact GPS route coordinates are intentionally withheld until a dedicated privacy toggle exists.");
        return privacy;
    }

    private void putIfPresent(JSONObject target, String key, Object value) throws Exception {
        if (value != null) target.put(key, value);
    }

    private String enumName(Object value) {
        if (value == null) return null;
        if (value instanceof Enum) return ((Enum<?>) value).name();
        return String.valueOf(value);
    }


    private List<JSONObject> toNutritionRecords(DataResponse<HealthDataPoint> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (HealthDataPoint point : response.getDataList()) {
            try {
                JSONObject r = baseRecord("NUTRITION", point);
                JSONObject fields = new JSONObject();
                putIfPresent(fields, "MEAL_TYPE", enumName(point.getValue(DataType.NutritionType.MEAL_TYPE)));
                putIfPresent(fields, "TITLE", point.getValue(DataType.NutritionType.TITLE));
                putIfPresent(fields, "CALORIES", point.getValue(DataType.NutritionType.CALORIES));
                putIfPresent(fields, "TOTAL_FAT", point.getValue(DataType.NutritionType.TOTAL_FAT));
                putIfPresent(fields, "SATURATED_FAT", point.getValue(DataType.NutritionType.SATURATED_FAT));
                putIfPresent(fields, "POLYSATURATED_FAT", point.getValue(DataType.NutritionType.POLYSATURATED_FAT));
                putIfPresent(fields, "MONOSATURATED_FAT", point.getValue(DataType.NutritionType.MONOSATURATED_FAT));
                putIfPresent(fields, "TRANS_FAT", point.getValue(DataType.NutritionType.TRANS_FAT));
                putIfPresent(fields, "CARBOHYDRATE", point.getValue(DataType.NutritionType.CARBOHYDRATE));
                putIfPresent(fields, "DIETARY_FIBER", point.getValue(DataType.NutritionType.DIETARY_FIBER));
                putIfPresent(fields, "SUGAR", point.getValue(DataType.NutritionType.SUGAR));
                putIfPresent(fields, "PROTEIN", point.getValue(DataType.NutritionType.PROTEIN));
                putIfPresent(fields, "CHOLESTEROL", point.getValue(DataType.NutritionType.CHOLESTEROL));
                putIfPresent(fields, "SODIUM", point.getValue(DataType.NutritionType.SODIUM));
                putIfPresent(fields, "POTASSIUM", point.getValue(DataType.NutritionType.POTASSIUM));
                putIfPresent(fields, "VITAMIN_A", point.getValue(DataType.NutritionType.VITAMIN_A));
                putIfPresent(fields, "VITAMIN_C", point.getValue(DataType.NutritionType.VITAMIN_C));
                putIfPresent(fields, "CALCIUM", point.getValue(DataType.NutritionType.CALCIUM));
                putIfPresent(fields, "IRON", point.getValue(DataType.NutritionType.IRON));
                r.put("fields", fields);
                r.put("unit_policy", "Samsung nutrition macro/micro-nutrients are forwarded in Samsung SDK units for Core-side normalization.");
                records.add(r);
            } catch (Exception ignored) {
                // Skip malformed nutrition point rather than breaking a whole sync batch.
            }
        }
        return records;
    }

    private List<JSONObject> toWaterIntakeRecords(DataResponse<HealthDataPoint> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (HealthDataPoint point : response.getDataList()) {
            try {
                JSONObject r = baseRecord("WATER_INTAKE", point);
                JSONObject fields = new JSONObject();
                putIfPresent(fields, "AMOUNT", point.getValue(DataType.WaterIntakeType.AMOUNT));
                r.put("fields", fields);
                r.put("unit", "milliliter_or_provider_default");
                records.add(r);
            } catch (Exception ignored) {
                // Skip malformed hydration point.
            }
        }
        return records;
    }

    private List<JSONObject> toBloodPressureRecords(DataResponse<HealthDataPoint> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (HealthDataPoint point : response.getDataList()) {
            try {
                JSONObject r = baseRecord("BLOOD_PRESSURE", point);
                JSONObject fields = new JSONObject();
                putIfPresent(fields, "SYSTOLIC", point.getValue(DataType.BloodPressureType.SYSTOLIC));
                putIfPresent(fields, "DIASTOLIC", point.getValue(DataType.BloodPressureType.DIASTOLIC));
                putIfPresent(fields, "MEAN", point.getValue(DataType.BloodPressureType.MEAN));
                putIfPresent(fields, "PULSE_RATE", point.getValue(DataType.BloodPressureType.PULSE_RATE));
                putIfPresent(fields, "MEDICATION_TAKEN", point.getValue(DataType.BloodPressureType.MEDICATION_TAKEN));
                r.put("fields", fields);
                r.put("unit", "mmHg");
                records.add(r);
            } catch (Exception ignored) {
                // Skip malformed blood-pressure point.
            }
        }
        return records;
    }

    private List<JSONObject> toBloodGlucoseRecords(DataResponse<HealthDataPoint> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (HealthDataPoint point : response.getDataList()) {
            try {
                JSONObject r = baseRecord("BLOOD_GLUCOSE", point);
                JSONObject fields = new JSONObject();
                putIfPresent(fields, "GLUCOSE_LEVEL", point.getValue(DataType.BloodGlucoseType.GLUCOSE_LEVEL));
                putIfPresent(fields, "MEASUREMENT_TYPE", enumName(point.getValue(DataType.BloodGlucoseType.MEASUREMENT_TYPE)));
                putIfPresent(fields, "SAMPLE_SOURCE_TYPE", enumName(point.getValue(DataType.BloodGlucoseType.SAMPLE_SOURCE_TYPE)));
                java.time.Instant mealTime = point.getValue(DataType.BloodGlucoseType.MEAL_TIME);
                if (mealTime != null) fields.put("MEAL_TIME", safeInstant(mealTime));
                putIfPresent(fields, "MEAL_STATUS", enumName(point.getValue(DataType.BloodGlucoseType.MEAL_STATUS)));
                putIfPresent(fields, "INSULIN_INJECTED", point.getValue(DataType.BloodGlucoseType.INSULIN_INJECTED));
                putIfPresent(fields, "MEDICATION_TAKEN", point.getValue(DataType.BloodGlucoseType.MEDICATION_TAKEN));
                List<?> series = point.getValue(DataType.BloodGlucoseType.SERIES_DATA);
                if (series != null) fields.put("SERIES_POINT_COUNT", series.size());
                r.put("fields", fields);
                r.put("unit", "provider_default_glucose_unit");
                records.add(r);
            } catch (Exception ignored) {
                // Skip malformed glucose point.
            }
        }
        return records;
    }

    private List<JSONObject> toBodyTemperatureRecords(DataResponse<HealthDataPoint> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (HealthDataPoint point : response.getDataList()) {
            try {
                JSONObject r = baseRecord("BODY_TEMPERATURE", point);
                JSONObject fields = new JSONObject();
                putIfPresent(fields, "BODY_TEMPERATURE", point.getValue(DataType.BodyTemperatureType.BODY_TEMPERATURE));
                r.put("fields", fields);
                r.put("unit", "celsius");
                records.add(r);
            } catch (Exception ignored) {
                // Skip malformed temperature point.
            }
        }
        return records;
    }

    private List<JSONObject> toBodyCompositionRecords(DataResponse<HealthDataPoint> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (HealthDataPoint point : response.getDataList()) {
            try {
                JSONObject r = baseRecord("BODY_COMPOSITION", point);
                JSONObject fields = new JSONObject();
                putIfPresent(fields, "WEIGHT", point.getValue(DataType.BodyCompositionType.WEIGHT));
                putIfPresent(fields, "HEIGHT", point.getValue(DataType.BodyCompositionType.HEIGHT));
                putIfPresent(fields, "BODY_FAT", point.getValue(DataType.BodyCompositionType.BODY_FAT));
                putIfPresent(fields, "SKELETAL_MUSCLE", point.getValue(DataType.BodyCompositionType.SKELETAL_MUSCLE));
                putIfPresent(fields, "MUSCLE_MASS", point.getValue(DataType.BodyCompositionType.MUSCLE_MASS));
                putIfPresent(fields, "BASAL_METABOLIC_RATE", point.getValue(DataType.BodyCompositionType.BASAL_METABOLIC_RATE));
                putIfPresent(fields, "BODY_FAT_MASS", point.getValue(DataType.BodyCompositionType.BODY_FAT_MASS));
                putIfPresent(fields, "FAT_FREE_MASS", point.getValue(DataType.BodyCompositionType.FAT_FREE_MASS));
                putIfPresent(fields, "FAT_FREE", point.getValue(DataType.BodyCompositionType.FAT_FREE));
                putIfPresent(fields, "SKELETAL_MUSCLE_MASS", point.getValue(DataType.BodyCompositionType.SKELETAL_MUSCLE_MASS));
                putIfPresent(fields, "TOTAL_BODY_WATER", point.getValue(DataType.BodyCompositionType.TOTAL_BODY_WATER));
                putIfPresent(fields, "BODY_MASS_INDEX", point.getValue(DataType.BodyCompositionType.BODY_MASS_INDEX));
                r.put("fields", fields);
                r.put("unit_policy", "Samsung body composition fields are forwarded in Samsung SDK units for Core-side normalization.");
                records.add(r);
            } catch (Exception ignored) {
                // Skip malformed body-composition point.
            }
        }
        return records;
    }

    private JSONObject baseRecord(String recordType, HealthDataPoint point) throws Exception {
        JSONObject r = new JSONObject();
        r.put("recordType", recordType);
        r.put("sourceUid", point.getUid());
        r.put("startTime", safeStart(point.getStartLocalDateTime()));
        r.put("endTime", safeEnd(point.getEndLocalDateTime()));
        return r;
    }

    private List<JSONObject> toSleepRecords(List<HealthDataPoint> sleepPoints) {
        List<JSONObject> records = new ArrayList<>();
        if (sleepPoints == null) return records;
        for (HealthDataPoint point : sleepPoints) {
            try {
                JSONObject r = new JSONObject();
                r.put("recordType", "SLEEP_SESSION");
                r.put("sourceUid", point.getUid());
                r.put("startTime", safeStart(point.getStartLocalDateTime()));
                r.put("endTime", safeEnd(point.getEndLocalDateTime()));
                Duration duration = point.getValue(DataType.SleepType.DURATION);
                Integer score = point.getValue(DataType.SleepType.SLEEP_SCORE);
                if (duration != null) r.put("durationSeconds", duration.getSeconds());
                if (score != null) r.put("sleepScore", score);
                records.add(r);

                List<SleepSession> sessions = point.getValue(DataType.SleepType.SESSIONS);
                if (sessions != null) {
                    for (SleepSession session : sessions) {
                        if (session == null) continue;
                        JSONObject sr = new JSONObject();
                        sr.put("recordType", "SLEEP_SESSION_DETAIL");
                        sr.put("parentUid", point.getUid());
                        sr.put("startTime", session.getStartTime() == null ? safeStart(point.getStartLocalDateTime()) : LocalDateTime.ofInstant(session.getStartTime(), ZoneId.systemDefault()).toString());
                        sr.put("endTime", session.getEndTime() == null ? safeEnd(point.getEndLocalDateTime()) : LocalDateTime.ofInstant(session.getEndTime(), ZoneId.systemDefault()).toString());
                        if (session.getDuration() != null) sr.put("durationSeconds", session.getDuration().getSeconds());
                        records.add(sr);

                        List<SleepSession.SleepStage> stages = session.getStages();
                        if (stages != null) {
                            for (SleepSession.SleepStage stage : stages) {
                                if (stage == null) continue;
                                JSONObject st = new JSONObject();
                                st.put("recordType", "SLEEP_STAGE");
                                st.put("parentUid", point.getUid());
                                st.put("stage", stage.getStage() == null ? "UNKNOWN" : stage.getStage().name());
                                st.put("startTime", stage.getStartTime() == null ? safeStart(point.getStartLocalDateTime()) : LocalDateTime.ofInstant(stage.getStartTime(), ZoneId.systemDefault()).toString());
                                st.put("endTime", stage.getEndTime() == null ? safeEnd(point.getEndLocalDateTime()) : LocalDateTime.ofInstant(stage.getEndTime(), ZoneId.systemDefault()).toString());
                                records.add(st);
                            }
                        }
                    }
                }
            } catch (Exception ignored) {
                // Skip malformed sleep point rather than breaking a whole sync batch.
            }
        }
        return records;
    }

    private List<JSONObject> toSleepAssociatedRecords(DataResponse<AssociatedDataPoints> response) {
        List<JSONObject> records = new ArrayList<>();
        if (response == null || response.getDataList() == null) return records;
        for (AssociatedDataPoints associated : response.getDataList()) {
            if (associated == null) continue;
            try {
                List<HealthDataPoint> skinPoints = associated.getDataPointOf(DataTypes.SKIN_TEMPERATURE);
                if (skinPoints != null) {
                    for (HealthDataPoint point : skinPoints) {
                        JSONObject r = new JSONObject();
                        r.put("recordType", "SLEEP_SKIN_TEMPERATURE");
                        r.put("parentUid", associated.getUid());
                        r.put("sourceUid", point.getUid());
                        r.put("startTime", safeStart(point.getStartLocalDateTime()));
                        r.put("endTime", safeEnd(point.getEndLocalDateTime()));
                        JSONObject fields = new JSONObject();
                        Float temp = point.getValue(DataType.SkinTemperatureType.SKIN_TEMPERATURE);
                        Float min = point.getValue(DataType.SkinTemperatureType.MIN_SKIN_TEMPERATURE);
                        Float max = point.getValue(DataType.SkinTemperatureType.MAX_SKIN_TEMPERATURE);
                        if (temp != null) fields.put("SKIN_TEMPERATURE", temp);
                        if (min != null) fields.put("MIN_SKIN_TEMPERATURE", min);
                        if (max != null) fields.put("MAX_SKIN_TEMPERATURE", max);
                        r.put("fields", fields);
                        r.put("unit", "celsius");
                        records.add(r);
                    }
                }

                List<HealthDataPoint> oxygenPoints = associated.getDataPointOf(DataTypes.BLOOD_OXYGEN);
                if (oxygenPoints != null) {
                    for (HealthDataPoint point : oxygenPoints) {
                        JSONObject r = new JSONObject();
                        r.put("recordType", "SLEEP_BLOOD_OXYGEN");
                        r.put("parentUid", associated.getUid());
                        r.put("sourceUid", point.getUid());
                        r.put("startTime", safeStart(point.getStartLocalDateTime()));
                        r.put("endTime", safeEnd(point.getEndLocalDateTime()));
                        JSONObject fields = new JSONObject();
                        Float oxygen = point.getValue(DataType.BloodOxygenType.OXYGEN_SATURATION);
                        Float min = point.getValue(DataType.BloodOxygenType.MIN_OXYGEN_SATURATION);
                        Float max = point.getValue(DataType.BloodOxygenType.MAX_OXYGEN_SATURATION);
                        if (oxygen != null) fields.put("OXYGEN_SATURATION", oxygen);
                        if (min != null) fields.put("MIN_OXYGEN_SATURATION", min);
                        if (max != null) fields.put("MAX_OXYGEN_SATURATION", max);
                        r.put("fields", fields);
                        r.put("unit", "percent");
                        records.add(r);
                    }
                }
            } catch (Exception ignored) {
                // Skip malformed associated sleep point.
            }
        }
        return records;
    }

    private String safeStart(LocalDateTime value) {
        return value == null ? LocalDateTime.now().toString() : value.toString();
    }

    private String safeEnd(LocalDateTime value) {
        return value == null ? LocalDateTime.now().toString() : value.toString();
    }

    private String safeInstant(java.time.Instant value) {
        return value == null ? LocalDateTime.now().toString() : LocalDateTime.ofInstant(value, ZoneId.systemDefault()).toString();
    }
}
