package com.miltonmarketing.virii8.health;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Runs a conservative scheduled Health Bridge sync when policy constraints pass. */
public class BackgroundSyncReceiver extends BroadcastReceiver {
    private static final String PREFS = "virii8_health_companion_preferences";
    private static final String KEY_PENDING_QUEUE = "pending_sync_queue";
    private static final String KEY_QUEUE_LAST_CHANGE = "pending_sync_queue_last_change";
    private static final String KEY_SYNC_HISTORY = "sync_history";
    private static final String KEY_LAST_SYNC = "last_sync_summary";
    private static final int HISTORY_LIMIT = 24;
    private static final int QUEUE_LIMIT = 12;
    private static final String[] CATEGORY_KEYS = {"steps", "sleep", "heart", "workouts", "nutrition", "body_metrics"};

    @Override
    public void onReceive(Context context, Intent intent) {
        PendingResult pending = goAsync();
        runBackgroundSync(context.getApplicationContext(), pending);
    }

    static void runNow(Context context) {
        Intent intent = new Intent(context, BackgroundSyncReceiver.class).setAction(BackgroundSyncScheduler.ACTION_BACKGROUND_SYNC);
        context.sendBroadcast(intent);
    }

    private static void runBackgroundSync(Context context, PendingResult pending) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        SecureTokenStore tokenStore = new SecureTokenStore(context);
        ExecutorService executor = Executors.newSingleThreadExecutor();
        SamsungHealthBridge bridge = new SamsungHealthBridge(context);

        Runnable finishOnly = () -> {
            BackgroundSyncScheduler.apply(context, prefs);
            pending.finish();
        };

        try {
            String mode = prefs.getString(MainActivity.KEY_BACKGROUND_MODE, MainActivity.MODE_MANUAL);
            if (MainActivity.MODE_MANUAL.equals(mode) || prefs.getBoolean(MainActivity.KEY_BACKGROUND_PAUSED, false)) {
                recordResult(prefs, "Skipped: background sync is manual-only or paused.");
                finishOnly.run();
                return;
            }
            if (!tokenStore.isPaired()) {
                recordResult(prefs, "Skipped: device is not paired with Virii8.");
                finishOnly.run();
                return;
            }
            if (prefs.getBoolean(MainActivity.KEY_BACKGROUND_WIFI_ONLY, true) && !isWifiConnected(context)) {
                recordResult(prefs, "Skipped: Wi-Fi-only background policy and Wi-Fi is not connected.");
                finishOnly.run();
                return;
            }
            if (prefs.getBoolean(MainActivity.KEY_BACKGROUND_CHARGING_ONLY, false) && !isCharging(context)) {
                recordResult(prefs, "Skipped: charging-only background policy and device is not charging.");
                finishOnly.run();
                return;
            }
            Set<String> cats = selectedCategories(prefs);
            if (cats.isEmpty()) {
                recordResult(prefs, "Skipped: no Health Bridge categories selected.");
                finishOnly.run();
                return;
            }

            appendHistory(prefs, "background", "Background sync started for: " + categorySummary(cats) + ".");
            prefs.edit().putString(MainActivity.KEY_BACKGROUND_LAST_RUN, stamp()).apply();

            bridge.readTodaySelectedRecords(cats, records -> {
                if (records == null || records.isEmpty()) {
                    recordResult(prefs, "Completed: Samsung returned zero records for " + categorySummary(cats) + ".");
                    finishOnly.run();
                    return;
                }
                executor.execute(() -> {
                    JSONObject payload = null;
                    try {
                        payload = bridge.buildSyncPayload(tokenStore.getDeviceLabel(), records, cats, "0.6.0-background");
                        if (!isNetworkAvailable(context)) {
                            queuePayload(prefs, tokenStore, payload, "background network unavailable");
                            recordResult(prefs, "Queued: network unavailable after reading " + records.size() + " record(s).");
                        } else {
                            String response = Virii8HealthApi.postSync(tokenStore.getSiteUrl(), tokenStore.getToken(), payload);
                            String summary = stampMinute() + " • background • " + records.size() + " health records • " + categorySummary(cats);
                            prefs.edit().putString(KEY_LAST_SYNC, summary).apply();
                            recordResult(prefs, "Success: sent " + records.size() + " background record(s). Virii8: " + shortResponse(response));
                        }
                    } catch (Exception e) {
                        if (payload != null) queuePayload(prefs, tokenStore, payload, "background send failed: " + e.getMessage());
                        recordResult(prefs, "Error: " + e.getMessage());
                    } finally {
                        executor.shutdownNow();
                        BackgroundSyncScheduler.apply(context, prefs);
                        pending.finish();
                    }
                });
            }, e -> {
                recordResult(prefs, "Samsung read error: " + e.getMessage());
                finishOnly.run();
            });
        } catch (Exception e) {
            recordResult(prefs, "Unexpected background error: " + e.getMessage());
            finishOnly.run();
        }
    }

    private static Set<String> selectedCategories(SharedPreferences prefs) {
        Set<String> out = new LinkedHashSet<>();
        for (String key : CATEGORY_KEYS) {
            if (prefs.getBoolean("cat_" + key, "steps".equals(key))) out.add(key);
        }
        return out;
    }

    private static String categorySummary(Set<String> cats) {
        if (cats == null || cats.isEmpty()) return "none";
        StringBuilder b = new StringBuilder();
        for (String key : cats) {
            if (b.length() > 0) b.append(", ");
            if ("body_metrics".equals(key)) b.append("body metrics"); else b.append(key);
        }
        return b.toString();
    }

    private static boolean isNetworkAvailable(Context context) {
        try {
            ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (manager == null) return true;
            NetworkInfo info = manager.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception ignored) {
            return true;
        }
    }

    private static boolean isWifiConnected(Context context) {
        try {
            ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (manager == null) return true;
            NetworkInfo info = manager.getActiveNetworkInfo();
            return info != null && info.isConnected() && info.getType() == ConnectivityManager.TYPE_WIFI;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static boolean isCharging(Context context) {
        try {
            Intent battery = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (battery == null) return false;
            int status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            return status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static void queuePayload(SharedPreferences prefs, SecureTokenStore tokenStore, JSONObject payload, String reason) {
        if (payload == null) return;
        JSONArray old = loadPendingQueue(prefs);
        JSONArray next = new JSONArray();
        int start = Math.max(0, old.length() - (QUEUE_LIMIT - 1));
        for (int i = start; i < old.length(); i++) {
            Object item = old.opt(i);
            if (item != null) next.put(item);
        }
        JSONObject envelope = new JSONObject();
        try {
            envelope.put("queued_at", stamp());
            envelope.put("reason", sanitize(reason));
            envelope.put("site_url", tokenStore.getSiteUrl());
            envelope.put("device_label", tokenStore.getDeviceLabel());
            envelope.put("selected_categories", "background");
            envelope.put("payload", payload);
            next.put(envelope);
            prefs.edit()
                .putString(KEY_PENDING_QUEUE, next.toString())
                .putString(KEY_QUEUE_LAST_CHANGE, stamp() + " • queued background batch: " + sanitize(reason))
                .apply();
            appendHistory(prefs, "queue", "Queued background sync batch locally: " + reason + ". Pending queue: " + next.length());
        } catch (JSONException ignored) {}
    }

    private static JSONArray loadPendingQueue(SharedPreferences prefs) {
        try {
            return new JSONArray(prefs.getString(KEY_PENDING_QUEUE, "[]"));
        } catch (JSONException e) {
            prefs.edit().remove(KEY_PENDING_QUEUE).putString(KEY_QUEUE_LAST_CHANGE, stamp() + " • queue reset after malformed background JSON").apply();
            return new JSONArray();
        }
    }

    private static void recordResult(SharedPreferences prefs, String result) {
        String clean = sanitize(result);
        prefs.edit().putString(MainActivity.KEY_BACKGROUND_LAST_RUN, stamp()).putString(MainActivity.KEY_BACKGROUND_LAST_RESULT, clean).apply();
        appendHistory(prefs, "background", clean);
    }

    private static void appendHistory(SharedPreferences prefs, String type, String message) {
        String line = stamp() + " • " + sanitize(type) + " • " + sanitize(message);
        String existing = prefs.getString(KEY_SYNC_HISTORY, "");
        String[] oldLines = existing == null || existing.trim().isEmpty() ? new String[0] : existing.split("\\n");
        StringBuilder b = new StringBuilder(line);
        int kept = 1;
        for (String old : oldLines) {
            if (old == null || old.trim().isEmpty()) continue;
            if (kept >= HISTORY_LIMIT) break;
            b.append('\n').append(old.trim());
            kept++;
        }
        prefs.edit().putString(KEY_SYNC_HISTORY, b.toString()).apply();
    }

    private static String shortResponse(String response) {
        if (response == null) return "empty response";
        String clean = response.replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() > 180 ? clean.substring(0, 180) + "…" : clean;
    }

    private static String sanitize(String value) {
        if (value == null) return "";
        String clean = value.replace('\n', ' ').replace('\r', ' ').trim();
        return clean.length() > 260 ? clean.substring(0, 260) + "…" : clean;
    }

    private static String stamp() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
    }

    private static String stampMinute() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date());
    }
}
