# Virii8 Health Companion Android v0.1.1

Professional Samsung Health Data SDK bridge companion for MiltonMarketing.com / Virii8 Health.

## v0.1.1 changes

- Removes the forced portrait lock so the app can rotate normally.
- Adds responsive phone/tablet/foldable layout behavior.
- Uses a centered max-width shell on wide screens.
- Uses two-column layout on landscape/tablet/foldable widths.
- Adds bridge status summary.
- Adds setup help directly in the app.
- Adds data coverage explanation.
- Adds external help links for MiltonMarketing.com, Samsung Health Data SDK, Android Health Connect, Fitbit Web API, and Apple HealthKit.
- Preserves encrypted local token storage.
- Preserves manual Samsung step aggregate sync scaffold.

## Build with GitHub Actions

This project includes `.github/workflows/build-debug-apk.yml`.

If the project is extracted into a GitHub repo root, go to:

`Actions -> Build Virii8 Health Debug APK -> Run workflow`

Download artifact:

`virii8-health-companion-v0.1.0-debug-apk`

The APK will be inside the artifact ZIP.

## Build locally

```bash
./build-debug-apk.sh
```

Output:

`app/build/outputs/apk/debug/app-debug.apk`

## Runtime notes

The Samsung SDK must run on a real Android device. Emulators are not supported by Samsung Health Data SDK.

The app currently syncs today's Samsung step aggregates only. Additional record groups are prepared in the bridge contract but should be enabled through separate tested passes.
